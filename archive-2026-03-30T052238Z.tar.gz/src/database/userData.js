const { existsSync, mkdirSync, readFileSync, writeFileSync } = require('fs');
const { join } = require('path');
const config = require('../config');

const USER_DATA_DIR = join(config.paths.data, 'users');

// In-memory cache to reduce fs reads — flushed periodically
const userCache = new Map();
const CACHE_TTL = 120000; // 2 minutes

/**
 * Ensure the user data directory exists.
 */
function ensureUserDir() {
  if (!existsSync(USER_DATA_DIR)) {
    mkdirSync(USER_DATA_DIR, { recursive: true });
  }
}

/**
 * Get the file path for a user's data file.
 */
function getUserFilePath(userId) {
  return join(USER_DATA_DIR, `${userId}.json`);
}

/**
 * Default user data structure.
 */
function defaultUserData(userId, username) {
  return {
    userId,
    username: username || 'unknown',
    displayName: '',
    firstSeen: Date.now(),
    lastActive: Date.now(),
    totalMessages: 0,
    facts: [],           // things the bot knows about this user
    interests: [],       // detected interests
    nicknames: [],       // names/relationships: "bhai", "babe", "papa"
    recentTopics: [],    // last N topics discussed
    mood: 'neutral',     // last detected mood
    language: 'hinglish',// preferred language
    relationship: 'acquaintance', // acquaintance → friend → close → bestfriend
    gossip: [],          // things OTHER users said about this user
    conversationLog: [], // last N bot<->user exchanges (for memory)
    notes: [],           // AI-generated observations
    warnings: 0,         // toxic escalation count
  };
}

/**
 * Load user data from file (or cache).
 */
function loadUserData(userId) {
  // Check cache first
  const cached = userCache.get(userId);
  if (cached && Date.now() - cached.loadedAt < CACHE_TTL) {
    return cached.data;
  }

  ensureUserDir();
  const filePath = getUserFilePath(userId);

  if (existsSync(filePath)) {
    try {
      const raw = readFileSync(filePath, 'utf-8');
      const data = JSON.parse(raw);
      userCache.set(userId, { data, loadedAt: Date.now() });
      return data;
    } catch (e) {
      console.error(`[UserData] Failed to read ${filePath}:`, e.message);
    }
  }

  return null;
}

/**
 * Save user data to file and cache.
 */
function saveUserData(userId, data) {
  ensureUserDir();
  const filePath = getUserFilePath(userId);

  try {
    writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf-8');
    userCache.set(userId, { data, loadedAt: Date.now() });
  } catch (e) {
    console.error(`[UserData] Failed to write ${filePath}:`, e.message);
  }
}

/**
 * Get or create user data.
 */
function getOrCreateUser(userId, username, displayName) {
  let data = loadUserData(userId);
  if (!data) {
    data = defaultUserData(userId, username);
    data.displayName = displayName || '';
    saveUserData(userId, data);
  } else {
    // Update last active and username
    data.lastActive = Date.now();
    if (username) data.username = username;
    if (displayName) data.displayName = displayName;
  }
  return data;
}

/**
 * Track a message from a user (increment count, update activity).
 */
function trackUserMessage(userId, username, displayName, content) {
  const data = getOrCreateUser(userId, username, displayName);
  data.totalMessages++;
  data.lastActive = Date.now();

  // Track recent topics (keep last 20)
  if (content && content.length > 10) {
    data.recentTopics.push({
      text: content.slice(0, 150),
      time: Date.now(),
    });
    if (data.recentTopics.length > 20) {
      data.recentTopics = data.recentTopics.slice(-20);
    }
  }

  saveUserData(userId, data);
  return data;
}

/**
 * Log a bot<->user conversation exchange.
 */
function logUserConversation(userId, username, userMessage, botReply) {
  const data = getOrCreateUser(userId, username);

  data.conversationLog.push({
    user: userMessage.slice(0, 300),
    bot: botReply.slice(0, 300),
    time: Date.now(),
  });

  // Keep last 50 exchanges
  if (data.conversationLog.length > 50) {
    data.conversationLog = data.conversationLog.slice(-50);
  }

  saveUserData(userId, data);
}

/**
 * Add a fact about a user (dedup by similarity).
 */
function addUserFact(userId, fact) {
  const data = loadUserData(userId);
  if (!data) return;

  const lower = fact.toLowerCase();
  const isDup = data.facts.some(f => {
    const fl = f.text.toLowerCase();
    return fl === lower || fl.includes(lower) || lower.includes(fl);
  });

  if (!isDup) {
    data.facts.push({ text: fact, addedAt: Date.now() });
    // Keep max 30 facts
    if (data.facts.length > 30) {
      data.facts = data.facts.slice(-30);
    }
    saveUserData(userId, data);
  }
}

/**
 * Add gossip about a user (what someone else said about them).
 */
function addUserGossip(userId, fromUsername, gossip) {
  const data = loadUserData(userId);
  if (!data) return;

  data.gossip.push({
    from: fromUsername,
    text: gossip.slice(0, 200),
    time: Date.now(),
  });

  // Keep last 20 gossip entries
  if (data.gossip.length > 20) {
    data.gossip = data.gossip.slice(-20);
  }

  saveUserData(userId, data);
}

/**
 * Set a user's relationship label.
 */
function setUserRelationship(userId, relationship) {
  const data = loadUserData(userId);
  if (!data) return;
  data.relationship = relationship;
  saveUserData(userId, data);
}

/**
 * Add a nickname/label for a user.
 */
function addUserNickname(userId, nickname) {
  const data = loadUserData(userId);
  if (!data) return;
  if (!data.nicknames.includes(nickname)) {
    data.nicknames.push(nickname);
    if (data.nicknames.length > 10) data.nicknames = data.nicknames.slice(-10);
    saveUserData(userId, data);
  }
}

/**
 * Get a user's conversation summary for context.
 * Returns a compact string the AI can use.
 */
function getUserContextSummary(userId) {
  const data = loadUserData(userId);
  if (!data) return '';

  const parts = [];

  if (data.facts.length > 0) {
    parts.push('Known facts: ' + data.facts.slice(-8).map(f => f.text).join('; '));
  }

  if (data.nicknames.length > 0) {
    parts.push('Nicknames/labels: ' + data.nicknames.join(', '));
  }

  if (data.relationship !== 'acquaintance') {
    parts.push('Relationship: ' + data.relationship);
  }

  if (data.gossip.length > 0) {
    const recentGossip = data.gossip.slice(-3);
    parts.push('Gossip: ' + recentGossip.map(g => `${g.from} said "${g.text}"`).join('; '));
  }

  if (data.interests.length > 0) {
    parts.push('Interests: ' + data.interests.join(', '));
  }

  if (data.recentTopics.length > 0) {
    const recent = data.recentTopics.slice(-5).map(t => t.text.slice(0, 50));
    parts.push('Recent topics: ' + recent.join(' | '));
  }

  // Last few conversation exchanges
  if (data.conversationLog.length > 0) {
    const lastConvos = data.conversationLog.slice(-3);
    parts.push('Recent exchanges: ' + lastConvos.map(c => `"${c.user.slice(0, 40)}" → "${c.bot.slice(0, 40)}"`).join('; '));
  }

  return parts.join('\n');
}

/**
 * Get info about a specific user (for when someone asks "tell me about X").
 */
function getUserProfile(userId) {
  const data = loadUserData(userId);
  if (!data) return null;
  return {
    username: data.username,
    displayName: data.displayName,
    totalMessages: data.totalMessages,
    relationship: data.relationship,
    facts: data.facts.slice(-10).map(f => f.text),
    interests: data.interests,
    nicknames: data.nicknames,
    gossip: data.gossip.slice(-5),
    mood: data.mood,
    lastActive: data.lastActive,
  };
}

/**
 * Increment toxic escalation warning count.
 */
function warnUser(userId) {
  const data = loadUserData(userId);
  if (!data) return 0;
  data.warnings++;
  saveUserData(userId, data);
  return data.warnings;
}

module.exports = {
  getOrCreateUser,
  trackUserMessage: trackUserMessage,
  logUserConversation,
  addUserFact,
  addUserGossip,
  setUserRelationship,
  addUserNickname,
  getUserContextSummary,
  getUserProfile,
  warnUser,
  loadUserData,
  saveUserData,
};
