const Database = require('better-sqlite3');
const path = require('path');
const config = require('../config');

// Cache open DB connections per guild
const dbCache = new Map();

function getServerDb(guildId) {
  if (dbCache.has(guildId)) return dbCache.get(guildId);

  const dbPath = path.join(config.paths.servers, `${guildId}.db`);
  const db = new Database(dbPath);
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');

  db.exec(`
    -- Server-level config
    CREATE TABLE IF NOT EXISTS server_config (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL,
      updated_at INTEGER NOT NULL DEFAULT (unixepoch())
    );

    -- Chat channels where AI is active
    CREATE TABLE IF NOT EXISTS chat_channels (
      channel_id TEXT PRIMARY KEY,
      added_by TEXT,
      added_at INTEGER NOT NULL DEFAULT (unixepoch())
    );

    -- Banned users (from AI interaction)
    CREATE TABLE IF NOT EXISTS banned_users (
      user_id TEXT PRIMARY KEY,
      banned_by TEXT,
      reason TEXT DEFAULT '',
      banned_at INTEGER NOT NULL DEFAULT (unixepoch())
    );

    -- Ignored users (requested to be left alone)
    CREATE TABLE IF NOT EXISTS ignored_users (
      user_id TEXT PRIMARY KEY,
      ignored_at INTEGER NOT NULL DEFAULT (unixepoch())
    );

    -- Message log
    CREATE TABLE IF NOT EXISTS messages (
      message_id TEXT PRIMARY KEY,
      channel_id TEXT NOT NULL,
      user_id TEXT NOT NULL,
      username TEXT NOT NULL DEFAULT '',
      content TEXT NOT NULL DEFAULT '',
      is_bot_message INTEGER DEFAULT 0,
      reply_to_user_id TEXT,
      reply_to_message_id TEXT,
      created_at INTEGER NOT NULL DEFAULT (unixepoch())
    );

    CREATE INDEX IF NOT EXISTS idx_messages_channel ON messages(channel_id, created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_messages_user ON messages(user_id, created_at DESC);

    -- Per-server user stats
    CREATE TABLE IF NOT EXISTS user_stats (
      user_id TEXT PRIMARY KEY,
      username TEXT DEFAULT '',
      message_count INTEGER DEFAULT 0,
      reply_count INTEGER DEFAULT 0,
      replies_received INTEGER DEFAULT 0,
      mention_count INTEGER DEFAULT 0,
      mentions_received INTEGER DEFAULT 0,
      detected_gender TEXT DEFAULT 'unknown',
      roles_cache TEXT DEFAULT '[]',
      avg_message_hour REAL DEFAULT 12.0,
      first_seen INTEGER NOT NULL DEFAULT (unixepoch()),
      last_seen INTEGER NOT NULL DEFAULT (unixepoch())
    );

    -- Social graph (user-to-user interaction tracking)
    CREATE TABLE IF NOT EXISTS social_graph (
      user_a TEXT NOT NULL,
      user_b TEXT NOT NULL,
      interaction_count INTEGER DEFAULT 0,
      reply_count INTEGER DEFAULT 0,
      mention_count INTEGER DEFAULT 0,
      last_interaction INTEGER DEFAULT (unixepoch()),
      relationship_label TEXT DEFAULT '',
      PRIMARY KEY (user_a, user_b)
    );

    -- Server-level memories / observations
    CREATE TABLE IF NOT EXISTS server_memories (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      memory_type TEXT NOT NULL DEFAULT 'observation',
      content TEXT NOT NULL,
      channel_id TEXT,
      created_at INTEGER NOT NULL DEFAULT (unixepoch()),
      expires_at INTEGER
    );

    CREATE INDEX IF NOT EXISTS idx_server_memories_type ON server_memories(memory_type);

    -- Channel vibe tracking
    CREATE TABLE IF NOT EXISTS channel_vibes (
      channel_id TEXT PRIMARY KEY,
      current_vibe TEXT DEFAULT 'neutral',
      activity_level TEXT DEFAULT 'normal',
      dominant_topic TEXT DEFAULT 'general',
      last_updated INTEGER DEFAULT (unixepoch())
    );

    -- Conversation thread tracking
    CREATE TABLE IF NOT EXISTS conversation_threads (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      channel_id TEXT NOT NULL,
      topic TEXT DEFAULT '',
      started_by TEXT,
      participants TEXT DEFAULT '[]',
      message_count INTEGER DEFAULT 0,
      started_at INTEGER NOT NULL DEFAULT (unixepoch()),
      last_active INTEGER NOT NULL DEFAULT (unixepoch()),
      is_active INTEGER DEFAULT 1
    );

    CREATE INDEX IF NOT EXISTS idx_threads_channel ON conversation_threads(channel_id, is_active);

    -- Reaction log
    CREATE TABLE IF NOT EXISTS reaction_log (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      message_id TEXT NOT NULL,
      channel_id TEXT NOT NULL,
      user_id TEXT NOT NULL,
      emoji TEXT NOT NULL,
      target_user_id TEXT,
      created_at INTEGER NOT NULL DEFAULT (unixepoch())
    );

    CREATE INDEX IF NOT EXISTS idx_reactions_user ON reaction_log(user_id);

    -- Activity sessions (tracks when users come and go)
    CREATE TABLE IF NOT EXISTS activity_sessions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT NOT NULL,
      channel_id TEXT NOT NULL,
      started_at INTEGER NOT NULL DEFAULT (unixepoch()),
      last_message_at INTEGER NOT NULL DEFAULT (unixepoch()),
      message_count INTEGER DEFAULT 1,
      ended INTEGER DEFAULT 0
    );

    CREATE INDEX IF NOT EXISTS idx_activity_user ON activity_sessions(user_id, ended);

    -- Role snapshots (periodic role cache per user)
    CREATE TABLE IF NOT EXISTS role_snapshot (
      user_id TEXT PRIMARY KEY,
      roles_json TEXT DEFAULT '[]',
      is_staff INTEGER DEFAULT 0,
      staff_tier TEXT DEFAULT '',
      detected_gender TEXT DEFAULT 'unknown',
      updated_at INTEGER NOT NULL DEFAULT (unixepoch())
    );

    -- AI notes about users (high-signal observations)
    CREATE TABLE IF NOT EXISTS user_notes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT NOT NULL,
      content TEXT NOT NULL,
      note_type TEXT DEFAULT 'observation',
      confidence REAL DEFAULT 0.5,
      created_at INTEGER NOT NULL DEFAULT (unixepoch())
    );

    CREATE INDEX IF NOT EXISTS idx_user_notes ON user_notes(user_id, confidence DESC);

    -- Message analytics cache
    CREATE TABLE IF NOT EXISTS message_analytics (
      channel_id TEXT NOT NULL,
      period TEXT NOT NULL,
      message_count INTEGER DEFAULT 0,
      unique_users INTEGER DEFAULT 0,
      avg_length REAL DEFAULT 0,
      computed_at INTEGER NOT NULL DEFAULT (unixepoch()),
      PRIMARY KEY (channel_id, period)
    );

    -- Conversation sessions (tracks active bot-user conversations)
    CREATE TABLE IF NOT EXISTS conversation_sessions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      channel_id TEXT NOT NULL,
      user_id TEXT NOT NULL,
      started_at INTEGER NOT NULL DEFAULT (unixepoch()),
      last_message_at INTEGER NOT NULL DEFAULT (unixepoch()),
      message_count INTEGER DEFAULT 1,
      context_summary TEXT DEFAULT ''
    );

    CREATE INDEX IF NOT EXISTS idx_sessions_channel_user ON conversation_sessions(channel_id, user_id, last_message_at DESC);

    -- Engagement log (track proactive message success)
    CREATE TABLE IF NOT EXISTS engagement_log (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      channel_id TEXT NOT NULL,
      message_id TEXT,
      engagement_type TEXT NOT NULL DEFAULT 'proactive',
      sent_at INTEGER NOT NULL DEFAULT (unixepoch()),
      got_reply INTEGER DEFAULT 0,
      reply_count INTEGER DEFAULT 0
    );

    CREATE INDEX IF NOT EXISTS idx_engagement_channel ON engagement_log(channel_id, sent_at DESC);
  `);

  dbCache.set(guildId, db);
  return db;
}

// ─── Config Operations ─────────────────────────────────────────

function setServerConfig(guildId, key, value) {
  getServerDb(guildId).prepare(`
    INSERT INTO server_config (key, value, updated_at) VALUES (?, ?, unixepoch())
    ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = unixepoch()
  `).run(key, value);
}

function getServerConfig(guildId, key, defaultValue = null) {
  const row = getServerDb(guildId).prepare('SELECT value FROM server_config WHERE key = ?').get(key);
  return row ? row.value : defaultValue;
}

// ─── Channel Operations ────────────────────────────────────────

function addChatChannel(guildId, channelId, addedBy) {
  getServerDb(guildId).prepare(`
    INSERT OR REPLACE INTO chat_channels (channel_id, added_by) VALUES (?, ?)
  `).run(channelId, addedBy);
}

function removeChatChannel(guildId, channelId) {
  getServerDb(guildId).prepare('DELETE FROM chat_channels WHERE channel_id = ?').run(channelId);
}

function getChatChannels(guildId) {
  return getServerDb(guildId).prepare('SELECT channel_id FROM chat_channels').all().map((r) => r.channel_id);
}

function isChatChannel(guildId, channelId) {
  const channels = getChatChannels(guildId);
  // If no channels set, ALL channels are valid
  if (channels.length === 0) return true;
  return channels.includes(channelId);
}

// ─── Ban / Ignore Operations ───────────────────────────────────

function banUser(guildId, userId, bannedBy, reason = '') {
  getServerDb(guildId).prepare(`
    INSERT OR REPLACE INTO banned_users (user_id, banned_by, reason) VALUES (?, ?, ?)
  `).run(userId, bannedBy, reason);
}

function unbanUser(guildId, userId) {
  getServerDb(guildId).prepare('DELETE FROM banned_users WHERE user_id = ?').run(userId);
}

function isUserBanned(guildId, userId) {
  return !!getServerDb(guildId).prepare('SELECT 1 FROM banned_users WHERE user_id = ?').get(userId);
}

function ignoreUser(guildId, userId) {
  getServerDb(guildId).prepare('INSERT OR REPLACE INTO ignored_users (user_id) VALUES (?)').run(userId);
}

function unignoreUser(guildId, userId) {
  getServerDb(guildId).prepare('DELETE FROM ignored_users WHERE user_id = ?').run(userId);
}

function isUserIgnored(guildId, userId) {
  return !!getServerDb(guildId).prepare('SELECT 1 FROM ignored_users WHERE user_id = ?').get(userId);
}

// ─── Message Operations ────────────────────────────────────────

function logMessage(guildId, { messageId, channelId, userId, username, content, isBotMessage, replyToUserId, replyToMessageId }) {
  getServerDb(guildId).prepare(`
    INSERT OR REPLACE INTO messages (message_id, channel_id, user_id, username, content, is_bot_message, reply_to_user_id, reply_to_message_id)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `).run(messageId, channelId, userId, username, content, isBotMessage ? 1 : 0, replyToUserId || null, replyToMessageId || null);
}

function getRecentMessages(guildId, channelId, limit = 50) {
  return getServerDb(guildId).prepare(`
    SELECT * FROM messages WHERE channel_id = ? ORDER BY created_at DESC LIMIT ?
  `).all(channelId, limit).reverse(); // Reverse to get chronological order
}

function getRecentMessagesAllChannels(guildId, limit = 100) {
  return getServerDb(guildId).prepare(`
    SELECT * FROM messages ORDER BY created_at DESC LIMIT ?
  `).all(limit).reverse();
}

// ─── User Stats ────────────────────────────────────────────────

function getUserStats(guildId, userId) {
  return getServerDb(guildId).prepare('SELECT * FROM user_stats WHERE user_id = ?').get(userId);
}

function updateUserStats(guildId, userId, updates) {
  const db = getServerDb(guildId);

  // Ensure user exists
  db.prepare(`
    INSERT OR IGNORE INTO user_stats (user_id) VALUES (?)
  `).run(userId);

  if (updates.incrementMessages) {
    db.prepare(`
      UPDATE user_stats SET message_count = message_count + 1, last_seen = unixepoch() WHERE user_id = ?
    `).run(userId);
  }
  if (updates.incrementReplies) {
    db.prepare('UPDATE user_stats SET reply_count = reply_count + 1 WHERE user_id = ?').run(userId);
  }
  if (updates.incrementRepliesReceived) {
    db.prepare('UPDATE user_stats SET replies_received = replies_received + 1 WHERE user_id = ?').run(userId);
  }
  if (updates.incrementMentions) {
    db.prepare('UPDATE user_stats SET mention_count = mention_count + 1 WHERE user_id = ?').run(userId);
  }
  if (updates.incrementMentionsReceived) {
    db.prepare('UPDATE user_stats SET mentions_received = mentions_received + 1 WHERE user_id = ?').run(userId);
  }
  if (updates.detectedGender) {
    db.prepare('UPDATE user_stats SET detected_gender = ? WHERE user_id = ?').run(updates.detectedGender, userId);
  }
  if (updates.rolesCache) {
    db.prepare('UPDATE user_stats SET roles_cache = ? WHERE user_id = ?').run(JSON.stringify(updates.rolesCache), userId);
  }
  if (updates.avgHour !== undefined) {
    db.prepare('UPDATE user_stats SET avg_message_hour = ? WHERE user_id = ?').run(updates.avgHour, userId);
  }
  if (updates.username) {
    db.prepare('UPDATE user_stats SET username = ? WHERE user_id = ?').run(updates.username, userId);
  }
}

function getTopServerUsers(guildId, limit = 10) {
  return getServerDb(guildId).prepare(`
    SELECT * FROM user_stats ORDER BY message_count DESC LIMIT ?
  `).all(limit);
}

function getMostRepliedUsers(guildId, limit = 5) {
  return getServerDb(guildId).prepare(`
    SELECT *, CASE WHEN message_count > 0 THEN CAST(replies_received AS REAL) / message_count ELSE 0 END AS reply_rate
    FROM user_stats WHERE message_count > 5
    ORDER BY replies_received DESC LIMIT ?
  `).all(limit);
}

function getMostIgnoredUsers(guildId, limit = 5) {
  return getServerDb(guildId).prepare(`
    SELECT *, CASE WHEN message_count > 0 THEN CAST(replies_received AS REAL) / message_count ELSE 0 END AS reply_rate
    FROM user_stats WHERE message_count > 10
    ORDER BY reply_rate ASC LIMIT ?
  `).all(limit);
}

// ─── Social Graph ──────────────────────────────────────────────

function updateSocialGraph(guildId, userA, userB, type) {
  const db = getServerDb(guildId);
  db.prepare(`
    INSERT INTO social_graph (user_a, user_b, interaction_count, reply_count, mention_count, last_interaction)
    VALUES (?, ?, 1, ?, ?, unixepoch())
    ON CONFLICT(user_a, user_b) DO UPDATE SET
      interaction_count = interaction_count + 1,
      reply_count = reply_count + CASE WHEN ? = 'reply' THEN 1 ELSE 0 END,
      mention_count = mention_count + CASE WHEN ? = 'mention' THEN 1 ELSE 0 END,
      last_interaction = unixepoch()
  `).run(
    userA, userB,
    type === 'reply' ? 1 : 0,
    type === 'mention' ? 1 : 0,
    type, type
  );
}

function getStrongestPairs(guildId, limit = 10) {
  return getServerDb(guildId).prepare(`
    SELECT * FROM social_graph ORDER BY interaction_count DESC LIMIT ?
  `).all(limit);
}

// ─── Server Memories ───────────────────────────────────────────

function addServerMemory(guildId, { type, content, channelId, expiresInSec }) {
  const expiresAt = expiresInSec ? Math.floor(Date.now() / 1000) + expiresInSec : null;
  getServerDb(guildId).prepare(`
    INSERT INTO server_memories (memory_type, content, channel_id, expires_at) VALUES (?, ?, ?, ?)
  `).run(type, content, channelId || null, expiresAt);
}

function getServerMemories(guildId, channelId, limit = 15) {
  if (channelId) {
    return getServerDb(guildId).prepare(`
      SELECT * FROM server_memories
      WHERE (channel_id = ? OR channel_id IS NULL) AND (expires_at IS NULL OR expires_at > unixepoch())
      ORDER BY created_at DESC LIMIT ?
    `).all(channelId, limit);
  }
  return getServerDb(guildId).prepare(`
    SELECT * FROM server_memories
    WHERE expires_at IS NULL OR expires_at > unixepoch()
    ORDER BY created_at DESC LIMIT ?
  `).all(limit);
}

// ─── Channel Vibes ─────────────────────────────────────────────

function updateChannelVibe(guildId, channelId, vibe, activity, topic) {
  getServerDb(guildId).prepare(`
    INSERT INTO channel_vibes (channel_id, current_vibe, activity_level, dominant_topic, last_updated)
    VALUES (?, ?, ?, ?, unixepoch())
    ON CONFLICT(channel_id) DO UPDATE SET
      current_vibe = excluded.current_vibe,
      activity_level = excluded.activity_level,
      dominant_topic = excluded.dominant_topic,
      last_updated = unixepoch()
  `).run(channelId, vibe || 'neutral', activity || 'normal', topic || 'general');
}

function getChannelVibe(guildId, channelId) {
  return getServerDb(guildId).prepare('SELECT * FROM channel_vibes WHERE channel_id = ?').get(channelId);
}

// ─── Conversation Threads ──────────────────────────────────────

function startConversationThread(guildId, channelId, topic, startedBy) {
  // Close any existing active thread in this channel
  getServerDb(guildId).prepare(`
    UPDATE conversation_threads SET is_active = 0 WHERE channel_id = ? AND is_active = 1 AND last_active < unixepoch() - 600
  `).run(channelId);

  const result = getServerDb(guildId).prepare(`
    INSERT INTO conversation_threads (channel_id, topic, started_by, participants) VALUES (?, ?, ?, ?)
  `).run(channelId, topic || '', startedBy || '', JSON.stringify(startedBy ? [startedBy] : []));

  return result.lastInsertRowid;
}

function getActiveThread(guildId, channelId) {
  return getServerDb(guildId).prepare(`
    SELECT * FROM conversation_threads WHERE channel_id = ? AND is_active = 1
    ORDER BY last_active DESC LIMIT 1
  `).get(channelId);
}

function updateThread(guildId, threadId, userId) {
  const thread = getServerDb(guildId).prepare('SELECT * FROM conversation_threads WHERE id = ?').get(threadId);
  if (!thread) return;

  const participants = JSON.parse(thread.participants || '[]');
  if (!participants.includes(userId)) participants.push(userId);

  getServerDb(guildId).prepare(`
    UPDATE conversation_threads SET
      message_count = message_count + 1,
      last_active = unixepoch(),
      participants = ?
    WHERE id = ?
  `).run(JSON.stringify(participants), threadId);
}

// ─── Reaction Log ──────────────────────────────────────────────

function logReaction(guildId, { messageId, channelId, userId, emoji, targetUserId }) {
  getServerDb(guildId).prepare(`
    INSERT INTO reaction_log (message_id, channel_id, user_id, emoji, target_user_id) VALUES (?, ?, ?, ?, ?)
  `).run(messageId, channelId, userId, emoji, targetUserId || null);
}

function getTopReactedUsers(guildId, limit = 5) {
  return getServerDb(guildId).prepare(`
    SELECT target_user_id AS user_id, COUNT(*) AS reaction_count
    FROM reaction_log WHERE target_user_id IS NOT NULL
    GROUP BY target_user_id ORDER BY reaction_count DESC LIMIT ?
  `).all(limit);
}

// ─── Activity Sessions ────────────────────────────────────────

function trackActivitySession(guildId, userId, channelId) {
  const db = getServerDb(guildId);
  // Check for existing active session
  const existing = db.prepare(`
    SELECT * FROM activity_sessions
    WHERE user_id = ? AND channel_id = ? AND ended = 0 AND last_message_at > unixepoch() - 600
    ORDER BY last_message_at DESC LIMIT 1
  `).get(userId, channelId);

  if (existing) {
    db.prepare(`
      UPDATE activity_sessions SET last_message_at = unixepoch(), message_count = message_count + 1 WHERE id = ?
    `).run(existing.id);
    return existing.id;
  }

  // Close old sessions
  db.prepare(`
    UPDATE activity_sessions SET ended = 1 WHERE user_id = ? AND ended = 0
  `).run(userId);

  const result = db.prepare(`
    INSERT INTO activity_sessions (user_id, channel_id) VALUES (?, ?)
  `).run(userId, channelId);

  return result.lastInsertRowid;
}

function getUserActivityPattern(guildId, userId) {
  return getServerDb(guildId).prepare(`
    SELECT channel_id,
           COUNT(*) AS session_count,
           SUM(message_count) AS total_messages,
           AVG(last_message_at - started_at) AS avg_session_duration
    FROM activity_sessions WHERE user_id = ?
    GROUP BY channel_id ORDER BY total_messages DESC LIMIT 5
  `).all(userId);
}

// ─── Role Snapshots ────────────────────────────────────────────

function updateRoleSnapshot(guildId, userId, rolesJson, isStaff, staffTier, detectedGender) {
  getServerDb(guildId).prepare(`
    INSERT INTO role_snapshot (user_id, roles_json, is_staff, staff_tier, detected_gender, updated_at)
    VALUES (?, ?, ?, ?, ?, unixepoch())
    ON CONFLICT(user_id) DO UPDATE SET
      roles_json = excluded.roles_json,
      is_staff = excluded.is_staff,
      staff_tier = excluded.staff_tier,
      detected_gender = excluded.detected_gender,
      updated_at = unixepoch()
  `).run(userId, rolesJson, isStaff ? 1 : 0, staffTier || '', detectedGender || 'unknown');
}

function getRoleSnapshot(guildId, userId) {
  return getServerDb(guildId).prepare('SELECT * FROM role_snapshot WHERE user_id = ?').get(userId);
}

// ─── User Notes ────────────────────────────────────────────────

function addUserNote(guildId, userId, content, noteType = 'observation', confidence = 0.5) {
  // Prevent duplicate notes
  const existing = getServerDb(guildId).prepare(`
    SELECT 1 FROM user_notes WHERE user_id = ? AND content = ?
  `).get(userId, content);
  if (existing) return;

  getServerDb(guildId).prepare(`
    INSERT INTO user_notes (user_id, content, note_type, confidence) VALUES (?, ?, ?, ?)
  `).run(userId, content, noteType, confidence);
}

function getUserNotes(guildId, userId, limit = 10) {
  return getServerDb(guildId).prepare(`
    SELECT * FROM user_notes WHERE user_id = ? ORDER BY confidence DESC, created_at DESC LIMIT ?
  `).all(userId, limit);
}

function getHighConfidenceNotes(guildId, userId, minConfidence = 0.7) {
  return getServerDb(guildId).prepare(`
    SELECT * FROM user_notes WHERE user_id = ? AND confidence >= ? ORDER BY confidence DESC
  `).all(userId, minConfidence);
}

// ─── Message Analytics ─────────────────────────────────────────

function getMessageVelocity(guildId, channelId, windowSeconds = 300) {
  const result = getServerDb(guildId).prepare(`
    SELECT COUNT(*) AS count FROM messages
    WHERE channel_id = ? AND created_at > unixepoch() - ?
  `).get(channelId, windowSeconds);
  return result ? result.count : 0;
}

function getUniqueActiveUsers(guildId, channelId, windowSeconds = 600) {
  return getServerDb(guildId).prepare(`
    SELECT DISTINCT user_id, username FROM messages
    WHERE channel_id = ? AND created_at > unixepoch() - ? AND is_bot_message = 0
  `).all(channelId, windowSeconds);
}

function getIgnoredMessages(guildId, channelId, limit = 5) {
  // Messages that have no replies within 5 minutes
  return getServerDb(guildId).prepare(`
    SELECT m.* FROM messages m
    WHERE m.channel_id = ? AND m.is_bot_message = 0
      AND m.created_at > unixepoch() - 1800
      AND NOT EXISTS (
        SELECT 1 FROM messages r
        WHERE r.channel_id = m.channel_id
          AND r.reply_to_message_id = m.message_id
      )
    ORDER BY m.created_at DESC LIMIT ?
  `).all(channelId, limit);
}

// ─── Conversation Sessions ─────────────────────────────────────

function getActiveSession(guildId, channelId, userId) {
  // Session is active if last message was within 10 minutes
  return getServerDb(guildId).prepare(`
    SELECT * FROM conversation_sessions
    WHERE channel_id = ? AND user_id = ? AND last_message_at > unixepoch() - 600
    ORDER BY last_message_at DESC LIMIT 1
  `).get(channelId, userId);
}

function startSession(guildId, channelId, userId, contextSummary = '') {
  return getServerDb(guildId).prepare(`
    INSERT INTO conversation_sessions (channel_id, user_id, context_summary)
    VALUES (?, ?, ?)
  `).run(channelId, userId, contextSummary);
}

function updateSession(guildId, sessionId, contextSummary) {
  getServerDb(guildId).prepare(`
    UPDATE conversation_sessions
    SET last_message_at = unixepoch(), message_count = message_count + 1, context_summary = ?
    WHERE id = ?
  `).run(contextSummary, sessionId);
}

function expireOldSessions(guildId) {
  // Delete sessions older than 1 hour
  getServerDb(guildId).prepare(`
    DELETE FROM conversation_sessions WHERE last_message_at < unixepoch() - 3600
  `).run();
}

// ─── Engagement Log ────────────────────────────────────────────

function logEngagement(guildId, channelId, messageId, engagementType = 'proactive') {
  getServerDb(guildId).prepare(`
    INSERT INTO engagement_log (channel_id, message_id, engagement_type)
    VALUES (?, ?, ?)
  `).run(channelId, messageId, engagementType);
}

function markEngagementReply(guildId, channelId, botMessageId) {
  getServerDb(guildId).prepare(`
    UPDATE engagement_log SET got_reply = 1, reply_count = reply_count + 1
    WHERE channel_id = ? AND message_id = ? AND sent_at > unixepoch() - 1800
  `).run(channelId, botMessageId);
}

function getEngagementSuccessRate(guildId, days = 7) {
  const result = getServerDb(guildId).prepare(`
    SELECT
      COUNT(*) AS total,
      SUM(CASE WHEN got_reply = 1 THEN 1 ELSE 0 END) AS replied
    FROM engagement_log
    WHERE sent_at > unixepoch() - (? * 86400)
  `).get(days);
  if (!result || result.total === 0) return { total: 0, replied: 0, rate: 0 };
  return { total: result.total, replied: result.replied, rate: Math.round((result.replied / result.total) * 100) };
}

// ─── Cleanup ───────────────────────────────────────────────────

function cleanupOldMessages(guildId, retentionDays = 30) {
  const cutoff = retentionDays * 86400;
  const result = getServerDb(guildId).prepare(`
    DELETE FROM messages WHERE created_at < unixepoch() - ?
  `).run(cutoff);
  return result.changes;
}

module.exports = {
  getServerDb,
  // Config
  setServerConfig,
  getServerConfig,
  // Channels
  addChatChannel,
  removeChatChannel,
  getChatChannels,
  isChatChannel,
  // Bans / Ignores
  banUser,
  unbanUser,
  isUserBanned,
  ignoreUser,
  unignoreUser,
  isUserIgnored,
  // Messages
  logMessage,
  getRecentMessages,
  getRecentMessagesAllChannels,
  // User Stats
  getUserStats,
  updateUserStats,
  getTopServerUsers,
  getMostRepliedUsers,
  getMostIgnoredUsers,
  // Social Graph
  updateSocialGraph,
  getStrongestPairs,
  // Server Memories
  addServerMemory,
  getServerMemories,
  // Channel Vibes
  updateChannelVibe,
  getChannelVibe,
  // Conversation Threads
  startConversationThread,
  getActiveThread,
  updateThread,
  // Reactions
  logReaction,
  getTopReactedUsers,
  // Activity Sessions
  trackActivitySession,
  getUserActivityPattern,
  // Role Snapshots
  updateRoleSnapshot,
  getRoleSnapshot,
  // User Notes
  addUserNote,
  getUserNotes,
  getHighConfidenceNotes,
  // Analytics
  getMessageVelocity,
  getUniqueActiveUsers,
  getIgnoredMessages,
  // Conversation Sessions
  getActiveSession,
  startSession,
  updateSession,
  expireOldSessions,
  // Engagement Log
  logEngagement,
  markEngagementReply,
  getEngagementSuccessRate,
  // Cleanup
  cleanupOldMessages,
};
