const Database = require('better-sqlite3');
const config = require('../config');

let db;

function initGlobalDb() {
  db = new Database(config.paths.globalDb);
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');

  db.exec(`
    -- Global user profiles (cross-server)
    CREATE TABLE IF NOT EXISTS users (
      user_id TEXT PRIMARY KEY,
      username TEXT NOT NULL DEFAULT '',
      display_name TEXT DEFAULT '',
      detected_gender TEXT DEFAULT 'unknown',
      preferred_language TEXT DEFAULT 'en',
      personality_summary TEXT DEFAULT '',
      interests TEXT DEFAULT '[]',
      first_seen INTEGER NOT NULL DEFAULT (unixepoch()),
      total_messages INTEGER DEFAULT 0,
      last_active INTEGER DEFAULT (unixepoch()),
      vibe TEXT DEFAULT 'neutral',
      is_bot INTEGER DEFAULT 0
    );

    -- Long-term memory entries per user (global)
    CREATE TABLE IF NOT EXISTS user_memories (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT NOT NULL,
      memory_type TEXT NOT NULL DEFAULT 'fact',
      content TEXT NOT NULL,
      importance INTEGER DEFAULT 5,
      created_at INTEGER NOT NULL DEFAULT (unixepoch()),
      last_recalled INTEGER DEFAULT (unixepoch()),
      recall_count INTEGER DEFAULT 0,
      FOREIGN KEY (user_id) REFERENCES users(user_id)
    );

    CREATE INDEX IF NOT EXISTS idx_user_memories_user ON user_memories(user_id);
    CREATE INDEX IF NOT EXISTS idx_user_memories_importance ON user_memories(importance DESC);
  `);

  return db;
}

function getGlobalDb() {
  if (!db) initGlobalDb();
  return db;
}

// ─── User Operations ─────────────────────────────────────────────

function upsertUser(userId, username, displayName = '', isBot = false) {
  const d = getGlobalDb();
  d.prepare(`
    INSERT INTO users (user_id, username, display_name, is_bot, last_active)
    VALUES (?, ?, ?, ?, unixepoch())
    ON CONFLICT(user_id) DO UPDATE SET
      username = excluded.username,
      display_name = CASE WHEN excluded.display_name != '' THEN excluded.display_name ELSE users.display_name END,
      last_active = unixepoch()
  `).run(userId, username, displayName, isBot ? 1 : 0);
}

function getUser(userId) {
  return getGlobalDb().prepare('SELECT * FROM users WHERE user_id = ?').get(userId);
}

function incrementUserMessages(userId) {
  getGlobalDb().prepare(`
    UPDATE users SET total_messages = total_messages + 1, last_active = unixepoch() WHERE user_id = ?
  `).run(userId);
}

function updateUserField(userId, field, value) {
  const allowed = ['detected_gender', 'preferred_language', 'personality_summary', 'interests', 'vibe'];
  if (!allowed.includes(field)) return;
  getGlobalDb().prepare(`UPDATE users SET ${field} = ? WHERE user_id = ?`).run(value, userId);
}

function getInactiveUsers(thresholdSeconds = 86400) {
  return getGlobalDb().prepare(`
    SELECT * FROM users WHERE last_active < unixepoch() - ? AND is_bot = 0 AND total_messages > 5
    ORDER BY total_messages DESC LIMIT 10
  `).all(thresholdSeconds);
}

function getTopUsers(limit = 10) {
  return getGlobalDb().prepare(`
    SELECT * FROM users WHERE is_bot = 0 ORDER BY total_messages DESC LIMIT ?
  `).all(limit);
}

// ─── Memory Operations ───────────────────────────────────────────

function addUserMemory(userId, content, type = 'fact', importance = 5) {
  getGlobalDb().prepare(`
    INSERT INTO user_memories (user_id, memory_type, content, importance)
    VALUES (?, ?, ?, ?)
  `).run(userId, type, content, importance);
}

function getUserMemories(userId, limit = 20) {
  return getGlobalDb().prepare(`
    SELECT * FROM user_memories WHERE user_id = ?
    ORDER BY importance DESC, last_recalled DESC LIMIT ?
  `).all(userId, limit);
}

function recallMemory(memoryId) {
  getGlobalDb().prepare(`
    UPDATE user_memories SET recall_count = recall_count + 1, last_recalled = unixepoch() WHERE id = ?
  `).run(memoryId);
}

function pruneOldMemories(userId, keepCount = 50) {
  getGlobalDb().prepare(`
    DELETE FROM user_memories WHERE user_id = ? AND id NOT IN (
      SELECT id FROM user_memories WHERE user_id = ?
      ORDER BY importance DESC, last_recalled DESC LIMIT ?
    )
  `).run(userId, userId, keepCount);
}

module.exports = {
  initGlobalDb,
  getGlobalDb,
  upsertUser,
  getUser,
  incrementUserMessages,
  updateUserField,
  getInactiveUsers,
  getTopUsers,
  addUserMemory,
  getUserMemories,
  recallMemory,
  pruneOldMemories,
};
