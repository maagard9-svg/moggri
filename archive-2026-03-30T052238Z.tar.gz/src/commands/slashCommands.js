const { SlashCommandBuilder, REST, Routes } = require('discord.js');
const config = require('../config');

const slashCommandDefinitions = [
  new SlashCommandBuilder()
    .setName('help')
    .setDescription('Show all StarkLink commands'),

  new SlashCommandBuilder()
    .setName('serverinfo')
    .setDescription('View detailed server information'),

  new SlashCommandBuilder()
    .setName('profile')
    .setDescription('View a user\'s AI profile')
    .addUserOption(opt => opt.setName('user').setDescription('User to view (default: yourself)').setRequired(false)),

  new SlashCommandBuilder()
    .setName('stats')
    .setDescription('View server AI stats'),

  new SlashCommandBuilder()
    .setName('social')
    .setDescription('View social connections')
    .addUserOption(opt => opt.setName('user').setDescription('User to view connections for').setRequired(false)),

  new SlashCommandBuilder()
    .setName('vibes')
    .setDescription('Check the current channel vibe'),

  new SlashCommandBuilder()
    .setName('status')
    .setDescription('View bot status and uptime'),

  new SlashCommandBuilder()
    .setName('leaderboard')
    .setDescription('View the server message leaderboard'),

  new SlashCommandBuilder()
    .setName('whois')
    .setDescription('Get detailed info about a user')
    .addUserOption(opt => opt.setName('user').setDescription('User to look up').setRequired(false)),

  new SlashCommandBuilder()
    .setName('dashboard')
    .setDescription('Owner-only bot dashboard'),
];

async function registerSlashCommands(client) {
  try {
    const rest = new REST({ version: '10' }).setToken(config.discord.token);
    const commands = slashCommandDefinitions.map(cmd => cmd.toJSON());

    console.log(`[SLASH] Registering ${commands.length} slash commands...`);
    await rest.put(
      Routes.applicationCommands(client.user.id),
      { body: commands },
    );
    console.log(`[SLASH] Successfully registered ${commands.length} slash commands`);
  } catch (err) {
    console.error('[SLASH] Failed to register slash commands:', err.message);
  }
}

module.exports = { registerSlashCommands, slashCommandDefinitions };
