const config = require('../config');
const { successEmbed, errorEmbed, helpEmbed, statsEmbed, userProfileEmbed, socialGraphEmbed, infoEmbed } = require('../utils/embeds');
const { addChatChannel, removeChatChannel, getChatChannels, banUser, unbanUser, setServerConfig, getServerConfig, getTopServerUsers, getStrongestPairs, getChannelVibe, getUserStats, isUserBanned, getUserNotes } = require('../database/server');
const { getUser, getUserMemories, getTopUsers } = require('../database/global');
const { getUserBehaviorProfile } = require('../analysis/behavior');
const { analyzeChannelVibe } = require('../analysis/language');
const { analyzeServerRoles, analyzeUserRoles, buildRoleContextForAI } = require('../analysis/roles');
const { getUserConnections } = require('../analysis/socialGraph');
const { formatNumber, formatIST, getISTHour } = require('../utils/helpers');

const commands = new Map();

// --- $help ---

commands.set('help', {
  description: 'Show all commands',
  permissions: [],
  execute: async (message, args) => {
    await message.reply({ embeds: [helpEmbed(config.discord.prefix)] });
  },
});

// --- $setchatchannel ---

commands.set('setchatchannel', {
  description: 'Add or remove AI chat channels',
  permissions: ['ManageChannels'],
  execute: async (message, args) => {
    const action = args[0]?.toLowerCase();

    if (!action || !['add', 'remove', 'list'].includes(action)) {
      return message.reply({
        embeds: [errorEmbed('Usage', `\`${config.discord.prefix}setchatchannel add/remove/list\`\nRun in the channel you want to add/remove.`)],
      });
    }

    const guildId = message.guild.id;

    if (action === 'list') {
      const channels = getChatChannels(guildId);
      const desc = channels.length > 0
        ? channels.map((id) => `<#${id}>`).join('\n')
        : 'No specific channels set (AI active in all channels)';
      return message.reply({ embeds: [infoEmbed('Chat Channels', desc)] });
    }

    if (action === 'add') {
      addChatChannel(guildId, message.channel.id, message.author.id);
      return message.reply({
        embeds: [successEmbed('Channel Added', `AI is now active in <#${message.channel.id}>`)],
      });
    }

    if (action === 'remove') {
      removeChatChannel(guildId, message.channel.id);
      return message.reply({
        embeds: [successEmbed('Channel Removed', `AI removed from <#${message.channel.id}>`)],
      });
    }
  },
});

// --- $setwelcomechannel ---

commands.set('setwelcomechannel', {
  description: 'Set welcome channel for new members',
  permissions: ['ManageChannels'],
  execute: async (message, args) => {
    const action = args[0]?.toLowerCase();
    const guildId = message.guild.id;

    if (action === 'off' || action === 'disable' || action === 'remove') {
      setServerConfig(guildId, 'welcome_channel', '');
      return message.reply({ embeds: [successEmbed('Welcome Disabled', 'Welcome messages are now disabled.')] });
    }

    // Use mentioned channel or current channel
    const targetChannel = message.mentions.channels.first() || message.channel;
    setServerConfig(guildId, 'welcome_channel', targetChannel.id);
    return message.reply({
      embeds: [successEmbed('Welcome Channel Set', `New members will be welcomed in <#${targetChannel.id}> with human-like messages!`)],
    });
  },
});

// --- $enable / $disable ---

commands.set('enable', {
  description: 'Enable AI in this server',
  permissions: ['ManageGuild'],
  execute: async (message) => {
    setServerConfig(message.guild.id, 'ai_enabled', 'true');
    await message.reply({ embeds: [successEmbed('AI Enabled', `${config.bot.name} is now active in this server.`)] });
  },
});

commands.set('disable', {
  description: 'Disable AI in this server',
  permissions: ['ManageGuild'],
  execute: async (message) => {
    setServerConfig(message.guild.id, 'ai_enabled', 'false');
    await message.reply({ embeds: [successEmbed('AI Disabled', `${config.bot.name} is now silent in this server.`)] });
  },
});

// --- $banai / $unbanai ---

commands.set('banai', {
  description: 'Ban a user from using AI',
  permissions: ['ManageMessages'],
  execute: async (message, args) => {
    const target = message.mentions.users.first();
    if (!target) return message.reply({ embeds: [errorEmbed('Usage', `\`${config.discord.prefix}banai @user\``)] });
    if (target.bot) return message.reply({ embeds: [errorEmbed('Error', 'Cannot ban a bot from AI.')] });

    banUser(message.guild.id, target.id, message.author.id, args.slice(1).join(' '));
    await message.reply({
      embeds: [successEmbed('User Banned', `<@${target.id}> can no longer interact with ${config.bot.name}.`)],
    });
  },
});

commands.set('unbanai', {
  description: 'Unban a user from using AI',
  permissions: ['ManageMessages'],
  execute: async (message) => {
    const target = message.mentions.users.first();
    if (!target) return message.reply({ embeds: [errorEmbed('Usage', `\`${config.discord.prefix}unbanai @user\``)] });

    unbanUser(message.guild.id, target.id);
    await message.reply({
      embeds: [successEmbed('User Unbanned', `<@${target.id}> can now interact with ${config.bot.name} again.`)],
    });
  },
});

// --- $profile ---

commands.set('profile', {
  description: 'View AI profile of a user',
  permissions: [],
  execute: async (message) => {
    const target = message.mentions.users.first() || message.author;
    if (target.bot) return message.reply({ embeds: [errorEmbed('Error', 'Cannot view profile of a bot.')] });

    const user = getUser(target.id);
    if (!user) return message.reply({ embeds: [errorEmbed('Not Found', 'No data for this user yet.')] });

    const stats = getUserStats(message.guild.id, target.id);
    const memories = getUserMemories(target.id, 10);
    const behavior = getUserBehaviorProfile(message.guild.id, target.id);
    const notes = getUserNotes(message.guild.id, target.id, 5);

    const embed = userProfileEmbed(user, stats, memories);

    if (behavior) {
      embed.addFields(
        { name: 'Activity Pattern', value: behavior.activityPattern, inline: true },
        { name: 'Influence', value: behavior.influence, inline: true },
        { name: 'Engagement', value: behavior.engagementLevel, inline: true },
      );
    }

    if (notes.length > 0) {
      const noteText = notes.map((n) => `• ${n.content}`).join('\n');
      embed.addFields({ name: 'AI Observations', value: noteText, inline: false });
    }

    await message.reply({ embeds: [embed] });
  },
});

// --- $stats ---

commands.set('stats', {
  description: 'Server AI stats',
  permissions: [],
  execute: async (message) => {
    const guildId = message.guild.id;
    const topUsers = getTopServerUsers(guildId, 10);
    const enabled = getServerConfig(guildId, 'ai_enabled', 'true') === 'true';
    const channels = getChatChannels(guildId);
    const welcomeChannel = getServerConfig(guildId, 'welcome_channel');

    // Filter out bots from top users
    const humanUsers = topUsers.filter((u) => {
      const member = message.guild.members.cache.get(u.user_id);
      return !member?.user?.bot;
    });

    const topList = humanUsers.length > 0
      ? humanUsers.slice(0, 10).map((u, i) => `**${i + 1}.** <@${u.user_id}> — ${formatNumber(u.message_count)} msgs`).join('\n')
      : 'No data yet';

    const embed = statsEmbed('Server Stats', [
      { name: 'AI Status', value: enabled ? '🟢 Active' : '🔴 Disabled', inline: true },
      { name: 'Chat Channels', value: channels.length > 0 ? channels.map((id) => `<#${id}>`).join(', ') : 'All', inline: true },
      { name: 'Members', value: formatNumber(message.guild.memberCount), inline: true },
      { name: 'Welcome', value: welcomeChannel ? `<#${welcomeChannel}>` : 'Disabled', inline: true },
      { name: 'Time (IST)', value: formatIST(), inline: true },
      { name: 'Most Active Users', value: topList, inline: false },
    ]);

    await message.reply({ embeds: [embed] });
  },
});

// --- $social ---

commands.set('social', {
  description: 'View social connections',
  permissions: [],
  execute: async (message) => {
    const target = message.mentions.users.first();
    if (target) {
      if (target.bot) return message.reply({ embeds: [errorEmbed('Error', 'Bots don\'t have social connections.')] });
      const connections = getUserConnections(message.guild.id, target.id);
      if (connections.length === 0) {
        return message.reply({ embeds: [infoEmbed('Social Graph', `No social data for <@${target.id}> yet.`)] });
      }
      const lines = connections.map((c, i) =>
        `**${i + 1}.** <@${c.partnerId}> — ${c.interactions} interactions, ${c.replies} replies`
      );
      const embed = infoEmbed(`Social Connections — ${target.username}`, lines.join('\n'));
      return message.reply({ embeds: [embed] });
    }

    const pairs = getStrongestPairs(message.guild.id, 10);
    await message.reply({ embeds: [socialGraphEmbed(pairs, `Social Graph — ${message.guild.name}`)] });
  },
});

// --- $vibes ---

commands.set('vibes', {
  description: 'Current channel vibe analysis',
  permissions: [],
  execute: async (message) => {
    const { getRecentMessages } = require('../database/server');
    const recentMsgs = getRecentMessages(message.guild.id, message.channel.id, 30);
    const vibeData = await analyzeChannelVibe(message.guild.id, message.channel.id, recentMsgs);

    if (!vibeData) {
      return message.reply({ embeds: [infoEmbed('Channel Vibe', 'Not enough data to analyze yet.')] });
    }

    const embed = statsEmbed(`#${message.channel.name} Vibes`, [
      { name: 'Mood', value: vibeData.vibe || 'neutral', inline: true },
      { name: 'Activity', value: vibeData.activity || 'normal', inline: true },
      { name: 'Topic', value: vibeData.topic || 'general chat', inline: true },
    ]);

    await message.reply({ embeds: [embed] });
  },
});

// --- $memory ---

commands.set('memory', {
  description: 'View stored memories about a user',
  permissions: [],
  execute: async (message) => {
    const target = message.mentions.users.first() || message.author;
    if (target.bot) return message.reply({ embeds: [errorEmbed('Error', 'Bots don\'t have memories.')] });

    const memories = getUserMemories(target.id, 15);

    if (memories.length === 0) {
      return message.reply({ embeds: [infoEmbed('Memories', `No memories stored for <@${target.id}> yet.`)] });
    }

    const memList = memories.map((m, i) => `**${i + 1}.** ${m.content} *(${m.memory_type})*`).join('\n');
    const embed = infoEmbed(`Memories — ${target.username}`, memList);
    await message.reply({ embeds: [embed] });
  },
});

// --- $forgetme ---

commands.set('forgetme', {
  description: 'Clear your memory data',
  permissions: [],
  execute: async (message) => {
    const { getGlobalDb } = require('../database/global');
    getGlobalDb().prepare('DELETE FROM user_memories WHERE user_id = ?').run(message.author.id);
    getGlobalDb().prepare("UPDATE users SET personality_summary = '', interests = '[]', vibe = 'neutral' WHERE user_id = ?").run(message.author.id);
    await message.reply({ embeds: [successEmbed('Memory Cleared', 'All memories about you have been wiped. Fresh start!')] });
  },
});

// --- $status ---

commands.set('status', {
  description: 'Bot status info',
  permissions: [],
  execute: async (message) => {
    const uptime = process.uptime();
    const hours = Math.floor(uptime / 3600);
    const minutes = Math.floor((uptime % 3600) / 60);

    const embed = statsEmbed(`${config.bot.name} Status`, [
      { name: 'Uptime', value: `${hours}h ${minutes}m`, inline: true },
      { name: 'Servers', value: String(message.client.guilds.cache.size), inline: true },
      { name: 'Memory', value: `${Math.round(process.memoryUsage().heapUsed / 1024 / 1024)}MB`, inline: true },
      { name: 'Time (IST)', value: formatIST(), inline: true },
      { name: 'AI Models', value: (config.openai?.models || config.groq.models).map((m) => `\`${m.label}\``).join(', '), inline: false },
      { name: 'Made by', value: config.bot.maker, inline: true },
    ]);

    await message.reply({ embeds: [embed] });
  },
});

// --- $roles ---

commands.set('roles', {
  description: 'View server role hierarchy',
  permissions: [],
  execute: async (message) => {
    try {
      const hierarchy = analyzeServerRoles(message.guild);
      const fields = [];

      if (hierarchy.staffRoles.length > 0) {
        const staffList = hierarchy.staffRoles.slice(0, 15).map((r) => {
          const members = r.memberCount > 0 ? ` (${r.memberCount})` : ' (empty)';
          return `**${r.tier.toUpperCase()}** — ${r.name}${members}`;
        }).join('\n');
        fields.push({ name: 'Staff Hierarchy', value: staffList, inline: false });
      }

      if (hierarchy.genderRoles.length > 0) {
        fields.push({
          name: 'Gender Roles',
          value: hierarchy.genderRoles.map((r) => `${r.name} (${r.genderType})`).join(', '),
          inline: true,
        });
      }

      if (hierarchy.levelRoles.length > 0) {
        fields.push({
          name: 'Level Roles',
          value: hierarchy.levelRoles.slice(0, 10).map((r) => r.name).join(', '),
          inline: true,
        });
      }

      fields.push({ name: 'Total Roles', value: String(hierarchy.totalRoles), inline: true });
      fields.push({ name: 'Bot Roles', value: String(hierarchy.botRoles.length), inline: true });

      const embed = statsEmbed(`Role Hierarchy — ${message.guild.name}`, fields);
      await message.reply({ embeds: [embed] });
    } catch (err) {
      await message.reply({ embeds: [errorEmbed('Error', 'Failed to analyze roles.')] });
    }
  },
});

// --- $serverinfo ---

commands.set('serverinfo', {
  description: 'View server information',
  permissions: [],
  execute: async (message) => {
    const guild = message.guild;
    const hierarchy = analyzeServerRoles(guild);
    const owner = await guild.fetchOwner().catch(() => null);

    // Count humans vs bots
    const humanCount = guild.members.cache.filter((m) => !m.user.bot).size;
    const botCount = guild.members.cache.filter((m) => m.user.bot).size;

    const embed = statsEmbed(`Server Info — ${guild.name}`, [
      { name: 'Owner', value: owner ? `${owner.user.tag}` : 'Unknown', inline: true },
      { name: 'Members', value: `${formatNumber(guild.memberCount)} (${humanCount} humans, ${botCount} bots)`, inline: true },
      { name: 'Roles', value: String(hierarchy.totalRoles), inline: true },
      { name: 'Channels', value: String(guild.channels.cache.size), inline: true },
      { name: 'Boost Level', value: `Tier ${guild.premiumTier || 0} (${guild.premiumSubscriptionCount || 0} boosts)`, inline: true },
      { name: 'Created', value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:R>`, inline: true },
      { name: 'Staff Roles', value: hierarchy.staffRoles.length > 0 ? hierarchy.staffRoles.slice(0, 8).map((r) => r.name).join(', ') : 'None detected', inline: false },
    ]);

    if (guild.iconURL()) embed.setThumbnail(guild.iconURL({ dynamic: true }));

    await message.reply({ embeds: [embed] });
  },
});

// --- $whois ---

commands.set('whois', {
  description: 'Detailed info about a user',
  permissions: [],
  execute: async (message) => {
    const target = message.mentions.members?.first() || message.member;
    if (!target) return message.reply({ embeds: [errorEmbed('Not Found', 'User not found.')] });

    const isBot = target.user.bot;
    const roleAnalysis = analyzeUserRoles(message.guild, target);
    const behavior = !isBot ? getUserBehaviorProfile(message.guild.id, target.id) : null;
    const globalUser = getUser(target.id);

    const fields = [];
    fields.push({ name: 'Display Name', value: target.displayName || target.user.username, inline: true });
    fields.push({ name: 'Type', value: isBot ? '🤖 Bot' : '👤 Human', inline: true });

    if (roleAnalysis) {
      fields.push({ name: 'Status', value: roleAnalysis.isOwner ? 'Server Owner' : roleAnalysis.isStaff ? `Staff (${roleAnalysis.staffTier})` : 'Member', inline: true });
      if (roleAnalysis.roles.length > 0) {
        fields.push({ name: 'Roles', value: roleAnalysis.roles.slice(0, 15).map((r) => r.name).join(', '), inline: false });
      }
      if (roleAnalysis.isBooster) fields.push({ name: 'Booster', value: 'Yes', inline: true });
      if (roleAnalysis.detectedGender !== 'unknown') fields.push({ name: 'Gender', value: roleAnalysis.detectedGender, inline: true });
    }

    if (behavior) {
      fields.push({ name: 'Messages', value: formatNumber(behavior.messageCount), inline: true });
      fields.push({ name: 'Reply Rate', value: `${behavior.replyRate}%`, inline: true });
      fields.push({ name: 'Activity', value: behavior.activityPattern, inline: true });
      fields.push({ name: 'Influence', value: behavior.influence, inline: true });
    }

    if (target.joinedAt) {
      fields.push({ name: 'Joined', value: `<t:${Math.floor(target.joinedTimestamp / 1000)}:R>`, inline: true });
    }

    const embed = statsEmbed(`Who is ${target.displayName}?`, fields);
    if (target.user.avatarURL()) embed.setThumbnail(target.user.avatarURL({ dynamic: true }));

    await message.reply({ embeds: [embed] });
  },
});

// --- $leaderboard ---

commands.set('leaderboard', {
  description: 'Server leaderboard',
  permissions: [],
  execute: async (message) => {
    const topUsers = getTopServerUsers(message.guild.id, 30);
    if (topUsers.length === 0) {
      return message.reply({ embeds: [infoEmbed('Leaderboard', 'No data yet.')] });
    }

    // Filter out bots
    const humanUsers = topUsers.filter((u) => {
      const member = message.guild.members.cache.get(u.user_id);
      return !member?.user?.bot;
    }).slice(0, 15);

    if (humanUsers.length === 0) {
      return message.reply({ embeds: [infoEmbed('Leaderboard', 'No human data yet.')] });
    }

    const medals = ['🥇', '🥈', '🥉'];
    const lines = humanUsers.map((u, i) => {
      const medal = medals[i] || `**${i + 1}.**`;
      const replyRate = u.message_count > 0 ? Math.round((u.replies_received / u.message_count) * 100) : 0;
      return `${medal} <@${u.user_id}> — ${formatNumber(u.message_count)} msgs | ${replyRate}% reply rate`;
    });

    const embed = infoEmbed(`Leaderboard — ${message.guild.name}`, lines.join('\n'));
    await message.reply({ embeds: [embed] });
  },
});

// --- Command Handler ---

async function handleCommand(message) {
  const prefix = config.discord.prefix;
  if (!message.content.startsWith(prefix)) return false;

  // Ignore bots running commands
  if (message.author.bot) return false;

  const args = message.content.slice(prefix.length).trim().split(/\s+/);
  const commandName = args.shift().toLowerCase();

  const command = commands.get(commandName);
  if (!command) return false;

  // Permission check
  if (command.permissions.length > 0) {
    const member = message.member;
    const hasPerms = command.permissions.every((perm) => member?.permissions?.has(perm));
    if (!hasPerms) {
      await message.reply({ embeds: [errorEmbed('No Permission', 'You don\'t have the required permissions.')] });
      return true;
    }
  }

  try {
    await command.execute(message, args);
  } catch (err) {
    console.error(`[CMD] Error in ${commandName}:`, err);
    await message.reply({ embeds: [errorEmbed('Error', 'Something went wrong.')] }).catch(() => {});
  }

  return true;
}

// --- Dashboard Command ($dashboard / /dashboard) — Owner Only ---

commands.set('dashboard', {
  description: 'Owner-only bot dashboard',
  permissions: [],
  execute: async (message) => {
    if (message.author.id !== config.discord.ownerId) {
      return message.reply({ embeds: [errorEmbed('No Permission', 'Owner only.')] });
    }

    const uptime = process.uptime();
    const hours = Math.floor(uptime / 3600);
    const minutes = Math.floor((uptime % 3600) / 60);
    const mem = process.memoryUsage();

    const guilds = message.client.guilds.cache;
    const totalMembers = guilds.reduce((sum, g) => sum + g.memberCount, 0);

    // Top 5 most active servers by member count
    const topGuilds = [...guilds.values()]
      .sort((a, b) => b.memberCount - a.memberCount)
      .slice(0, 5)
      .map((g, i) => `**${i + 1}.** ${g.name} — ${formatNumber(g.memberCount)} members`)
      .join('\n');

    // AI model status
    const modelStatus = (config.openai?.models || config.groq.models).map((m) => `\`${m.label}\` ✅`).join(' | ');

    // Read recent errors from log if exists
    let recentErrors = 'None';
    try {
      const fs = require('fs');
      const logPath = require('path').join(config.paths.data, 'logs', 'error.log');
      if (fs.existsSync(logPath)) {
        const lines = fs.readFileSync(logPath, 'utf8').trim().split('\n');
        recentErrors = lines.slice(-5).join('\n').slice(0, 500) || 'None';
      }
    } catch (e) { /* optional */ }

    const embed = statsEmbed(`${config.bot.name} Dashboard`, [
      { name: 'Uptime', value: `${hours}h ${minutes}m`, inline: true },
      { name: 'Servers', value: String(guilds.size), inline: true },
      { name: 'Total Members', value: formatNumber(totalMembers), inline: true },
      { name: 'Heap Memory', value: `${Math.round(mem.heapUsed / 1024 / 1024)}MB / ${Math.round(mem.heapTotal / 1024 / 1024)}MB`, inline: true },
      { name: 'RSS', value: `${Math.round(mem.rss / 1024 / 1024)}MB`, inline: true },
      { name: 'Time (IST)', value: formatIST(), inline: true },
      { name: 'AI Models', value: modelStatus, inline: false },
      { name: 'Top Servers', value: topGuilds || 'None', inline: false },
      { name: 'Recent Errors', value: recentErrors.slice(0, 300), inline: false },
    ]);

    await message.reply({ embeds: [embed] });
  },
});

// --- Slash Command Handler ---

async function handleSlashCommand(interaction) {
  if (!interaction.isChatInputCommand()) return;

  const commandName = interaction.commandName;

  // Map slash commands to existing command logic
  const slashHandlers = {
    help: async () => {
      await interaction.reply({ embeds: [helpEmbed(config.discord.prefix)] });
    },
    serverinfo: async () => {
      const cmd = commands.get('serverinfo');
      if (cmd) {
        const fakeMsg = createFakeMessage(interaction);
        await cmd.execute(fakeMsg);
      }
    },
    profile: async () => {
      const target = interaction.options.getUser('user') || interaction.user;
      if (target.bot) return interaction.reply({ embeds: [errorEmbed('Error', 'Cannot view profile of a bot.')], ephemeral: true });
      const user = getUser(target.id);
      if (!user) return interaction.reply({ embeds: [errorEmbed('Not Found', 'No data for this user yet.')], ephemeral: true });
      const stats = getUserStats(interaction.guild.id, target.id);
      const memories = getUserMemories(target.id, 10);
      const behavior = getUserBehaviorProfile(interaction.guild.id, target.id);
      const notes = getUserNotes(interaction.guild.id, target.id, 5);
      const embed = userProfileEmbed(user, stats, memories);
      if (behavior) {
        embed.addFields(
          { name: 'Activity Pattern', value: behavior.activityPattern, inline: true },
          { name: 'Influence', value: behavior.influence, inline: true },
          { name: 'Engagement', value: behavior.engagementLevel, inline: true },
        );
      }
      if (notes.length > 0) {
        const noteText = notes.map((n) => `• ${n.content}`).join('\n');
        embed.addFields({ name: 'AI Observations', value: noteText, inline: false });
      }
      await interaction.reply({ embeds: [embed] });
    },
    stats: async () => {
      const cmd = commands.get('stats');
      if (cmd) {
        const fakeMsg = createFakeMessage(interaction);
        await cmd.execute(fakeMsg);
      }
    },
    social: async () => {
      const target = interaction.options.getUser('user');
      const guildId = interaction.guild.id;
      if (target) {
        if (target.bot) return interaction.reply({ embeds: [errorEmbed('Error', 'Bots don\'t have social connections.')], ephemeral: true });
        const connections = getUserConnections(guildId, target.id);
        if (connections.length === 0) {
          return interaction.reply({ embeds: [infoEmbed('Social Graph', `No social data for <@${target.id}> yet.`)] });
        }
        const lines = connections.map((c, i) =>
          `**${i + 1}.** <@${c.partnerId}> — ${c.interactions} interactions, ${c.replies} replies`
        );
        return interaction.reply({ embeds: [infoEmbed(`Social Connections — ${target.username}`, lines.join('\n'))] });
      }
      const pairs = getStrongestPairs(guildId, 10);
      await interaction.reply({ embeds: [socialGraphEmbed(pairs, `Social Graph — ${interaction.guild.name}`)] });
    },
    vibes: async () => {
      const { getRecentMessages: getMsg } = require('../database/server');
      const recentMsgs = getMsg(interaction.guild.id, interaction.channel.id, 30);
      const vibeData = await analyzeChannelVibe(interaction.guild.id, interaction.channel.id, recentMsgs);
      if (!vibeData) {
        return interaction.reply({ embeds: [infoEmbed('Channel Vibe', 'Not enough data to analyze yet.')] });
      }
      const embed = statsEmbed(`#${interaction.channel.name} Vibes`, [
        { name: 'Mood', value: vibeData.vibe || 'neutral', inline: true },
        { name: 'Activity', value: vibeData.activity || 'normal', inline: true },
        { name: 'Topic', value: vibeData.topic || 'general chat', inline: true },
      ]);
      await interaction.reply({ embeds: [embed] });
    },
    status: async () => {
      const uptime = process.uptime();
      const hours = Math.floor(uptime / 3600);
      const minutes = Math.floor((uptime % 3600) / 60);
      const embed = statsEmbed(`${config.bot.name} Status`, [
        { name: 'Uptime', value: `${hours}h ${minutes}m`, inline: true },
        { name: 'Servers', value: String(interaction.client.guilds.cache.size), inline: true },
        { name: 'Memory', value: `${Math.round(process.memoryUsage().heapUsed / 1024 / 1024)}MB`, inline: true },
        { name: 'Time (IST)', value: formatIST(), inline: true },
        { name: 'AI Models', value: (config.openai?.models || config.groq.models).map((m) => `\`${m.label}\``).join(', '), inline: false },
        { name: 'Made by', value: config.bot.maker, inline: true },
      ]);
      await interaction.reply({ embeds: [embed] });
    },
    leaderboard: async () => {
      const cmd = commands.get('leaderboard');
      if (cmd) {
        const fakeMsg = createFakeMessage(interaction);
        await cmd.execute(fakeMsg);
      }
    },
    whois: async () => {
      const cmd = commands.get('whois');
      if (cmd) {
        const target = interaction.options.getUser('user');
        const fakeMsg = createFakeMessage(interaction);
        if (target) {
          fakeMsg.mentions = { members: { first: () => interaction.guild.members.cache.get(target.id) }, users: { first: () => target } };
        }
        await cmd.execute(fakeMsg);
      }
    },
    dashboard: async () => {
      if (interaction.user.id !== config.discord.ownerId) {
        return interaction.reply({ embeds: [errorEmbed('No Permission', 'Owner only.')], ephemeral: true });
      }
      const cmd = commands.get('dashboard');
      if (cmd) {
        const fakeMsg = createFakeMessage(interaction);
        fakeMsg.author = interaction.user;
        await cmd.execute(fakeMsg);
      }
    },
  };

  const handler = slashHandlers[commandName];
  if (handler) {
    try {
      await handler();
    } catch (err) {
      console.error(`[SLASH] Error in /${commandName}:`, err);
      const replyMethod = interaction.replied || interaction.deferred ? 'followUp' : 'reply';
      await interaction[replyMethod]({ embeds: [errorEmbed('Error', 'Something went wrong.')], ephemeral: true }).catch(() => {});
    }
  }
}

/**
 * Create a fake message-like object from a slash interaction
 * so existing command logic can work with slash commands.
 */
function createFakeMessage(interaction) {
  return {
    author: interaction.user,
    member: interaction.member,
    guild: interaction.guild,
    channel: interaction.channel,
    client: interaction.client,
    mentions: {
      users: { first: () => null },
      members: { first: () => null },
      channels: { first: () => null },
    },
    reply: (content) => {
      if (interaction.replied || interaction.deferred) {
        return interaction.followUp(content);
      }
      return interaction.reply(content);
    },
  };
}

module.exports = { handleCommand, handleSlashCommand };
