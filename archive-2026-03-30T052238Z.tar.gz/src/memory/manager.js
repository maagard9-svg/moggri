const { addUserMemory, getUserMemories, pruneOldMemories } = require('../database/global');
const { addServerMemory, getServerMemories, addUserNote } = require('../database/server');
const { analyze } = require('../ai/groq');

/**
 * After a conversation, extract and store memories about the user.
 * Uses AI to identify memorable facts from the conversation.
 */
async function extractAndStoreMemories(userId, username, recentMessages, guildId) {
  const userMsgs = recentMessages.filter((m) => m.user_id === userId && !m.is_bot_message);
  if (userMsgs.length < 2) return;

  const existingMemories = getUserMemories(userId, 20);
  const existingFacts = existingMemories.map((m) => m.content).join('\n');

  const chatSnippet = userMsgs.slice(-15).map((m) => `${m.username}: ${m.content}`).join('\n');

  const prompt = `Analyze these Discord messages from user "${username}" and extract 1-3 NEW memorable facts, preferences, or personality traits. These should be things worth remembering for future conversations.

EXISTING KNOWN FACTS (don't repeat these):
${existingFacts || 'None yet'}

RECENT MESSAGES:
${chatSnippet}

Respond with ONLY a JSON array of strings. Each string is one fact. Example:
["likes anime especially one piece", "gets annoyed when people don't reply", "usually active at night"]

If nothing new or memorable, respond with: []`;

  try {
    const result = await analyze(prompt, { maxTokens: 200 });
    if (!result) return;

    const cleaned = result.replace(/```json?\n?/g, '').replace(/```/g, '').trim();
    const facts = JSON.parse(cleaned);

    if (Array.isArray(facts)) {
      for (const fact of facts.slice(0, 3)) {
        if (typeof fact === 'string' && fact.length > 3 && fact.length < 200) {
          // Dedup: skip if existing fact is very similar
          const isDup = existingMemories.some((m) => {
            const a = m.content.toLowerCase();
            const b = fact.toLowerCase();
            return a === b || a.includes(b) || b.includes(a);
          });
          if (isDup) continue;
          addUserMemory(userId, fact, 'fact', 5);
          // Also store as a high-confidence user note in the server DB
          if (guildId) {
            addUserNote(guildId, userId, fact, 'memory', 0.8);
          }
        }
      }
    }

    pruneOldMemories(userId, 50);
  } catch (e) {
    // Silently fail — memory extraction is best-effort
  }
}

/**
 * Extract server-level observations from recent chat.
 */
async function extractServerObservations(guildId, recentMessages) {
  if (recentMessages.length < 10) return;

  const chatSnippet = recentMessages.slice(-30).map((m) => `${m.username}: ${m.content}`).join('\n');

  const prompt = `Analyze this Discord chat and extract 1-2 brief social observations about the group dynamics. Focus on: who's active, any interesting interactions, ignored messages, mood shifts, or notable patterns.

CHAT:
${chatSnippet}

Respond with ONLY a JSON array of strings. Each string is one observation. Keep each under 100 characters.
Example: ["user1 and user2 seem close, always replying to each other", "chat died after the argument about music"]

If nothing notable: []`;

  try {
    const result = await analyze(prompt, { maxTokens: 150 });
    if (!result) return;

    const cleaned = result.replace(/```json?\n?/g, '').replace(/```/g, '').trim();
    const observations = JSON.parse(cleaned);

    if (Array.isArray(observations)) {
      for (const obs of observations.slice(0, 2)) {
        if (typeof obs === 'string' && obs.length > 5) {
          addServerMemory(guildId, {
            type: 'observation',
            content: obs,
            expiresInSec: 259200, // 72 hours
          });
        }
      }
    }
  } catch (e) {
    // Best-effort
  }
}

/**
 * Extract quick behavioral notes about a user (stored per-server).
 * Lower threshold than full memory extraction.
 */
async function extractUserNotes(guildId, userId, username, recentMessages) {
  const userMsgs = recentMessages.filter((m) => m.user_id === userId && !m.is_bot_message);
  if (userMsgs.length < 3) return;

  const chatSnippet = userMsgs.slice(-10).map((m) => m.content).join('\n');

  const prompt = `Based on these Discord messages from "${username}", extract 1-2 quick behavioral observations. Focus on: communication style, mood patterns, social behavior, interests hinted at.

Messages:
${chatSnippet}

Respond with ONLY a JSON array of objects: [{"note": "...", "confidence": 0.0-1.0}]
Confidence: 0.9 = very certain, 0.5 = educated guess, 0.3 = slight hint

If nothing notable: []`;

  try {
    const result = await analyze(prompt, { maxTokens: 150 });
    if (!result) return;

    const cleaned = result.replace(/```json?\n?/g, '').replace(/```/g, '').trim();
    const notes = JSON.parse(cleaned);

    if (Array.isArray(notes)) {
      for (const note of notes.slice(0, 2)) {
        if (note?.note && typeof note.note === 'string' && note.note.length > 3) {
          addUserNote(guildId, userId, note.note, 'behavior', note.confidence || 0.5);
        }
      }
    }
  } catch (e) {
    // Best-effort
  }
}

/**
 * Analyze and update user personality profile periodically.
 */
async function updateUserProfile(userId, username, recentMessages) {
  const userMsgs = recentMessages.filter((m) => m.user_id === userId && !m.is_bot_message);
  if (userMsgs.length < 10) return null;

  const chatSnippet = userMsgs.slice(-20).map((m) => m.content).join('\n');

  const prompt = `Based on these Discord messages from "${username}", give a brief personality summary in 1-2 sentences. Include: communication style, interests visible, mood tendency, activity pattern.

Messages:
${chatSnippet}

Respond with ONLY the summary, nothing else.`;

  try {
    const result = await analyze(prompt, { maxTokens: 100 });
    return result || null;
  } catch (e) {
    return null;
  }
}

module.exports = {
  extractAndStoreMemories,
  extractServerObservations,
  extractUserNotes,
  updateUserProfile,
};
