const { analyze } = require('../ai/groq');
const { getRecentMessages } = require('../database/server');
const { appendFileSync, readFileSync, writeFileSync, existsSync, mkdirSync } = require('fs');
const { join } = require('path');
const config = require('../config');

// --- 0. ADAPTIVE REPLY SIZING ENGINE ---
// 5 tiers: MICRO → SHORT → MEDIUM → LONG → FULL
// Automatically picks the right size based on context signals

const REPLY_TIERS = {
  MICRO:  { maxTokens: 25,  maxChars: 40,   maxSentences: 1, label: 'micro' },   // "lol" "fr" "nah"
  SHORT:  { maxTokens: 80,  maxChars: 160,  maxSentences: 2, label: 'short' },   // casual banter — enough room for a real sentence
  MEDIUM: { maxTokens: 150, maxChars: 350,  maxSentences: 3, label: 'medium' },  // opinions, mild engagement
  LONG:   { maxTokens: 220, maxChars: 600,  maxSentences: 4, label: 'long' },    // knowledge, help, deep topics
  FULL:   { maxTokens: 350, maxChars: 1200, maxSentences: 8, label: 'full' },    // detailed help, technical, serious
};

// Patterns that indicate the user is asking a KNOWLEDGE question needing a real answer
const KNOWLEDGE_QUESTION_PATTERNS = [
  // Server/role questions
  /\b(tell|about|info|details?|explain|describe|what('?s| is| are)?)\b.*(server|roles?|channel|member|mod|admin|owner|staff|boost)/i,
  /\b(who|what|how many|list|show)\b.*(roles?|members?|admin|mod|online|channel|server|staff|boost)/i,
  /\b(server|roles?|members?)\b.*(kya|kitne|kaun|batao|bata|details?)/i,
  /\b(batao|bata)\b.*(server|roles?|channel|member)/i,
  /\bkitne\s+(members?|log|roles?)/i,
  // Current events / opinion questions
  /\b(what|how)\b.*(think|opinion|going on|happening|feel)\b/i,
  /\b(iran|war|politics|election|modi|trump|ukraine|gaza|palestine|cricket|ipl|movie|game)\b/i,
  /\b(kya lagta|kya sochte|tera opinion|tumhara opinion|what do you think)\b/i,
  // Technical/knowledge questions
  /\b(how (to|do|does|can)|what (is|are|does)|why (is|are|do|does)|explain|define|difference between)\b/i,
  /\b(coding|programming|python|javascript|java|code|function|error|bug)\b/i,
  // Deep/personal questions that need thoughtful answers
  /\b(meaning of life|purpose|philosophy|religion|death|consciousness)\b/i,
  // Hindi explain/request patterns
  /\b(samjha|samjhao|samjha de|explain kar|batao detail|detail mein|puri detail|step by step|ache se bata)\b/i,
  // Choice/comparison questions (CRITICAL — bot must actually pick and answer)
  /\b(who\s+is\s+(best|better|worst|greater))\b/i,
  /\b(choose\s+one|pick\s+one|choice\s+one|choice\s+a)\b/i,
  /\b(kon\s+(best|better|accha|acha)|kaun\s+(best|better|accha|acha))\b/i,
  /\b(X\s+or\s+Y|A\s+ya\s+B)\b/i,
  /\b(best\s+owner|best\s+mod|best\s+member|best\s+admin)\b/i,
  // "tell me" / "bata" patterns — user explicitly asking for info
  /\b(tell\s+me|plz\s+tell|please\s+tell|bata\s+na|bata\s+de|batao|bata\b)/i,
  // "who is your" patterns
  /\b(who\s+is\s+your|tera\s+(baap|papa|dad|mummy|mom|friend|dost))\b/i,
  // "do you know" / "aati hai" patterns
  /\b(do\s+you\s+know|you\s+know|aati\s+hai|aata\s+hai|pata\s+hai)\b/i,
  // "how" questions
  /\b(how\s+(are|is|did|do|can|could|was|were))\b/i,
  /\b(kaise|kyu|kyun|why)\b/i,
];

// Patterns that indicate the user wants an ACTION (ping someone, help, etc.)
const ACTION_PATTERNS = [
  /\b(ping|call|bulao|bula|tag|mention)\b.*(friend|dost|bhai|yaar|user|member|\w+)/i,
  /\b(friend|dost|bhai|yaar)\b.*(ping|call|bulao|bula|tag)/i,
  /\b(help|madad|chahiye|please|serious|seriously|zaruri|urgent|important)\b/i,
  /\bko\s+(ping|call|bulao|bula|tag)\b/i,
  /\b(ek kaam|pls|plz)\b/i,
];

// Signals for DEEP conversation (upgrade to MEDIUM/LONG even if casual)
const DEEP_SIGNALS = [
  /\b(feel|feeling|sad|depressed|lonely|happy|angry|frustrated|confused|scared|anxious|worried)\b/i,
  /\b(love|hate|miss|care|trust|hurt|pain|broken|lost)\b/i,
  /\b(life|death|future|past|dream|goal|career|relationship|family|friend)\b/i,
  /\b(kya karu|samajh nahi|samjha|samjhao|pata nahi kya|confused hu|help kar|bata na|sun na|soch raha|batao|bata de)\b/i,
  /\b(serious|genuinely|honestly|real talk|no cap|fr fr|not joking)\b/i,
  /\b(story|explain|detail|elaborate|tell me more|aur bata|puri baat)\b/i,
];

// Patterns for MICRO tier — one-word energy responses
const MICRO_PATTERNS = [
  /^(lol|lmao|bruh|fr|ong|bet|nah|haha|ok|hmm|damn|nice|cool|wtf|tf|💀|😂|🤡|gg|rip|w|l|f|oof)\s*[.!?]*$/i,
  /^(gm|gn|bye|cya|peace|later|yo|sup)\s*[.!?]*$/i,
  /^(ye|ha|haan|nahi|nope|yep|yea|yeah|yup|nah|nope|true|facts|cap|no cap)\s*[.!?]*$/i,
];

// Patterns for SHORT tier — quick casual chat
const SHORT_PATTERNS = [
  /^(hi|hello|hey|heyy|heyyy|yo|sup|kya|kya hal|kaise ho|how are you|wyd|wbu|hbu)/i,
  /^.{1,30}$/,  // Short messages get short replies
];

/**
 * ADAPTIVE REPLY SIZER — The brain of reply length decisions.
 * Analyzes the user's message + conversation context to pick the perfect reply tier.
 * Returns: { tier: REPLY_TIERS.X, type: string, isQuestion: boolean, allowLong: boolean }
 */
function calculateReplyTier(content, opts = {}) {
  if (!content) return { tier: REPLY_TIERS.SHORT, type: 'casual', isQuestion: false, allowLong: false };

  const msgLen = content.length;
  const wordCount = content.split(/\s+/).length;
  const recentBotReplies = opts.recentBotReplies || 0;  // how many bot replies in last few messages
  const conversationDepth = opts.conversationDepth || 0; // how many back-and-forth exchanges
  const userMsgLength = opts.userAvgLength || 0; // user's recent average msg length

  // --- TIER 1: MICRO — single-word energy ---
  // ONLY use micro for genuinely single-word/emoji-only messages with NO question marks
  if (!content.includes('?') && !content.includes('plz') && !content.includes('tell')) {
    for (const p of MICRO_PATTERNS) {
      if (p.test(content.trim())) {
        return { tier: REPLY_TIERS.MICRO, type: 'micro', isQuestion: false, allowLong: false };
      }
    }
  }

  // --- Check ACTION patterns first (ping, help) ---
  const hasAction = ACTION_PATTERNS.some(p => p.test(content));
  if (hasAction) {
    if (/ping|call|bulao|bula|tag|mention/i.test(content)) {
      return { tier: REPLY_TIERS.MEDIUM, type: 'action_ping', isQuestion: true, allowLong: true };
    }
    // Help request — tier depends on seriousness
    if (/serious|urgent|zaruri|important|please.*help|madad.*chahiye/i.test(content)) {
      return { tier: REPLY_TIERS.FULL, type: 'action_help', isQuestion: true, allowLong: true };
    }
    return { tier: REPLY_TIERS.LONG, type: 'action_help', isQuestion: true, allowLong: true };
  }

  // --- Check KNOWLEDGE questions ---
  for (const p of KNOWLEDGE_QUESTION_PATTERNS) {
    if (p.test(content)) {
      if (/\b(server|roles?|members?|channels?|mods?\b|admin|staff|boost)\b/i.test(content) && !/\bmodi\b/i.test(content)) {
        return { tier: REPLY_TIERS.LONG, type: 'server_knowledge', isQuestion: true, allowLong: true };
      }
      if (/\b(war|politics|election|iran|ukraine|gaza|cricket|ipl|movie|opinion|think|lagta|sochte|modi|trump)\b/i.test(content)) {
        return { tier: REPLY_TIERS.MEDIUM, type: 'opinion', isQuestion: true, allowLong: true };
      }
      if (/how to|what is|explain|define|coding|programming|code|samjha|samjhao|detail mein|batao detail/i.test(content)) {
        // Technical/explain: tier based on complexity
        if (msgLen > 50 || /explain|detail|step|tutorial|samjhao|puri|ache se/i.test(content)) {
          return { tier: REPLY_TIERS.FULL, type: 'technical', isQuestion: true, allowLong: true };
        }
        return { tier: REPLY_TIERS.LONG, type: 'technical', isQuestion: true, allowLong: true };
      }
      return { tier: REPLY_TIERS.MEDIUM, type: 'general_question', isQuestion: true, allowLong: true };
    }
  }

  // --- Check DEEP conversation signals ---
  const deepScore = DEEP_SIGNALS.reduce((score, p) => score + (p.test(content) ? 1 : 0), 0);
  if (deepScore >= 2) {
    return { tier: REPLY_TIERS.LONG, type: 'deep_convo', isQuestion: false, allowLong: true };
  }
  if (deepScore >= 1 && msgLen > 50) {
    return { tier: REPLY_TIERS.MEDIUM, type: 'emotional', isQuestion: false, allowLong: true };
  }

  // --- Question mark with some substance ---
  if (/\?$/.test(content.trim()) || /\?\s*$/.test(content.trim())) {
    if (msgLen > 60) return { tier: REPLY_TIERS.MEDIUM, type: 'general_question', isQuestion: true, allowLong: true };
    if (msgLen > 15) return { tier: REPLY_TIERS.SHORT, type: 'quick_question', isQuestion: true, allowLong: false };
    // Even very short ? questions deserve a real answer
    return { tier: REPLY_TIERS.SHORT, type: 'quick_question', isQuestion: true, allowLong: false };
  }

  // --- Choice/comparison requests without ? ("choose one", "pick one", "tell me name") ---
  if (/\b(choose|pick|select|tell|bata|batao|plz|plzz|please|kon|kaun|which|best|better|worse|worst)\b/i.test(content)) {
    return { tier: REPLY_TIERS.SHORT, type: 'choice_request', isQuestion: true, allowLong: false };
  }

  // --- Mirror user's effort: longer messages deserve more engagement ---
  if (msgLen > 200 || wordCount > 40) {
    return { tier: REPLY_TIERS.MEDIUM, type: 'engaged', isQuestion: false, allowLong: true };
  }
  if (msgLen > 80 || wordCount > 15) {
    return { tier: REPLY_TIERS.SHORT, type: 'casual_engaged', isQuestion: false, allowLong: false };
  }

  // --- Conversation depth boost: if deep in a back-and-forth, allow slightly longer ---
  if (conversationDepth >= 5 && msgLen > 30) {
    return { tier: REPLY_TIERS.SHORT, type: 'flowing_convo', isQuestion: false, allowLong: false };
  }

  // --- SHORT greetings ---
  for (const p of SHORT_PATTERNS) {
    if (p.test(content.trim())) {
      return { tier: REPLY_TIERS.SHORT, type: 'casual', isQuestion: false, allowLong: false };
    }
  }

  // --- Default: SHORT ---
  return { tier: REPLY_TIERS.SHORT, type: 'casual', isQuestion: false, allowLong: false };
}

// Legacy wrapper for backward compatibility
function detectQuestionType(content) {
  const result = calculateReplyTier(content);
  return {
    isQuestion: result.isQuestion,
    type: result.type,
    allowLong: result.allowLong,
    tier: result.tier,
  };
}

// --- 1. POST-PROCESSING: Catch and kill AI patterns ---

// Patterns that scream "I am an AI" — instant removal or rewrite
const AI_PATTERNS = [
  // Self-referencing name repeatedly
  /main toh (bas|sirf)?\s*\w+ hoon/gi,
  /main toh tumhar[ai]\s/gi,
  /i'?m just \w+/gi,
  // ANY self-reference with bot name mid-sentence
  /main\s+(toh\s+)?starklink/gi,
  /starklink\s+(hoon|hi\s+bulao|hu[nm])/gi,
  /tumhara\s+starklink/gi,
  // Describing own personality traits
  /humor mere blood mein/gi,
  /meri personality/gi,
  /main toh (chill|savage|funny|cool) hoon/gi,
  // AI essay structure — comma-separated clauses in Hindi (lowered threshold)
  /(.{15,}),\s*(aur|par|lekin|toh)\s+(.{15,}),\s*(aur|par|lekin|toh)/gi,
  // Over-explaining everything
  /tumhare saath (chat|baat) karke/gi,
  /tumhare saath baat kar/gi,
  /tumhare kehne pe/gi,
  /tumhari feelings ko hurt nahi/gi,
  /sach mein[,.]?\s/gi,
  // Formal AI Hindi that no teen writes
  /main.*chahta\s*(hoon|tha|hun)/gi,
  /aapki.*zarurat/gi,
  /kisi ko.*hurt.*nahi/gi,
  // WhatsApp forward energy
  /dosti toh bani rahegi/gi,
  // Narrating what they're doing
  /main.*reply.*kar\s*raha/gi,
  /main.*chat.*kar\s*raha/gi,
  /main.*sun(unga|ega|raha)/gi,
  // "I'm not X, I'm Y" pattern
  /main .* nahi hoon.*main .* hoon/gi,
  // Unnecessary self-labels (only the AI-declaring-identity pattern)
  /main toh (single|taken) hoon/gi,
  // Overly structured "lekin sach mein" style
  /lekin sach mein/gi,
  // AI loves "but seriously" / "par seriously"
  /par seriously/gi,
  // Repeatedly saying the same thing in different words
  /shaadi\?.*shaadi/gi,
  // "yaar" spam — 3+ in one message is AI
  /(yaar[,.\s]*){3,}/gi,
  // Bot describing its own behavior/role (unprompted)
  /tumhari baat sun/gi,
];

// Phrases to completely nuke from replies
const NUKE_PHRASES = [
  'main toh bas starklink hoon',
  'main toh sirf starklink hoon',
  'main toh starklink hoon',
  'main toh tumhara starklink hoon',
  'main tumhara starklink hoon',
  'i\'m just starklink',
  'main starklink hoon',
  'starklink hoon',
  'starklink hi bulao',
  'mujhe starklink bulao',
  'tumhare saath chat kar raha hoon',
  'tumhare saath baat karke',
  'tumhare saath baat kar raha',
  'tumhare kehne pe chalta hoon',
  'tumhari feelings ko hurt nahi karna chahta',
  'dosti toh bani rahegi',
  'sorry to hear that',
  'How can I help',
  'Is there anything else',
  'humor mere blood mein',
  'lekin sach mein',
  'main serious nahi hoon',
  'sochne ki zarurat nahi',
  'baaki cheezein toh',
  'tumhari baat sunke',
];

/**
 * Post-process AI output to kill AI-sounding patterns.
 * @param {string} text - AI response
 * @param {object} questionCtx - from detectQuestionType()
 * Returns cleaned text, or null if the whole thing is unsalvageable.
 */
function postProcessReply(text, questionCtx = null) {
  if (!text) return null;
  let cleaned = text;
  const tier = questionCtx?.tier || REPLY_TIERS.SHORT;

  // Strip <think>...</think> reasoning blocks (safety net)
  cleaned = cleaned.replace(/<think>[\s\S]*?<\/think>/gi, '').trim();
  cleaned = cleaned.replace(/<think>[\s\S]*/gi, '').trim();
  if (!cleaned) return null;

  // Remove nuke phrases (ALWAYS, even in long answers)
  for (const phrase of NUKE_PHRASES) {
    const regex = new RegExp(phrase.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi');
    cleaned = cleaned.replace(regex, '');
  }

  // Strip any sentence containing bot name used self-referentially
  const botName = (config.bot.name || 'starklink').toLowerCase();
  if (cleaned.toLowerCase().includes(botName)) {
    const clauses = cleaned.split(/[,.]/).filter(c => {
      const lower = c.toLowerCase().trim();
      const selfRef = lower.includes(botName) && (
        /main\b/.test(lower) || /hoon\b/.test(lower) || /bulao\b/.test(lower) ||
        /tumhar[ai]\b/.test(lower) || /mera\b/.test(lower)
      );
      return !selfRef;
    });
    cleaned = clauses.join(', ').trim();
  }

  // Strip AI patterns from the text
  for (const pattern of AI_PATTERNS) {
    pattern.lastIndex = 0;
    cleaned = cleaned.replace(pattern, '');
  }

  // Clean up orphaned commas, spaces, trailing connectors
  cleaned = cleaned.replace(/^[\s,]+|[\s,]+$/g, '');
  cleaned = cleaned.replace(/\s{2,}/g, ' ');
  cleaned = cleaned.replace(/^(aur|par|lekin|toh)\s*/i, '');
  cleaned = cleaned.replace(/\s*(aur|par|lekin)\s*$/i, '');
  cleaned = cleaned.trim();

  // --- TIER-BASED LENGTH CONTROL ---
  const maxChars = tier.maxChars;
  const maxSentences = tier.maxSentences;

  // For MICRO/SHORT: kill run-on sentences (2+ comma clauses → first clause only)
  if (tier.label === 'micro' || tier.label === 'short') {
    const commaCount = (cleaned.match(/,/g) || []).length;
    if (commaCount >= 2) {
      const firstClause = cleaned.split(',')[0].trim();
      if (firstClause.length >= 3) cleaned = firstClause;
    }
  }

  // Apply tier-based character + sentence limits
  if (cleaned.length > maxChars) {
    const sentences = cleaned.split(/[.!?\n]+/).filter(s => s.trim().length > 0);
    if (sentences.length > maxSentences) {
      cleaned = sentences.slice(0, maxSentences).join('. ').trim();
    }
    if (cleaned.length > maxChars) {
      const cut = cleaned.lastIndexOf(' ', maxChars);
      cleaned = cleaned.slice(0, cut > maxChars * 0.3 ? cut : maxChars).trim();
    }
  }

  // Final cleanup
  cleaned = cleaned.replace(/^[\s,]+|[\s,]+$/g, '');
  cleaned = cleaned.replace(/\s{2,}/g, ' ').trim();

  // If nothing meaningful left, return null
  if (cleaned.length < 2) return null;

  return cleaned;
}

// --- 2. STYLE LEARNER: Learn how real users actually text ---

const styleDataDir = join(config.paths.data, 'style');

function ensureStyleDir() {
  if (!existsSync(styleDataDir)) mkdirSync(styleDataDir, { recursive: true });
}

/**
 * Analyze how REAL users in a server text and extract their style patterns.
 * This runs periodically and stores style insights that get injected into the prompt.
 */
async function learnServerStyle(guildId, channelId) {
  ensureStyleDir();
  const recentMsgs = getRecentMessages(guildId, channelId, 80);
  const humanMsgs = recentMsgs
    .filter(m => !m.is_bot_message && m.content.length > 3 && m.content.length < 200)
    .map(m => m.content);

  if (humanMsgs.length < 15) return null;

  // Sample 20 random messages
  const sample = [];
  const shuffled = [...humanMsgs].sort(() => Math.random() - 0.5);
  for (const msg of shuffled.slice(0, 20)) {
    sample.push(msg);
  }

  const prompt = `Analyze these REAL Discord messages from actual human users and extract the STYLE patterns. Focus on:
1. Average message length (in words)
2. Common slang/abbreviations used
3. Emoji usage patterns
4. Grammar style (lowercase? broken? proper?)
5. Language mix (English? Hindi? Hinglish?)
6. Tone (casual/serious/meme-y/edgy?)

Messages:
${sample.map((m, i) => `${i + 1}. ${m}`).join('\n')}

Respond with ONLY a JSON object like:
{"avg_words": 5, "slang": ["fr", "ngl", "bhai"], "emoji_rate": "low", "grammar": "broken lowercase", "language": "hinglish", "tone": "casual edgy", "example_phrases": ["bruh what", "ye kya hai bc"], "max_words_typical": 12}`;

  try {
    const result = await analyze(prompt, { maxTokens: 200 });
    if (!result) return null;

    const cleaned = result.replace(/```json?\n?/g, '').replace(/```/g, '').trim();
    const styleData = JSON.parse(cleaned);

    // Store for this guild
    const filePath = join(styleDataDir, `${guildId}.json`);
    const data = { updatedAt: Date.now(), channelId, style: styleData };
    appendFileSync(filePath, ''); // ensure exists
    require('fs').writeFileSync(filePath, JSON.stringify(data, null, 2));

    return styleData;
  } catch (e) {
    return null;
  }
}

/**
 * Get cached style data for a server (if available and recent).
 */
function getServerStyle(guildId) {
  const filePath = join(styleDataDir, `${guildId}.json`);
  if (!existsSync(filePath)) return null;
  try {
    const raw = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(raw);
    // Style data is valid for 6 hours
    if (Date.now() - data.updatedAt > 6 * 60 * 60 * 1000) return null;
    return data.style;
  } catch (e) {
    return null;
  }
}

/**
 * Build a dynamic style hint for the AI prompt based on learned server style.
 */
function buildStyleHint(guildId) {
  const style = getServerStyle(guildId);
  if (!style) return '';

  const parts = ['[LEARNED SERVER STYLE — match this EXACTLY:'];
  if (style.avg_words) parts.push(`  - Users here write ~${style.avg_words} words per message. MATCH THIS LENGTH.`);
  if (style.max_words_typical) parts.push(`  - NEVER exceed ${style.max_words_typical} words unless answering a complex question`);
  if (style.slang && style.slang.length > 0) parts.push(`  - Common slang here: ${style.slang.join(', ')}`);
  if (style.emoji_rate) parts.push(`  - Emoji usage: ${style.emoji_rate}`);
  if (style.grammar) parts.push(`  - Grammar style: ${style.grammar}`);
  if (style.language) parts.push(`  - Language: ${style.language}`);
  if (style.tone) parts.push(`  - Tone: ${style.tone}`);
  if (style.example_phrases && style.example_phrases.length > 0) {
    parts.push(`  - Example phrases real users use: "${style.example_phrases.join('", "')}"`);
  }
  parts.push(']');
  return parts.join('\n');
}

// --- 3. REPLY QUALITY TRACKER ---

// Track bot reply lengths and engagement
const replyTracker = {
  recent: [],   // last 50 replies: { length, gotReply, guildId }
  maxEntries: 50,
};

function trackBotReply(guildId, replyText, gotReplyBack = false) {
  replyTracker.recent.push({
    length: replyText.length,
    words: replyText.split(/\s+/).length,
    gotReply: gotReplyBack,
    guildId,
    time: Date.now(),
  });
  if (replyTracker.recent.length > replyTracker.maxEntries) {
    replyTracker.recent.shift();
  }
}

function getReplyQualityInsight() {
  if (replyTracker.recent.length < 10) return '';
  const avgLen = Math.round(replyTracker.recent.reduce((s, r) => s + r.words, 0) / replyTracker.recent.length);
  const repliedTo = replyTracker.recent.filter(r => r.gotReply).length;
  const replyRate = Math.round((repliedTo / replyTracker.recent.length) * 100);
  
  let hint = '';
  if (avgLen > 25) hint += `[WARNING: Your average reply is ${avgLen} words — way too long. Real users write 5-10 words. CUT IT DOWN.]\n`;
  if (replyRate < 20) hint += '[Your replies rarely get responses. Try being more engaging, ask questions, be provocative.]\n';
  return hint;
}

// --- 4. SELF-VALIDATION QUALITY GATE ---

// Fast local checks (no AI call needed)
const VAGUE_PATTERNS = [
  /mujhe pata hai/gi,
  /i know about/gi,
  /mujhe maloom hai/gi,
  /details toh.*pata/gi,
  /knowledge .* hai/gi,
  /\bpata hai\b.*\bpar\b/gi,
  /toh mujhe.*hai/gi,
  /roles? ki (knowledge|details|info)/gi,
  // Vague "I have knowledge" without giving specifics
  /haan.*mujhe.*hai/gi,
];

/**
 * Fast self-check: does the reply actually answer the question?
 * Returns { pass: boolean, issue: string|null }
 */
function quickQualityCheck(reply, userMsg, questionCtx) {
  if (!reply || !questionCtx) return { pass: true, issue: null };

  // Check 0: FILLER DETECTION — catch lazy non-answers
  // If the reply is ONLY filler words + emoji, it's garbage for any non-micro message
  const strippedReply = reply.replace(/[\u{1F600}-\u{1F9FF}\u{2600}-\u{2B55}\u{FE00}-\u{FEFF}\u{1FA00}-\u{1FAFF}\u{200D}\u{20E3}]/gu, '').trim();
  const fillerOnlyPatterns = [
    /^(fr|ong|lmao|nahi yaar|bc|bruh|lol|ik|same|ok|hmm|damn|oof|rip|bet|nah|haan|true|facts)\s*$/i,
    /^(fr|ong|lmao|nahi yaar|bc|bruh|lol|ik)\s+(fr|ong|lmao|nahi yaar|bc|bruh|lol|ik)\s*$/i,
    /^(kuch nahi|nahi yaar|bc kya|kya bc|teri ma ki|bc teri|same here)\s*$/i,
    /^(chup bc|chill|nahi yaar bc|bc yaar|nahi yaar chill|nahi dekha yaar)\s*$/i,
    /^(bc shut up|bc bas kar|bc teri maa?)\s*$/i,
    /^(hello|hi fr|hay hay|deep yaar)\s*$/i,
  ];
  // For questions and choice requests — ALWAYS check filler
  if (questionCtx.isQuestion || questionCtx.type === 'choice_request') {
    for (const p of fillerOnlyPatterns) {
      if (p.test(strippedReply)) {
        return { pass: false, issue: 'filler_nonanswer' };
      }
    }
  }
  // Even for NON-questions: if the reply is pure filler and the user said something substantive (>15 chars), catch it
  if (!questionCtx.isQuestion && userMsg && userMsg.length > 15) {
    for (const p of fillerOnlyPatterns) {
      if (p.test(strippedReply)) {
        return { pass: false, issue: 'filler_nonanswer' };
      }
    }
  }

  // Check 1: Vague non-answer detection
  if (questionCtx.isQuestion) {
    for (const p of VAGUE_PATTERNS) {
      p.lastIndex = 0;
      if (p.test(reply)) {
        return { pass: false, issue: 'vague_nonanswer' };
      }
    }
  }

  // Check 2: Server question but no specific data in reply
  if (questionCtx.type === 'server_knowledge') {
    // Should contain at least a number or a specific name
    const hasSpecifics = /\d+/.test(reply) || /\b[A-Z][a-z]+\b/.test(reply) || /<@/.test(reply);
    if (!hasSpecifics && reply.length < 100) {
      return { pass: false, issue: 'no_specifics' };
    }
  }

  // Check 3: Opinion question but no actual opinion given
  if (questionCtx.type === 'opinion') {
    const isVague = /mujhe nahi pata|idk about that|no idea|pata nahi/i.test(reply);
    if (isVague && reply.length < 30) {
      return { pass: false, issue: 'no_opinion' };
    }
  }

  return { pass: true, issue: null };
}

/**
 * Build a regen prompt based on what went wrong.
 */
function buildRegenPrompt(issue, questionCtx, userMsg) {
  const base = 'YOUR PREVIOUS REPLY FAILED QUALITY CHECK. ';
  
  switch (issue) {
    case 'vague_nonanswer':
      return base + 'You said "mujhe pata hai" or similar WITHOUT giving actual details. DO NOT say you know something — just tell the actual facts. Use the server data, role names, member counts from your context. Be SPECIFIC. Give real numbers and names.';
    case 'no_specifics':
      return base + 'You gave a vague answer about the server without specific data. USE THE DATA IN YOUR CONTEXT. Mention actual role names, member count, channel names, server features. Real numbers, real names.';
    case 'no_opinion':
      return base + 'User asked your opinion but you dodged it. Give a REAL opinion — spicy, controversial, interesting. You have strong views on everything. Share them.';
    case 'filler_nonanswer':
      return base + `Your reply was just lazy filler like "fr 😂" or "nahi yaar". The user said: "${userMsg}". ACTUALLY RESPOND to what they said. If they asked a question, ANSWER IT. If they said hi, say hi back. No filler — give a REAL reply.`;
    default:
      return base + 'Give a better, more specific answer. Use real data from your context.';
  }
}

/**
 * Build extra context injection for knowledge questions.
 * Adds explicit instruction to use the data.
 */
function buildKnowledgeBoost(questionCtx, guild) {
  if (!questionCtx?.isQuestion || !guild) return '';

  const parts = [];

  if (questionCtx.type === 'server_knowledge') {
    parts.push('[INSTRUCTION: User is asking about the server. You MUST use the ACTUAL DATA from your context above.');
    parts.push('  - Mention REAL role names, REAL member count, REAL channel info');
    parts.push('  - Do NOT say "mujhe pata hai" — just TELL THEM the actual info');
    parts.push('  - Example good answer: "ye server me 8 members hain, TOP role sabse upar hai, admins ke paas ban perms hain"');
    parts.push('  - Example BAD answer: "haan mujhe roles ki knowledge hai, details toh pata hai"');
    parts.push('  - CITE SPECIFIC role names, numbers. Be the guy who actually knows everything.]');

    // Inject additional live server snapshot
    try {
      const channels = guild.channels.cache.filter(c => c.type === 0).map(c => c.name).slice(0, 10);
      const memberCount = guild.memberCount;
      const boostLevel = guild.premiumTier || 0;
      const boostCount = guild.premiumSubscriptionCount || 0;
      const owner = guild.members.cache.get(guild.ownerId);
      const ownerName = owner?.displayName || owner?.user?.username || 'unknown';
      const createdAt = guild.createdAt?.toLocaleDateString('en-IN') || 'unknown';

      parts.push(`[LIVE SERVER SNAPSHOT FOR YOUR ANSWER:`);
      parts.push(`  Server: ${guild.name}`);
      parts.push(`  Members: ${memberCount}`);
      parts.push(`  Owner: ${ownerName}`);
      parts.push(`  Created: ${createdAt}`);
      parts.push(`  Channels: #${channels.join(', #')}`);
      parts.push(`  Boost: Level ${boostLevel} (${boostCount} boosts)`);

      // List all roles with member counts
      const roles = guild.roles.cache
        .filter(r => r.name !== '@everyone')
        .sort((a, b) => b.position - a.position)
        .map(r => `${r.name} (${r.members.size} members)`)
        .slice(0, 20);
      parts.push(`  All Roles (top to bottom): ${roles.join(', ')}`);

      // Online members
      const online = guild.members.cache.filter(m => !m.user.bot && m.presence?.status && m.presence.status !== 'offline');
      if (online.size > 0) {
        parts.push(`  Online now: ${online.map(m => m.displayName || m.user.username).slice(0, 15).join(', ')} (${online.size} total)`);
      }
      parts.push(']');
    } catch (e) { /* best effort */ }
  }

  if (questionCtx.type === 'opinion') {
    parts.push('[INSTRUCTION: User wants your OPINION. You have STRONG views on everything.');
    parts.push('  Give a real, spicy take. Be controversial. Be interesting. Take a side.');
    parts.push('  Do NOT say "idk" or "pata nahi". You always have an opinion.]');
  }

  return parts.join('\n');
}

module.exports = {
  postProcessReply,
  detectQuestionType,
  calculateReplyTier,
  REPLY_TIERS,
  quickQualityCheck,
  buildRegenPrompt,
  buildKnowledgeBoost,
  learnServerStyle,
  getServerStyle,
  buildStyleHint,
  trackBotReply,
  getReplyQualityInsight,
};
