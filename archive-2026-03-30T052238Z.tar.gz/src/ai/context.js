const { getRecentMessages, getStrongestPairs, getMostIgnoredUsers, getMostRepliedUsers, getChannelVibe, getUserStats, getServerMemories, getActiveThread, getMessageVelocity, getUniqueActiveUsers, getIgnoredMessages, getUserNotes, getHighConfidenceNotes, getActiveSession } = require('../database/server');
const { getUser, getUserMemories } = require('../database/global');
const { buildSystemPrompt, buildUserContext, buildSocialContext, buildFriendsContext, buildChannelContext } = require('./personality');
const { analyzeServerRoles, analyzeUserRoles, buildRoleContextForAI, buildUserRoleContext } = require('../analysis/roles');
const { detectDynamics, getUserConnections } = require('../analysis/socialGraph');
const { formatIST } = require('../utils/helpers');
const { getUserContextSummary } = require('../database/userData');
const config = require('../config');

/**
 * Build the full messages array for the AI call.
 */
function buildFullContext(message, guild) {
  const guildId = guild.id;
  const channelId = message.channel.id;
  const username = message.author.displayName || message.author.username;
  const content = message.content || '';

  // Get channel vibe
  const vibeData = getChannelVibe(guildId, channelId);
  const channelVibe = vibeData ? `${vibeData.current_vibe} / ${vibeData.activity_level}` : 'neutral';

  // Bot roles in server
  const botMember = guild.members.cache.get(message.client.user.id);
  const botRoles = botMember?.roles?.cache?.filter((r) => r.name !== '@everyone').map((r) => r.name).join(', ') || '';

  // Role hierarchy context for AI
  let roleContext = '';
  let serverInfo = '';
  try {
    roleContext = buildRoleContextForAI(guild);
    const hierarchy = analyzeServerRoles(guild);
    serverInfo = `[Server Info: ${hierarchy.totalMembers} members, ${hierarchy.totalRoles} roles, Boost Level ${guild.premiumTier || 0}]`;
  } catch (e) {
    // Role analysis optional
  }

  // Current time in IST
  const currentTimeIST = formatIST();

  // System prompt
  const systemPrompt = buildSystemPrompt({
    serverName: guild.name,
    channelName: message.channel.name,
    channelVibe,
    botRoles,
    roleContext,
    serverInfo,
    currentTimeIST,
  });

  // Get recent messages for context
  const recentMsgs = getRecentMessages(guildId, channelId, config.bot.contextMessageCount);

  // Build conversation history — tag bots
  const conversationMessages = [];
  const seenUsers = new Set();

  for (const msg of recentMsgs) {
    seenUsers.add(msg.user_id);
    const role = msg.is_bot_message ? 'assistant' : 'user';
    // Tag bot messages so AI knows who is a bot
    let prefix = '';
    if (!msg.is_bot_message) {
      // Check if this user is a bot (from guild member cache)
      const member = guild.members.cache.get(msg.user_id);
      const isBot = member?.user?.bot || false;
      prefix = isBot ? `[BOT ${msg.username}]: ` : `[${msg.username}]: `;
    }
    conversationMessages.push({
      role,
      content: `${prefix}${msg.content}`,
    });
  }

  // Build context about the current user who triggered
  const triggerUser = getUser(message.author.id);
  const triggerMemories = getUserMemories(message.author.id, 15);
  const triggerServerStats = getUserStats(guildId, message.author.id);

  // Get user role analysis
  let triggerRoleAnalysis = null;
  try {
    if (message.member) {
      triggerRoleAnalysis = analyzeUserRoles(guild, message.member);
    }
  } catch (e) {
    // Optional
  }

  // Get AI notes about this user
  const userNotes = getUserNotes(guildId, message.author.id, 8);

  const userCtx = buildUserContext(triggerUser, triggerMemories, triggerServerStats, triggerRoleAnalysis, userNotes, message.author.bot);

  // Build social context
  const pairs = getStrongestPairs(guildId, 6);
  const ignored = getMostIgnoredUsers(guildId, 4);
  const magnets = getMostRepliedUsers(guildId, 4);
  const dynamics = detectDynamics(guildId);
  const socialCtx = buildSocialContext(pairs, ignored, magnets, dynamics);

  // Build friends context for the triggering user
  const userConnections = getUserConnections(guildId, message.author.id);
  const friendsCtx = buildFriendsContext(userConnections);

  // Build channel context (velocity, active users, ignored messages)
  const velocity = getMessageVelocity(guildId, channelId, 300);
  const activeUsers = getUniqueActiveUsers(guildId, channelId, 600);
  const ignoredMsgs = getIgnoredMessages(guildId, channelId, 3);
  // Filter out the triggering user's own messages from ignored list
  // This prevents the AI from saying "nobody replied to your message"
  const filteredIgnored = ignoredMsgs.filter(m => m.user_id !== message.author.id);
  const activeThread = getActiveThread(guildId, channelId);

  // Get some member names for member list awareness
  let memberList = [];
  try {
    const onlineMembers = guild.members.cache
      .filter((m) => !m.user.bot && m.presence?.status && m.presence.status !== 'offline')
      .map((m) => m.displayName || m.user.username)
      .slice(0, 20);
    memberList = onlineMembers;
  } catch (e) { /* optional */ }

  // Channel topic awareness
  const channelTopic = message.channel.topic || '';

  const channelCtx = buildChannelContext({ velocity, activeUsers, ignoredMessages: filteredIgnored, activeThread, memberList, channelTopic });

  // Server memories (observations)
  const serverMems = getServerMemories(guildId, channelId, 10);
  const serverMemCtx = serverMems.length > 0
    ? '[Recent server observations:\n' + serverMems.map((m) => `  - ${m.content}`).join('\n') + '\n]'
    : '';

  // Active conversation session with this user
  let sessionCtx = '';
  try {
    const session = getActiveSession(guildId, channelId, message.author.id);
    if (session && session.context_summary) {
      sessionCtx = `[Active conversation with ${message.author.username} (${session.message_count} msgs):\n${session.context_summary.slice(-300)}\n]`;
    }
  } catch (e) { /* optional */ }

  // Per-user persistent data (from individual user files)
  let perUserCtx = '';
  try {
    const userDataSummary = getUserContextSummary(message.author.id);
    if (userDataSummary) {
      perUserCtx = `[YOUR MEMORY ABOUT ${username}:\n${userDataSummary}\n]`;
    }
  } catch (e) { /* optional */ }

  // Compose the final context injection
  const contextNote = [
    '--- CONTEXT (invisible to users, only for your understanding) ---',
    userCtx,
    perUserCtx,
    friendsCtx,
    socialCtx,
    channelCtx,
    serverMemCtx,
    `[Current time: ${currentTimeIST}]`,
    `[Users active in recent chat: ${seenUsers.size}]`,
    sessionCtx,
    `[TARGET: You are replying to ${username}. Message: "${content.slice(0, 200)}". RESPOND TO THIS.]`,
    `[ANTI-REPETITION: Do NOT repeat your recent replies. Say something DIFFERENT.]`,
    '--- END CONTEXT ---',
  ].filter(Boolean).join('\n');

  // Final messages array
  // Place recent chat history, then the focused context + trigger message at the end
  const messages = [
    { role: 'system', content: systemPrompt },
    { role: 'system', content: contextNote },
    ...conversationMessages.slice(-30),
    // Re-inject the triggering message as the absolute last user message
    // This ensures the AI knows EXACTLY who it's replying to and what they said
    { role: 'user', content: `[${username}]: ${content}` },
  ];

  return messages;
}

/**
 * Build context for proactive engagement (no trigger message).
 */
function buildEngagementContext(guild, channel, recentMsgs) {
  const guildId = guild.id;
  const vibeData = getChannelVibe(guildId, channel.id);
  const channelVibe = vibeData ? `${vibeData.current_vibe} / ${vibeData.activity_level}` : 'neutral';

  const botMember = guild.members.cache.get(guild.client?.user?.id);
  const botRoles = botMember?.roles?.cache?.filter((r) => r.name !== '@everyone').map((r) => r.name).join(', ') || '';

  let roleContext = '';
  try {
    roleContext = buildRoleContextForAI(guild);
  } catch (e) { /* optional */ }

  const currentTimeIST = formatIST();

  const systemPrompt = buildSystemPrompt({
    serverName: guild.name,
    channelName: channel.name,
    channelVibe,
    botRoles,
    roleContext,
    currentTimeIST,
  });

  const conversationMessages = recentMsgs.map((msg) => {
    if (msg.is_bot_message) {
      return { role: 'assistant', content: msg.content };
    }
    const member = guild.members.cache.get(msg.user_id);
    const isBot = member?.user?.bot || false;
    const prefix = isBot ? `[BOT ${msg.username}]: ` : `[${msg.username}]: `;
    return { role: 'user', content: `${prefix}${msg.content}` };
  });

  const pairs = getStrongestPairs(guildId, 5);
  const ignored = getMostIgnoredUsers(guildId, 3);
  const magnets = getMostRepliedUsers(guildId, 3);
  const dynamics = detectDynamics(guildId);
  const socialCtx = buildSocialContext(pairs, ignored, magnets, dynamics);

  // Channel velocity for engagement awareness
  const velocity = getMessageVelocity(guildId, channel.id, 300);
  const ignoredMsgs = getIgnoredMessages(guildId, channel.id, 3);
  const channelCtx = buildChannelContext({ velocity, ignoredMessages: ignoredMsgs });

  const contextNote = [
    '--- CONTEXT ---',
    socialCtx,
    channelCtx,
    `[Current time: ${currentTimeIST}]`,
    '[You are entering the chat proactively. Drop an observation, comment on the vibe, call someone out playfully, or highlight an ignored message. Keep it natural and short.]',
    '[REMINDER: NEVER ping @everyone, @here, or any role. Only ping individual users.]',
    '--- END CONTEXT ---',
  ].filter(Boolean).join('\n');

  return [
    { role: 'system', content: systemPrompt },
    { role: 'system', content: contextNote },
    ...conversationMessages.slice(-40),
  ];
}

/**
 * Build context for welcome messages.
 */
function buildWelcomeContext(guild, member) {
  const currentTimeIST = formatIST();

  const systemPrompt = `You are ${config.bot.name} — a real member of "${guild.name}" Discord server. NOT a bot. Made by ${config.bot.maker}.

A new member just joined the server! Welcome them like a real person would — warm, casual, maybe a little playful.

Rules:
- Be natural and human-like. No generic "Welcome to the server!" stuff
- Use their name or username naturally
- Be friendly but not cringe. Like greeting someone new at a party
- Keep it 1-3 lines max
- If their username is funny or interesting, comment on it
- Use lowercase. Don't be formal
- Don't use asterisks or markdown
- Match the vibe of the server
- IST timezone: ${currentTimeIST}
- NEVER ping @everyone, @here, or any role
- You CAN ping the new user with <@${member.id}>

Respond with ONLY the welcome message. No prefix, no quotes.`;

  return [{ role: 'system', content: systemPrompt }];
}

module.exports = { buildFullContext, buildEngagementContext, buildWelcomeContext };
