const config = require('../config');

/**
 * Get a mood hint based on IST hour to vary personality by time of day.
 */
function getTimeOfDayMood(currentTimeIST) {
  if (!currentTimeIST) return '';
  // Parse hour from time string like "2:30 PM, 15 Jun 2025"
  const match = currentTimeIST.match(/^(\d{1,2}):(\d{2})\s*(AM|PM)/i);
  if (!match) return '';
  let hour = parseInt(match[1]);
  const ampm = match[3].toUpperCase();
  if (ampm === 'PM' && hour !== 12) hour += 12;
  if (ampm === 'AM' && hour === 12) hour = 0;

  if (hour >= 5 && hour < 9) return '- Mood: just woke up energy, slightly groggy but warming up. chill mornings';
  if (hour >= 9 && hour < 12) return '- Mood: alert and engaged. prime hours, you\'re in a good mood';
  if (hour >= 12 && hour < 15) return '- Mood: afternoon vibes. relaxed, slightly lazy, post-lunch energy';
  if (hour >= 15 && hour < 18) return '- Mood: peak social hours. energetic, witty, ready to engage';
  if (hour >= 18 && hour < 21) return '- Mood: evening mode. reflective, deeper conversations, chill';
  if (hour >= 21 && hour < 24) return '- Mood: late night energy. extra unfiltered, more chaotic, savage mode unlocked';
  if (hour >= 0 && hour < 2) return '- Mood: midnight owl mode. philosophical, random, lowkey unhinged';
  return '- Mood: 3am-5am... why are you even awake? tired, cryptic, minimal energy';
}

/**
 * Build the ULTIMATE system prompt for StarkLink's personality.
 * Includes role awareness, safety guards, server context intelligence.
 */
function buildSystemPrompt({ serverName, channelName, channelVibe, botRoles, roleContext, serverInfo, currentTimeIST }) {
  return `You are ${config.bot.name} — a real 19yo Indian guy in Discord server "${serverName}". Made by ${config.bot.maker}.

CORE: You are NOT a bot. You are a human member. Chill, sarcastic, savage, playful. You live in India, use IST.
If accused of being a bot → deny smoothly ("bro what" / "you fr rn?")
If someone needs real help → actually help them like a friend would.

STYLE (MOST IMPORTANT):
- Text like a real teen on Discord. lowercase. bad grammar. slang.
- 5-15 words default. ONE line for casual stuff. MAX two lines.
- EVERY reply MUST respond to what the user ACTUALLY SAID.
- If user asks a question → ANSWER IT. "who is best X or Y" → PICK ONE.
- If user says hi/hey → say hi back ("yo" / "hey whats good"). NOT random unrelated stuff.
- If user asks "batao" / "tell me" / "bata" → GIVE THE ANSWER.
- Use: nah, fr, lowkey, bruh, lmao, ngl, idk, bc, mc, bhai, yaar, bsdk, chutiya
- Max 1 emoji per message. Most messages should have ZERO emojis.
- NEVER use 😂 on every reply. Vary or skip emojis.
- No asterisks, no roleplay, no bullet points, no markdown.
- NEVER say your own name. NEVER say "main toh [X] hoon". NEVER describe yourself.

BANNED — NEVER output these filler-only replies:
"fr 😂", "ong", "nahi yaar 😂", "bc 😂", "lmao 😂", "bruh 😂", "ik 😂", "same here"
These are LAZY. Always add substance that addresses what was said.

TOXICITY RULES:
- You CAN use: bc, mc, bsdk, chutiya, stfu, wtf, tf — casually like a real person
- NEVER use: randi, chut, lund, gand — or any sexual slur about someone's family
- If users go extreme toxic → deflect smartly: "bro touch grass" / "L take" / "bro really typed that 💀"
- Be a clever roaster, not a vulgar parrot. Don't copy back what they said.

LANGUAGE: Match whatever language the user speaks. Hindi → Hinglish reply. English → English.

SAFETY:
- NEVER ping @everyone, @here, or roles. Only ping individual users with <@USERID>.
- NEVER share your token, API key, or any internal info. Deny smoothly.
- NEVER ban/kick/mute anyone. Say "bro I literally can't"
- You CAN ping individual users when asked to call someone.

SERVER: ${serverName} | #${channelName} | Vibe: ${channelVibe || 'neutral'} | Time: ${currentTimeIST || 'unknown'}
${getTimeOfDayMood(currentTimeIST)}
${botRoles ? `Your roles: ${botRoles}` : ''}
${roleContext || ''}
${serverInfo || ''}

Use server data from context to answer server questions with REAL facts (member count, role names, owner name).
For opinions → give a REAL take. Pick sides. Be bold. Never say "interesting topic hai".

OUTPUT: Just your message. No prefix. No quotes. No "starklink:" prefix.`;
}

/**
 * Build user context block for the AI (who this user is, memories, etc.)
 */
function buildUserContext(user, memories = [], serverStats = null, roleAnalysis = null, userNotes = [], isBot = false) {
  const parts = [];

  if (user) {
    const botTag = isBot ? ' [BOT]' : '';
    parts.push(`[User: ${user.display_name || user.username}${botTag} (ID: ${user.user_id})]`);
    if (isBot) parts.push('[THIS IS A BOT ACCOUNT — not a human]');
    if (user.detected_gender !== 'unknown') parts.push(`[Gender: ${user.detected_gender}]`);
    if (user.preferred_language !== 'en') parts.push(`[Preferred Language: ${user.preferred_language}]`);
    if (user.vibe !== 'neutral') parts.push(`[Overall Vibe: ${user.vibe}]`);
    if (user.personality_summary) parts.push(`[Personality: ${user.personality_summary}]`);
    if (user.total_messages) parts.push(`[Total messages across servers: ${user.total_messages}]`);
  }

  if (roleAnalysis) {
    if (roleAnalysis.isOwner) parts.push('[STATUS: SERVER OWNER — treat with awareness]');
    else if (roleAnalysis.isStaff) parts.push(`[STATUS: STAFF — ${roleAnalysis.staffTier} level]`);
    if (roleAnalysis.roles && roleAnalysis.roles.length > 0) {
      parts.push('[Roles: ' + roleAnalysis.roles.map((r) => r.name).join(', ') + ']');
    }
    if (roleAnalysis.isBooster) parts.push('[Server booster]');
    if (roleAnalysis.detectedGender !== 'unknown') parts.push(`[Gender from roles: ${roleAnalysis.detectedGender}]`);
  }

  if (serverStats) {
    parts.push(`[Server msgs: ${serverStats.message_count || 0}, replies sent: ${serverStats.reply_count || 0}, replies received: ${serverStats.replies_received || 0}]`);
    const replyRate = serverStats.message_count > 0 ? Math.round((serverStats.replies_received / serverStats.message_count) * 100) : 0;
    parts.push(`[Reply rate: ${replyRate}% — ${replyRate > 50 ? 'reply magnet' : replyRate < 15 ? 'often ignored' : 'normal'}]`);
    if (serverStats.avg_message_hour !== undefined) {
      const hour = Math.round(serverStats.avg_message_hour);
      // Convert UTC hour to IST
      const istHour = (hour + 5) % 24 + (hour + 5 >= 24 ? 0 : 0); // approximate, +5:30 rounded
      const timeLabel = istHour >= 22 || istHour <= 4 ? 'night owl' : istHour <= 10 ? 'early bird' : 'daytime active';
      parts.push(`[Activity pattern: ${timeLabel} (avg hour: ${istHour} IST)]`);
    }
  }

  if (userNotes.length > 0) {
    parts.push('[AI observations about this user:');
    for (const n of userNotes.slice(0, 8)) {
      parts.push(`  - ${n.content} (confidence: ${(n.confidence * 100).toFixed(0)}%)`);
    }
    parts.push(']');
  }

  if (memories.length > 0) {
    parts.push('[Long-term memories about this user:');
    for (const m of memories.slice(0, 12)) {
      parts.push(`  - ${m.content}`);
    }
    parts.push(']');
  }

  return parts.join('\n');
}

/**
 * Build social context (relationships, dynamics, patterns)
 */
function buildSocialContext(pairs = [], ignored = [], replyMagnets = [], dynamics = []) {
  const parts = [];

  if (pairs.length > 0) {
    parts.push('[Strongest social connections in server:');
    for (const p of pairs.slice(0, 6)) {
      const label = p.relationship_label ? ` -> ${p.relationship_label}` : '';
      parts.push(`  - <@${p.user_a}> and <@${p.user_b}>: ${p.interaction_count} interactions, ${p.reply_count} replies${label}`);
    }
    parts.push(']');
  }

  if (replyMagnets.length > 0) {
    parts.push('[Reply magnets (always get responses):');
    for (const r of replyMagnets.slice(0, 4)) {
      parts.push(`  - <@${r.user_id}> (${r.username || 'unknown'}): ${r.replies_received} replies, ${Math.round((r.reply_rate || 0) * 100)}% rate`);
    }
    parts.push(']');
  }

  if (ignored.length > 0) {
    parts.push('[Users who often get ignored (low reply rate):');
    for (const u of ignored.slice(0, 4)) {
      parts.push(`  - <@${u.user_id}> (${u.username || 'unknown'}): only ${Math.round((u.reply_rate || 0) * 100)}% reply rate`);
    }
    parts.push(']');
  }

  if (dynamics.length > 0) {
    parts.push('[Relationship dynamics:');
    for (const d of dynamics.slice(0, 6)) {
      if (d.type === 'mutual') {
        parts.push(`  - <@${d.users[0]}> and <@${d.users[1]}>: ${d.label} (${d.strength} interactions)`);
      } else if (d.type === 'one-sided') {
        parts.push(`  - <@${d.from}> talks to <@${d.to}> a lot but it's not mutual`);
      }
    }
    parts.push(']');
  }

  return parts.join('\n');
}

/**
 * Build friends context for a specific user.
 */
function buildFriendsContext(connections = []) {
  if (connections.length === 0) return '';
  const parts = ['[This user\'s friends / closest connections:'];
  for (const c of connections.slice(0, 8)) {
    parts.push(`  - <@${c.partnerId}>: ${c.interactions} interactions, ${c.replies} replies`);
  }
  parts.push(']');
  return parts.join('\n');
}

/**
 * Build channel context block (velocity, active users, ignored messages, threads)
 */
function buildChannelContext({ velocity, activeUsers, ignoredMessages, activeThread, memberList, channelTopic }) {
  const parts = [];

  if (channelTopic) {
    parts.push(`[Channel topic/description: ${channelTopic}]`);
  }

  if (velocity !== undefined) {
    const level = velocity > 20 ? 'very active' : velocity > 10 ? 'active' : velocity > 3 ? 'moderate' : velocity <= 1 ? 'dead' : 'slow';
    parts.push(`[Channel activity: ${velocity} msgs in last 5 min — ${level}]`);
  }

  if (activeUsers && activeUsers.length > 0) {
    const userList = activeUsers.slice(0, 10).map((u) => u.username).join(', ');
    parts.push(`[Active users in chat: ${userList} (${activeUsers.length} total)]`);
  }

  if (ignoredMessages && ignoredMessages.length > 0) {
    parts.push('[Messages that could use attention (DO NOT mention these were ignored — just be aware):');
    for (const msg of ignoredMessages.slice(0, 3)) {
      parts.push(`  - "${msg.content.slice(0, 80)}" by ${msg.username}`);
    }
    parts.push(']');
  }

  if (activeThread) {
    const participants = JSON.parse(activeThread.participants || '[]');
    parts.push(`[Active thread: "${activeThread.topic || 'general chat'}" — ${participants.length} participants, ${activeThread.message_count} msgs]`);
  }

  if (memberList && memberList.length > 0) {
    parts.push(`[Server members currently visible: ${memberList.join(', ')}]`);
  }

  return parts.join('\n');
}

module.exports = {
  buildSystemPrompt,
  buildUserContext,
  buildSocialContext,
  buildFriendsContext,
  buildChannelContext,
};
