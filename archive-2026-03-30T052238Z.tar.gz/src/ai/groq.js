const OpenAI = require('openai');
const { existsSync, mkdirSync, readFileSync, writeFileSync } = require('fs');
const { join } = require('path');
const config = require('../config');

let openai;
const openaiApiKey = config.openai?.apiKey || process.env.OPENAI_API_KEY;
const hasOpenAiKey = Boolean(openaiApiKey);
try {
  openai = new OpenAI({ apiKey: openaiApiKey || 'placeholder' });
} catch (e) {
  console.warn('[OPENAI] Failed to initialize client:', e.message);
}

if (!hasOpenAiKey) {
  console.warn('[OPENAI] OPENAI_API_KEY is not set. AI replies will be disabled.');
}

// Track rate limit/backoff state per model
const modelState = new Map();

// --- Concurrency & queue throttling ---
const MAX_CONCURRENT = Number(process.env.OPENAI_MAX_CONCURRENT || 12);
const RATE_WINDOW_MS = 60000;
const MAX_PER_MINUTE = Number(process.env.OPENAI_MAX_PER_MINUTE || 180);
let activeRequests = 0;
const requestTimestamps = [];
const pendingQueue = [];

// Latency tracking
const latencyStats = { total: 0, count: 0, max: 0, lastAvg: 0 };

// Budget tracking (monthly)
const BUDGET_FILE = join(config.paths.data, 'openai-budget.json');
const PRICING_USD_PER_1M = {
  // Conservative estimates for budget safety. Override via env if needed.
  'gpt-4.1-mini': { in: 0.6, out: 2.4 },
  'gpt-4o-mini': { in: 0.3, out: 1.2 },
  'gpt-4.1-nano': { in: 0.15, out: 0.6 },
  default: { in: 0.7, out: 2.8 },
};

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function getLatencyStats() {
  const budget = readBudgetState();
  return {
    avgMs: latencyStats.count > 0 ? Math.round(latencyStats.total / latencyStats.count) : 0,
    maxMs: latencyStats.max,
    requests: latencyStats.count,
    monthSpendUsd: Number((budget.spentUsd || 0).toFixed(4)),
    monthBudgetUsd: getBudgetLimits().monthlyUsd,
  };
}

function cleanTimestamps() {
  const cutoff = Date.now() - RATE_WINDOW_MS;
  while (requestTimestamps.length > 0 && requestTimestamps[0] < cutoff) {
    requestTimestamps.shift();
  }
}

function canMakeRequest() {
  cleanTimestamps();
  return activeRequests < MAX_CONCURRENT && requestTimestamps.length < MAX_PER_MINUTE;
}

function processQueue() {
  while (pendingQueue.length > 0 && canMakeRequest()) {
    const { resolve } = pendingQueue.shift();
    resolve();
  }
}

function waitForSlot() {
  if (canMakeRequest()) return Promise.resolve();
  return new Promise((resolve) => {
    pendingQueue.push({ resolve });
    setTimeout(processQueue, 2000);
  });
}

async function throttledRequest(fn) {
  await waitForSlot();
  activeRequests++;
  requestTimestamps.push(Date.now());
  const start = Date.now();
  try {
    const result = await fn();
    const elapsed = Date.now() - start;
    latencyStats.total += elapsed;
    latencyStats.count++;
    if (elapsed > latencyStats.max) latencyStats.max = elapsed;
    latencyStats.lastAvg = Math.round(latencyStats.total / latencyStats.count);
    return result;
  } finally {
    activeRequests--;
    processQueue();
  }
}

function getModelState(modelId) {
  if (!modelState.has(modelId)) {
    modelState.set(modelId, { failedAt: 0, consecutiveFails: 0 });
  }
  return modelState.get(modelId);
}

function isModelAvailable(modelId) {
  const state = getModelState(modelId);
  if (state.consecutiveFails === 0) return true;
  const backoffMs = Math.min(state.consecutiveFails * 30000, 300000);
  return Date.now() - state.failedAt > backoffMs;
}

function markModelFailed(modelId) {
  const state = getModelState(modelId);
  state.failedAt = Date.now();
  state.consecutiveFails++;
}

function markModelSuccess(modelId) {
  const state = getModelState(modelId);
  state.consecutiveFails = 0;
}

function getBudgetMonthKey() {
  const now = new Date();
  return `${now.getUTCFullYear()}-${String(now.getUTCMonth() + 1).padStart(2, '0')}`;
}

function defaultBudgetState() {
  return {
    month: getBudgetMonthKey(),
    spentUsd: 0,
    requests: 0,
    promptTokens: 0,
    completionTokens: 0,
    updatedAt: Date.now(),
  };
}

function ensureBudgetDir() {
  const dir = config.paths.data;
  if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
}

function readBudgetState() {
  ensureBudgetDir();
  if (!existsSync(BUDGET_FILE)) return defaultBudgetState();
  try {
    const raw = readFileSync(BUDGET_FILE, 'utf-8');
    const data = JSON.parse(raw);
    if (!data || typeof data !== 'object') return defaultBudgetState();
    if (data.month !== getBudgetMonthKey()) return defaultBudgetState();
    return data;
  } catch (e) {
    return defaultBudgetState();
  }
}

function writeBudgetState(state) {
  ensureBudgetDir();
  try {
    writeFileSync(BUDGET_FILE, JSON.stringify(state, null, 2), 'utf-8');
  } catch (e) {
    console.error('[OPENAI] Failed writing budget file:', e.message);
  }
}

function getBudgetLimits() {
  const monthlyUsd = Number(config.openai?.budget?.monthlyUsd || 10);
  const softLimitRatio = Number(config.openai?.budget?.softLimitRatio || 0.85);
  const hardLimitRatio = Number(config.openai?.budget?.hardLimitRatio || 0.98);
  return { monthlyUsd, softLimitRatio, hardLimitRatio };
}

function getPricing(modelId) {
  return PRICING_USD_PER_1M[modelId] || PRICING_USD_PER_1M.default;
}

function estimateRequestCostUsd(modelId, usage) {
  if (!usage) return 0;
  const inTokens = Number(usage.prompt_tokens || 0);
  const outTokens = Number(usage.completion_tokens || 0);
  const pricing = getPricing(modelId);
  return (inTokens / 1000000) * pricing.in + (outTokens / 1000000) * pricing.out;
}

function recordUsageCost(modelId, usage) {
  if (!usage) return;
  const state = readBudgetState();
  const cost = estimateRequestCostUsd(modelId, usage);
  state.spentUsd += cost;
  state.requests += 1;
  state.promptTokens += Number(usage.prompt_tokens || 0);
  state.completionTokens += Number(usage.completion_tokens || 0);
  state.updatedAt = Date.now();
  writeBudgetState(state);
}

function isHardBudgetReached() {
  const state = readBudgetState();
  const limits = getBudgetLimits();
  return state.spentUsd >= limits.monthlyUsd * limits.hardLimitRatio;
}

function isSoftBudgetReached() {
  const state = readBudgetState();
  const limits = getBudgetLimits();
  return state.spentUsd >= limits.monthlyUsd * limits.softLimitRatio;
}

function modelsByCostAscending(models) {
  return [...models].sort((a, b) => {
    const pa = getPricing(a.id);
    const pb = getPricing(b.id);
    const ca = pa.in + pa.out;
    const cb = pb.in + pb.out;
    return ca - cb;
  });
}

function getChatModelChain() {
  const configured = config.openai?.models || [];
  if (configured.length === 0) return [];

  // Near budget edge, prioritize cheaper models first.
  if (isSoftBudgetReached()) {
    return modelsByCostAscending(configured);
  }
  return configured;
}

function getAnalysisModelChain() {
  const configured = config.openai?.analysisModels || [];
  if (configured.length > 0) return configured;
  return getChatModelChain();
}

function getRetryAfterMs(err) {
  const h = err?.headers || err?.response?.headers || {};
  const retryAfterMs = Number(h['retry-after-ms']);
  if (Number.isFinite(retryAfterMs) && retryAfterMs > 0) return retryAfterMs;

  const retryAfterSec = Number(h['retry-after']);
  if (Number.isFinite(retryAfterSec) && retryAfterSec > 0) return retryAfterSec * 1000;

  return 0;
}

function isRetriableError(err) {
  const status = Number(err?.status || err?.code || 0);
  return status === 408 || status === 409 || status === 429 || status >= 500;
}

async function requestWithRetry(requestFn, maxAttempts = 3) {
  let lastErr;

  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      return await throttledRequest(requestFn);
    } catch (err) {
      lastErr = err;
      if (!isRetriableError(err) || attempt === maxAttempts) break;

      const retryAfter = getRetryAfterMs(err);
      const base = Math.min(1000 * (2 ** (attempt - 1)), 8000);
      const jitter = Math.floor(Math.random() * 350);
      const waitMs = Math.max(retryAfter, base + jitter);
      await sleep(waitMs);
    }
  }

  throw lastErr;
}

// Junk patterns that models sometimes return instead of real answers
const JUNK_RESPONSE_PATTERNS = [
  /^okay\.?$/i,
  /^ok\.?$/i,
  /^sure\.?$/i,
  /^alright\.?$/i,
  /^hmm+\.?$/i,
  /^hm+\.?$/i,
  /^ah+\.?$/i,
  /^oh+\.?$/i,
  /^\.{1,5}$/,
  /^[\s\n]*$/,
  /^\*?(thinks?|thinking|pondering|considering)\*?\.?$/i,
];

/**
 * Strip reasoning tags and validate output is usable.
 */
function cleanModelOutput(raw) {
  if (!raw) return null;
  let content = raw;

  content = content.replace(/<think>[\s\S]*?<\/think>/gi, '').trim();
  content = content.replace(/<think>[\s\S]*/gi, '').trim();
  content = content.replace(/<reasoning>[\s\S]*?<\/reasoning>/gi, '').trim();
  content = content.replace(/<reasoning>[\s\S]*/gi, '').trim();
  content = content.replace(/<output>|<\/output>/gi, '').trim();

  if (!content || content.length < 1) return null;

  for (const pattern of JUNK_RESPONSE_PATTERNS) {
    if (pattern.test(content.trim())) return null;
  }

  return content.trim();
}

/**
 * Call OpenAI with fallback chain + retry + budget controls.
 */
async function chat(messages, opts = {}) {
  if (!openai || !hasOpenAiKey) {
    console.error('[OPENAI] Client unavailable');
    return { content: null, model: null };
  }

  if (isHardBudgetReached()) {
    console.warn('[OPENAI] Monthly budget hard-limit reached, skipping AI request');
    return { content: null, model: null };
  }

  const temperature = opts.temperature ?? 0.9;
  const errors = [];
  const thinkTagModels = [];
  const modelChain = getChatModelChain();

  for (const model of modelChain) {
    if (!isModelAvailable(model.id)) continue;

    try {
      const response = await requestWithRetry(() =>
        openai.chat.completions.create({
          model: model.id,
          messages,
          temperature,
          max_tokens: opts.maxTokens || model.maxTokens || 512,
          top_p: 0.95,
          frequency_penalty: opts.frequencyPenalty ?? 0.3,
          presence_penalty: opts.presencePenalty ?? 0.4,
        }),
      3);

      const raw = response.choices?.[0]?.message?.content;
      if (!raw) {
        markModelFailed(model.id);
        continue;
      }

      const content = cleanModelOutput(raw);
      if (!content) {
        console.warn(`[OPENAI] ${model.id} returned reasoning/junk, trying next model`);
        thinkTagModels.push(model);
        continue;
      }

      recordUsageCost(model.id, response.usage);
      markModelSuccess(model.id);
      return { content, model: model.id };
    } catch (err) {
      markModelFailed(model.id);
      errors.push({ model: model.id, error: err.message || String(err), status: err?.status || null });
    }
  }

  // Retry models that produced reasoning output with explicit instruction.
  if (thinkTagModels.length > 0 && !isHardBudgetReached()) {
    const retryMessages = [...messages, {
      role: 'system',
      content: 'CRITICAL: Do NOT output <think> tags, reasoning blocks, or internal thoughts. Reply directly with final answer text only.',
    }];

    for (const model of thinkTagModels) {
      if (!isModelAvailable(model.id)) continue;
      try {
        const response = await requestWithRetry(() =>
          openai.chat.completions.create({
            model: model.id,
            messages: retryMessages,
            temperature: Math.min(temperature + 0.05, 1.0),
            max_tokens: opts.maxTokens || model.maxTokens || 512,
            top_p: 0.95,
            frequency_penalty: opts.frequencyPenalty ?? 0.3,
            presence_penalty: opts.presencePenalty ?? 0.4,
          }),
        2);

        const raw = response.choices?.[0]?.message?.content;
        const content = cleanModelOutput(raw);
        if (content) {
          recordUsageCost(model.id, response.usage);
          markModelSuccess(model.id);
          return { content, model: model.id };
        }
      } catch (err) {
        markModelFailed(model.id);
      }
    }
  }

  console.error('[OPENAI] All models failed:', errors);
  return { content: null, model: null };
}

/**
 * Quick analysis call (cheap model chain + budget-aware)
 */
async function analyze(prompt, opts = {}) {
  if (!openai || !hasOpenAiKey || isHardBudgetReached()) return null;

  const messages = [
    { role: 'system', content: 'You are a concise analytical assistant. Respond with only the requested format, no extra text.' },
    { role: 'user', content: prompt },
  ];

  const modelChain = getAnalysisModelChain();

  for (const model of modelChain) {
    if (!isModelAvailable(model.id)) continue;
    try {
      const response = await requestWithRetry(() =>
        openai.chat.completions.create({
          model: model.id,
          messages,
          temperature: 0.3,
          max_tokens: opts.maxTokens || model.maxTokens || 220,
        }),
      2);

      const raw = response.choices?.[0]?.message?.content;
      const content = cleanModelOutput(raw);
      if (content) {
        recordUsageCost(model.id, response.usage);
        markModelSuccess(model.id);
        return content;
      }

      console.warn(`[OPENAI:analyze] ${model.id} returned reasoning/junk, trying next`);
    } catch (err) {
      markModelFailed(model.id);
    }
  }

  return null;
}

module.exports = { chat, analyze, getLatencyStats };
