const config = require('../config');
const { chat } = require('../ai/groq');
const { buildFullContext } = require('../ai/context');
const { shouldRespond, shouldReact, getReactionEmoji, markBotReplied, resetConsecutive, trackUserMessage } = require('../engine/decision');
const { handleCommand } = require('../commands/handler');
const { logMessage, isUserIgnored, ignoreUser, unignoreUser, getRecentMessages, updateUserStats, getActiveThread, startConversationThread, updateThread, addUserNote, getActiveSession, startSession, updateSession, expireOldSessions } = require('../database/server');
const { upsertUser, incrementUserMessages } = require('../database/global');
const { trackUserBehavior } = require('../analysis/behavior');
const { processMessageForSocialGraph, trackReply } = require('../analysis/socialGraph');
const { detectAndUpdateUserLanguage, analyzeChannelVibe } = require('../analysis/language');
const { extractAndStoreMemories, extractServerObservations, updateUserProfile } = require('../memory/manager');
const { sleep, truncate, sanitizeBotOutput } = require('../utils/helpers');
const { postProcessReply, learnServerStyle, buildStyleHint, trackBotReply, getReplyQualityInsight, detectQuestionType, calculateReplyTier, REPLY_TIERS, quickQualityCheck, buildRegenPrompt, buildKnowledgeBoost } = require('../ai/autoTuner');
const { logConversation } = require('../utils/conversationLogger');
const { trackUserMessage: trackUserDataMessage, logUserConversation, getUserContextSummary } = require('../database/userData');

// Track message counts for periodic analysis
const messageCounters = new Map();

async function handleMessageCreate(message) {
  // Ignore all bots (including self) and DMs
  if (message.author.bot) return;
  if (!message.guild) return;

  const guildId = message.guild.id;
  const channelId = message.channel.id;
  const userId = message.author.id;

  // --- Update user data (mark as NOT a bot) ---
  upsertUser(userId, message.author.username, message.author.displayName || '', false);
  incrementUserMessages(userId);

  // Track in per-user data file (persistent memory per user)
  trackUserDataMessage(userId, message.author.username, message.author.displayName || '', message.content);

  // Track in server DB
  if (message.member) {
    trackUserBehavior(guildId, message.member, message);
  }

  // Detect language
  if (message.content.length > 10) {
    detectAndUpdateUserLanguage(userId, message.content);
  }

  // Process social graph
  processMessageForSocialGraph(guildId, message);

  // Track reply relationships
  let replyToUserId = null;
  if (message.reference?.messageId) {
    try {
      const recentMsgs = getRecentMessages(guildId, channelId, 100);
      const repliedMsg = recentMsgs.find((m) => m.message_id === message.reference.messageId);
      if (repliedMsg) {
        replyToUserId = repliedMsg.user_id;
        trackReply(guildId, userId, replyToUserId);
      }
    } catch (e) {
      // Ignore
    }
  }

  // Log the message
  logMessage(guildId, {
    messageId: message.id,
    channelId,
    userId,
    username: message.author.displayName || message.author.username,
    content: truncate(message.content, 2000),
    isBotMessage: false,
    replyToUserId,
    replyToMessageId: message.reference?.messageId || null,
  });

  // Update conversation thread tracking
  try {
    const activeThread = getActiveThread(guildId, channelId);
    if (activeThread) {
      updateThread(guildId, activeThread.id, userId);
    } else if (message.content.length > 20) {
      startConversationThread(guildId, channelId, '', userId);
    }
  } catch (e) {
    // Thread tracking is best-effort
  }

  // Reset consecutive reply counter (non-bot message came in)
  resetConsecutive(channelId);

  // Track user message for spam detection
  trackUserMessage(userId, guildId);

  // --- Handle commands ---
  const wasCommand = await handleCommand(message);
  if (wasCommand) return;

  // --- Decision engine ---
  const decision = shouldRespond(message, guildId);

  // Handle "fuck off" / "bye" silent treatment
  if (decision.silentUser) {
    // Don't respond but maybe react for bye
    if (decision.reason === 'user_said_bye') {
      try { await message.react('👋'); } catch (e) { /* */ }
    }
    return;
  }

  // If user was ignored but pinged bot -> unignore
  if (decision.reason === 'mentioned' && isUserIgnored(guildId, userId)) {
    unignoreUser(guildId, userId);
  }

  // Should we just react instead?
  if (!decision.shouldReply && shouldReact(message)) {
    try {
      const emoji = getReactionEmoji(message.content);
      await message.react(emoji);
    } catch (e) {
      // Can't react
    }
    return;
  }

  if (!decision.shouldReply) return;

  // --- Generate AI response ---
  try {
    // Show typing indicator
    await message.channel.sendTyping();

    // Wait for the human-like delay
    if (decision.delay && decision.delay > 0) {
      await sleep(Math.min(decision.delay, 20000));
      if (decision.delay > 5000) {
        await message.channel.sendTyping().catch(() => {});
      }
    }

    // Build context
    const messages = buildFullContext(message, message.guild);

    // ADAPTIVE REPLY SIZING — picks the perfect tier based on message analysis
    const questionCtx = calculateReplyTier(message.content);
    const tier = questionCtx.tier;

    // Inject learned style hint if available
    const styleHint = buildStyleHint(guildId);
    const qualityHint = getReplyQualityInsight();
    if (styleHint || qualityHint) {
      messages.splice(messages.length - 1, 0, {
        role: 'system',
        content: (styleHint + '\n' + qualityHint).trim(),
      });
    }

    // Inject knowledge boost for questions that need real data
    const knowledgeBoost = buildKnowledgeBoost(questionCtx, message.guild);
    if (knowledgeBoost) {
      messages.splice(messages.length - 1, 0, {
        role: 'system',
        content: knowledgeBoost,
      });
    }

    // Inject tier-specific instruction so the AI knows the expected length
    const tierHints = {
      micro: '[REPLY LENGTH: MICRO. 1-5 words MAX. Single word energy. "lol", "fr", "nah", "bruh what 💀"]',
      short: '[REPLY LENGTH: SHORT. 5-15 words. One punchy line like a real teen texting. No essays.]',
      medium: '[REPLY LENGTH: MEDIUM. 1-3 sentences. Give a real answer but keep it tight and natural.]',
      long: '[REPLY LENGTH: LONG. 2-5 sentences. Give detailed info, real data, proper answer. This is a real question.]',
      full: '[REPLY LENGTH: FULL. As much as needed (up to 8 sentences). Give a thorough, helpful, detailed answer. User needs real help.]',
    };
    messages.splice(messages.length - 1, 0, {
      role: 'system',
      content: tierHints[tier.label] || tierHints.short,
    });

    // Use tier's maxTokens
    const maxTokens = tier.maxTokens;

    // Call AI
    let result = await chat(messages, {
      temperature: tier.label === 'micro' ? 1.0 : tier.label === 'full' ? 0.85 : 0.92,
      maxTokens,
      frequencyPenalty: 0.5,
      presencePenalty: 0.6,
    });

    if (!result.content) {
      console.error('[AI] Empty response from all models');
      return;
    }

    // Clean up response
    let response = result.content;
    // Final safety net: strip any leaked think/reasoning tags
    response = response.replace(/<think>[\s\S]*?<\/think>/gi, '').trim();
    response = response.replace(/<think>[\s\S]*/gi, '').trim();
    response = response.replace(/<reasoning>[\s\S]*?<\/reasoning>/gi, '').trim();
    response = response.replace(/<reasoning>[\s\S]*/gi, '').trim();
    response = response.replace(/<output>|<\/output>/gi, '').trim();
    response = response.replace(/^(starklink|stark\s*link)\s*[:]\s*/i, '');
    if (response.startsWith('"') && response.endsWith('"')) {
      response = response.slice(1, -1);
    }

    // Post-process (question-aware — won't truncate knowledge answers)
    response = postProcessReply(response, questionCtx);

    // Quality gate: check if reply actually answers the question
    if (response) {
      const qualityCheck = quickQualityCheck(response, message.content, questionCtx);
      if (!qualityCheck.pass) {
        // Reply is vague/bad — regen with specific fix prompt
        const regenMessages = [...messages];
        regenMessages.push({
          role: 'assistant',
          content: response, // show the AI what it said wrong
        });
        regenMessages.push({
          role: 'system',
          content: buildRegenPrompt(qualityCheck.issue, questionCtx, message.content),
        });
        const regen = await chat(regenMessages, {
          temperature: 0.85,
          maxTokens: Math.min(tier.maxTokens + 50, 400),
          frequencyPenalty: 0.4,
          presencePenalty: 0.5,
        });
        if (regen.content) {
          let regenResponse = regen.content.replace(/^(starklink|stark\s*link)\s*[:]\s*/i, '');
          if (regenResponse.startsWith('"') && regenResponse.endsWith('"')) regenResponse = regenResponse.slice(1, -1);
          regenResponse = postProcessReply(regenResponse, questionCtx);
          if (regenResponse) response = regenResponse;
        }
      }
    }

    // If post-processing nuked the reply entirely, try ONE last regen
    if (!response) {
      const regenMessages = [...messages];
      regenMessages.push({
        role: 'system',
        content: 'YOUR LAST REPLY WAS TOO AI-SOUNDING. This time: reply in MAX 8 WORDS. Be casual. No explanations. Think: how would a bored 19 year old reply to this? One short line ONLY.',
      });
      const regen = await chat(regenMessages, {
        temperature: 1.0,
        maxTokens: 40,
        frequencyPenalty: 0.7,
        presencePenalty: 0.7,
      });
      if (regen.content) {
        response = regen.content.replace(/^(starklink|stark\s*link)\s*[:]\s*/i, '');
        if (response.startsWith('"') && response.endsWith('"')) response = response.slice(1, -1);
        response = postProcessReply(response, questionCtx);
      }
    }

    // CRITICAL SAFETY: Sanitize output
    if (response) response = sanitizeBotOutput(response, message.client.user.id);

    // Truncate for Discord
    response = truncate(response, 1900);

    if (!response) return;

    // Send the response — ALWAYS reply to the person so they get notified
    let sent;
    try {
      sent = await message.reply(response);
    } catch (e) {
      // Fallback to channel.send if reply fails (e.g., original message deleted)
      sent = await message.channel.send(response);
    }

    // Log bot's message
    logMessage(guildId, {
      messageId: sent.id,
      channelId,
      userId: message.client.user.id,
      username: config.bot.name,
      content: response,
      isBotMessage: true,
      replyToUserId: userId,
      replyToMessageId: message.id,
    });

    markBotReplied(channelId, userId, guildId);

    // Log user -> bot conversation for training data
    logConversation({
      serverName: message.guild.name,
      channelName: message.channel.name,
      username: message.author.displayName || message.author.username,
      userMessage: message.content,
      botReply: response,
    });

    // Log to per-user data file (persistent memory)
    logUserConversation(userId, message.author.username, message.content, response);

    // Track reply for auto-tuner quality analysis
    trackBotReply(guildId, response);

    // --- Session tracking ---
    try {
      const existingSession = getActiveSession(guildId, channelId, userId);
      const shortSummary = `${message.author.username}: ${message.content.slice(0, 80)} -> bot: ${response.slice(0, 80)}`;
      if (existingSession) {
        const newSummary = (existingSession.context_summary + '\n' + shortSummary).slice(-500);
        updateSession(guildId, existingSession.id, newSummary);
      } else {
        startSession(guildId, channelId, userId, shortSummary);
      }
    } catch (e) { /* session tracking is best-effort */ }

    // Expire old sessions periodically
    if (Math.random() < 0.05) {
      try { expireOldSessions(guildId); } catch (e) { /* */ }
    }

    // --- Background tasks (non-blocking) ---
    const counter = (messageCounters.get(`${guildId}-${channelId}`) || 0) + 1;
    messageCounters.set(`${guildId}-${channelId}`, counter);

    if (counter % 25 === 0) {
      setImmediate(async () => {
        try {
          const recentMsgs = getRecentMessages(guildId, channelId, 50);
          await analyzeChannelVibe(guildId, channelId, recentMsgs);
          await extractServerObservations(guildId, recentMsgs);

          // Auto-learn server style every 50 messages
          if (counter % 50 === 0) {
            await learnServerStyle(guildId, channelId);
          }

          const activeUsers = new Set(recentMsgs.filter((m) => !m.is_bot_message).map((m) => m.user_id));
          for (const activeUserId of [...activeUsers].slice(0, 3)) {
            const activeUser = recentMsgs.find((m) => m.user_id === activeUserId);
            if (activeUser) {
              await extractAndStoreMemories(activeUserId, activeUser.username, recentMsgs, guildId);
            }
          }

          if (counter % 75 === 0) {
            for (const activeUserId of [...activeUsers].slice(0, 2)) {
              const activeUser = recentMsgs.find((m) => m.user_id === activeUserId);
              if (activeUser) {
                const summary = await updateUserProfile(activeUserId, activeUser.username, recentMsgs);
                if (summary) {
                  const { updateUserField } = require('../database/global');
                  updateUserField(activeUserId, 'personality_summary', summary);
                }
              }
            }
          }
        } catch (e) {
          console.error('[BACKGROUND] Analysis error:', e.message);
        }
      });
    }
  } catch (err) {
    console.error('[MESSAGE] Error handling message:', err);
  }
}

module.exports = { handleMessageCreate };
