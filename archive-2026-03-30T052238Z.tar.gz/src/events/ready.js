const { handleMessageCreate } = require('./messageCreate');
const { handleSlashCommand } = require('../commands/handler');
const { registerSlashCommands } = require('../commands/slashCommands');
const { engagementLoop, pingInactiveUsers } = require('../engine/timing');
const { invalidateRoleCache } = require('../analysis/roles');
const { buildWelcomeContext } = require('../ai/context');
const { chat, getLatencyStats } = require('../ai/groq');
const { sanitizeBotOutput, formatIST } = require('../utils/helpers');
const { getServerConfig, logMessage, cleanupOldMessages } = require('../database/server');
const { upsertUser } = require('../database/global');
const logger = require('../utils/logger');
const config = require('../config');

function registerEvents(client) {
  // --- Ready Event ---
  client.once('ready', async () => {
    console.log(`[READY] ${config.bot.name} is online as ${client.user.tag}`);
    console.log(`[READY] Serving ${client.guilds.cache.size} servers`);
    console.log(`[READY] Prefix: ${config.discord.prefix}`);
    console.log(`[READY] Time: ${formatIST()} (IST)`);

    // Set bot status
    client.user.setPresence({
      activities: [{ name: 'the chat', type: 3 }],
      status: 'online',
    });

    // Fetch member lists for all guilds (so bot can see members)
    for (const guild of client.guilds.cache.values()) {
      try {
        await guild.members.fetch({ limit: 500, time: 30000 });
        console.log(`[MEMBERS] Fetched ${guild.members.cache.size} members for ${guild.name}`);
      } catch (e) {
        console.error(`[MEMBERS] Failed to fetch for ${guild.name}:`, e.message);
      }
    }

    // Register bots in global DB
    for (const guild of client.guilds.cache.values()) {
      for (const member of guild.members.cache.values()) {
        if (member.user.bot && member.user.id !== client.user.id) {
          upsertUser(member.user.id, member.user.username, member.user.displayName || '', true);
        }
      }
    }

    // --- Start engagement loops ---
    setInterval(() => {
      engagementLoop(client).catch((err) => {
        console.error('[ENGAGEMENT LOOP]', err.message);
      });
    }, config.bot.engagementInterval);

    setInterval(() => {
      pingInactiveUsers(client).catch((err) => {
        console.error('[INACTIVE PING]', err.message);
      });
    }, 1800000);

    setTimeout(() => {
      engagementLoop(client).catch(() => {});
    }, 120000);

    // --- Health heartbeat (every 5 minutes) ---
    setInterval(() => {
      const mem = process.memoryUsage();
      const latency = getLatencyStats();
      logger.info('HEARTBEAT', `guilds=${client.guilds.cache.size} users=${client.users.cache.size} rss=${Math.round(mem.rss / 1024 / 1024)}MB heap=${Math.round(mem.heapUsed / 1024 / 1024)}MB ai_avg=${latency.avgMs}ms ai_reqs=${latency.requests}`);
    }, 300000);

    // --- DB cleanup on startup + daily ---
    try {
      for (const guild of client.guilds.cache.values()) {
        cleanupOldMessages(guild.id, 30);
      }
      logger.info('CLEANUP', 'Initial DB cleanup completed');
    } catch (e) { /* best-effort */ }

    setInterval(() => {
      for (const guild of client.guilds.cache.values()) {
        try { cleanupOldMessages(guild.id, 30); } catch (_) { /* skip */ }
      }
      logger.info('CLEANUP', 'Daily DB cleanup completed');
    }, 86400000);

    // Register slash commands
    await registerSlashCommands(client);
  });

  // --- Interaction Event (Slash Commands) ---
  client.on('interactionCreate', async (interaction) => {
    try {
      await handleSlashCommand(interaction);
    } catch (err) {
      console.error('[INTERACTION]', err);
    }
  });

  // --- Message Event ---
  client.on('messageCreate', (message) => {
    handleMessageCreate(message).catch((err) => {
      console.error('[MESSAGE EVENT]', err);
    });
  });

  // --- New Member Join (Welcome System) ---
  client.on('guildMemberAdd', async (member) => {
    try {
      // Register in global DB
      upsertUser(member.user.id, member.user.username, member.user.displayName || '', member.user.bot);

      // Skip bot accounts for welcome
      if (member.user.bot) return;

      const guild = member.guild;
      const guildId = guild.id;

      // Check if welcome is enabled
      const welcomeChannelId = getServerConfig(guildId, 'welcome_channel');
      if (!welcomeChannelId) return;

      const channel = guild.channels.cache.get(welcomeChannelId);
      if (!channel) return;

      // Generate human-like welcome message
      const messages = buildWelcomeContext(guild, member);

      // Add member info to the context
      messages.push({
        role: 'user',
        content: `New member just joined! Username: ${member.user.username}, Display name: ${member.displayName || member.user.username}, Account created: ${member.user.createdAt.toISOString()}. ${member.user.avatar ? 'They have a profile picture.' : 'No profile picture (default avatar).'} Welcome them naturally.`,
      });

      const result = await chat(messages, {
        temperature: 0.95,
        maxTokens: 200,
      });

      if (result.content) {
        let welcome = sanitizeBotOutput(result.content);
        welcome = welcome.replace(/^(starklink|stark\s*link)\s*[:]\s*/i, '');
        if (welcome.startsWith('"') && welcome.endsWith('"')) {
          welcome = welcome.slice(1, -1);
        }

        if (welcome) {
          const sent = await channel.send(welcome);
          logMessage(guildId, {
            messageId: sent.id,
            channelId: channel.id,
            userId: client.user.id,
            username: config.bot.name,
            content: welcome,
            isBotMessage: true,
          });
        }
      }
    } catch (e) {
      console.error('[WELCOME]', e.message);
    }
  });

  // --- Guild Join ---
  client.on('guildCreate', async (guild) => {
    console.log(`[GUILD] Joined: ${guild.name} (${guild.id})`);
    const { getServerDb } = require('../database/server');
    getServerDb(guild.id);

    // Fetch members for new guild
    try {
      await guild.members.fetch({ limit: 500, time: 30000 });
    } catch (e) { /* best-effort */ }
  });

  // --- Member Updates (role changes, nickname changes) ---
  client.on('guildMemberUpdate', (oldMember, newMember) => {
    if (oldMember.roles.cache.size !== newMember.roles.cache.size) {
      const { detectGenderFromRoles } = require('../analysis/behavior');
      const { updateUserField } = require('../database/global');
      const { updateUserStats, updateRoleSnapshot } = require('../database/server');
      const { analyzeUserRoles } = require('../analysis/roles');

      invalidateRoleCache(newMember.guild.id);

      const gender = detectGenderFromRoles(newMember);
      if (gender !== 'unknown') {
        updateUserField(newMember.id, 'detected_gender', gender);
        updateUserStats(newMember.guild.id, newMember.id, { detectedGender: gender });
      }

      try {
        const roleAnalysis = analyzeUserRoles(newMember.guild, newMember);
        if (roleAnalysis) {
          const roles = newMember.roles.cache.filter((r) => r.name !== '@everyone').map((r) => r.name);
          updateRoleSnapshot(
            newMember.guild.id,
            newMember.id,
            JSON.stringify(roles),
            roleAnalysis.isStaff,
            roleAnalysis.staffTier || '',
            roleAnalysis.detectedGender || gender
          );
        }
      } catch (e) { /* best-effort */ }
    }
  });

  // --- Role Updates (invalidate cache) ---
  client.on('roleCreate', (role) => {
    invalidateRoleCache(role.guild.id);
  });

  client.on('roleDelete', (role) => {
    invalidateRoleCache(role.guild.id);
  });

  client.on('roleUpdate', (oldRole, newRole) => {
    invalidateRoleCache(newRole.guild.id);
  });

  // --- Reaction tracking ---
  client.on('messageReactionAdd', async (reaction, user) => {
    if (user.bot) return;
    try {
      const message = reaction.message.partial ? await reaction.message.fetch() : reaction.message;
      if (!message.guild) return;

      const { trackReaction } = require('../analysis/socialGraph');
      trackReaction(message.guild.id, {
        messageId: message.id,
        channelId: message.channel.id,
        userId: user.id,
        emoji: reaction.emoji.name || reaction.emoji.toString(),
        targetUserId: message.author?.id || null,
      });
    } catch (e) { /* best-effort */ }
  });

  // --- Error Handling ---
  client.on('error', (err) => {
    console.error('[CLIENT ERROR]', err);
  });

  client.on('warn', (warn) => {
    console.warn('[CLIENT WARN]', warn);
  });
}

module.exports = { registerEvents };
