const { readFileSync, existsSync } = require('fs');
const path = require('path');

// Load .env manually (no dotenv dependency)
const envPath = path.join(__dirname, '..', '.env');
if (existsSync(envPath)) {
  const envContent = readFileSync(envPath, 'utf-8');
  for (const line of envContent.split('\n')) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const eqIdx = trimmed.indexOf('=');
    if (eqIdx === -1) continue;
    const key = trimmed.slice(0, eqIdx).trim();
    const val = trimmed.slice(eqIdx + 1).trim();
    if (!process.env[key]) process.env[key] = val;
  }
}

module.exports = {
  discord: {
    token: process.env.DISCORD_TOKEN,
    prefix: process.env.BOT_PREFIX || '$',
    ownerId: process.env.OWNER_ID || '',
  },
  openai: {
    apiKey: process.env.OPENAI_API_KEY,
    // Fallback chain optimized for quality + budget safety
    models: [
      { id: 'gpt-4.1-mini', maxTokens: 512, label: 'main' },
      { id: 'gpt-4o-mini', maxTokens: 512, label: 'backup' },
      { id: 'gpt-4.1-nano', maxTokens: 512, label: 'budget' },
    ],
    // Analysis/utility calls should prefer the cheapest reliable models
    analysisModels: [
      { id: 'gpt-4.1-nano', maxTokens: 220, label: 'analyze-fast' },
      { id: 'gpt-4o-mini', maxTokens: 220, label: 'analyze-fallback' },
    ],
    budget: {
      monthlyUsd: Number(process.env.OPENAI_BUDGET_USD || 10),
      // Start aggressively downgrading model selection near budget edge
      softLimitRatio: Number(process.env.OPENAI_SOFT_LIMIT_RATIO || 0.85),
      // Hard stop to prevent accidental overspend
      hardLimitRatio: Number(process.env.OPENAI_HARD_LIMIT_RATIO || 0.98),
    },
  },
  groq: {
    // Legacy compatibility fields for old commands/modules.
    // Mirrors OpenAI chain so older code paths still display valid models.
    apiKey: process.env.OPENAI_API_KEY,
    models: [
      { id: 'gpt-4.1-mini', maxTokens: 512, label: 'main' },
      { id: 'gpt-4o-mini', maxTokens: 512, label: 'backup' },
      { id: 'gpt-4.1-nano', maxTokens: 512, label: 'budget' },
    ],
  },
  paths: {
    data: path.join(__dirname, '..', 'data'),
    servers: path.join(__dirname, '..', 'data', 'servers'),
    globalDb: path.join(__dirname, '..', 'data', 'global.db'),
  },
  bot: {
    name: 'starklink',
    maker: 'moggerstark',
    // Timing config (ms)
    replyDelayMin: 5000,        // 5 sec minimum delay
    replyDelayMax: 20000,       // 20 sec max delay
    cooldownPerChannel: 30000,  // 30 sec cooldown per channel
    // How many messages to read for context
    contextMessageCount: 100,
    // Engagement loop interval (ms) — check for inactive users etc.
    engagementInterval: 300000, // 5 minutes
    // Max messages before forced cooldown
    maxConsecutiveReplies: 3,
    // Chance to randomly ignore a triggerable message (0-1)
    ignoreChance: 0.15,
    // Chance to react instead of reply
    reactChance: 0.08,
  },
};
