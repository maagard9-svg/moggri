const { getUserStats, updateUserStats, trackActivitySession, updateRoleSnapshot } = require('../database/server');
const { getUser, updateUserField } = require('../database/global');
const { analyzeUserRoles } = require('./roles');

/**
 * Detect user's gender from their Discord roles.
 * Enhanced with comprehensive keyword matching.
 */
function detectGenderFromRoles(member) {
  if (!member?.roles?.cache) return 'unknown';

  const roleNames = member.roles.cache.map((r) => r.name.toLowerCase());

  const maleIndicators = ['he/him', 'male', 'boy', 'guy', 'man', 'king', 'prince', 'bro', 'mr', 'gentleman', 'dude', 'lad', 'sir'];
  const femaleIndicators = ['she/her', 'female', 'girl', 'woman', 'queen', 'princess', 'sis', 'mrs', 'miss', 'ms', 'lady', 'goddess', 'ma\'am'];
  const nbIndicators = ['they/them', 'non-binary', 'nonbinary', 'enby', 'nb', 'agender', 'genderfluid', 'genderqueer'];

  for (const role of roleNames) {
    for (const ind of femaleIndicators) {
      if (role.includes(ind)) return 'female';
    }
    for (const ind of maleIndicators) {
      if (role.includes(ind)) return 'male';
    }
    for (const ind of nbIndicators) {
      if (role.includes(ind)) return 'non-binary';
    }
  }

  return 'unknown';
}

/**
 * Update behavior tracking for a user message.
 * Now includes activity session tracking and role snapshots.
 */
function trackUserBehavior(guildId, member, message) {
  const userId = member.id || member.user?.id;
  if (!userId) return;

  const channelId = message.channel?.id;

  // Update message stats
  updateUserStats(guildId, userId, { incrementMessages: true });
  updateUserStats(guildId, userId, { username: message.author?.displayName || message.author?.username || '' });

  // Detect and cache gender from roles
  const gender = detectGenderFromRoles(member);
  if (gender !== 'unknown') {
    updateUserStats(guildId, userId, { detectedGender: gender });
    updateUserField(userId, 'detected_gender', gender);
  }

  // Cache roles
  if (member.roles?.cache) {
    const roles = member.roles.cache.filter((r) => r.name !== '@everyone').map((r) => r.name);
    updateUserStats(guildId, userId, { rolesCache: roles });

    // Update role snapshot with staff detection
    try {
      if (member.guild) {
        const roleAnalysis = analyzeUserRoles(member.guild, member);
        if (roleAnalysis) {
          updateRoleSnapshot(
            guildId,
            userId,
            JSON.stringify(roles),
            roleAnalysis.isStaff,
            roleAnalysis.staffTier || '',
            roleAnalysis.detectedGender || gender
          );
        }
      }
    } catch (e) {
      // Role analysis is optional
    }
  }

  // Track activity session
  if (channelId) {
    try {
      trackActivitySession(guildId, userId, channelId);
    } catch (e) {
      // Activity tracking is best-effort
    }
  }

  // Track average active hour
  const hour = new Date().getUTCHours();
  const stats = getUserStats(guildId, userId);
  if (stats) {
    const count = stats.message_count || 1;
    const currentAvg = stats.avg_message_hour || 12;
    const newAvg = (currentAvg * (count - 1) + hour) / count;
    updateUserStats(guildId, userId, { avgHour: Math.round(newAvg * 10) / 10 });
  }
}

/**
 * Analyze user activity patterns — comprehensive profile.
 */
function getUserBehaviorProfile(guildId, userId) {
  const stats = getUserStats(guildId, userId);
  const globalUser = getUser(userId);

  if (!stats) return null;

  const replyRate = stats.message_count > 0 ? stats.replies_received / stats.message_count : 0;
  const mentionRate = stats.message_count > 0 ? stats.mentions_received / stats.message_count : 0;

  let activityPattern = 'average';
  if (stats.avg_message_hour >= 22 || stats.avg_message_hour <= 4) activityPattern = 'night owl';
  else if (stats.avg_message_hour >= 6 && stats.avg_message_hour <= 10) activityPattern = 'early bird';
  else if (stats.avg_message_hour >= 11 && stats.avg_message_hour <= 14) activityPattern = 'midday active';
  else if (stats.avg_message_hour >= 18 && stats.avg_message_hour <= 21) activityPattern = 'evening warrior';

  let influence = 'normal';
  if (replyRate > 0.6) influence = 'reply magnet (everyone responds)';
  else if (replyRate > 0.4) influence = 'popular';
  else if (replyRate < 0.08 && stats.message_count > 15) influence = 'often ignored';
  else if (mentionRate > 0.3) influence = 'frequently called out';

  let engagementLevel = 'casual';
  if (stats.message_count > 500) engagementLevel = 'power user';
  else if (stats.message_count > 100) engagementLevel = 'active';
  else if (stats.message_count > 30) engagementLevel = 'regular';
  else if (stats.message_count < 5) engagementLevel = 'lurker';

  return {
    userId,
    username: stats.username || globalUser?.username || 'unknown',
    messageCount: stats.message_count,
    replyRate: Math.round(replyRate * 100),
    mentionRate: Math.round(mentionRate * 100),
    activityPattern,
    avgHour: stats.avg_message_hour,
    influence,
    engagementLevel,
    gender: stats.detected_gender || globalUser?.detected_gender || 'unknown',
    language: globalUser?.preferred_language || 'en',
    firstSeen: stats.first_seen,
    lastSeen: stats.last_seen,
  };
}

module.exports = {
  detectGenderFromRoles,
  trackUserBehavior,
  getUserBehaviorProfile,
};
