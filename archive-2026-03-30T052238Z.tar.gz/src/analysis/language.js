const { analyze } = require('../ai/groq');
const { updateUserField } = require('../database/global');
const { updateChannelVibe } = require('../database/server');

// Simple language mapping for common languages using character detection
const SCRIPT_PATTERNS = [
  { lang: 'ar', pattern: /[\u0600-\u06FF]/ },
  { lang: 'hi', pattern: /[\u0900-\u097F]/ },
  { lang: 'zh', pattern: /[\u4E00-\u9FFF]/ },
  { lang: 'ja', pattern: /[\u3040-\u30FF]/ },
  { lang: 'ko', pattern: /[\uAC00-\uD7AF]/ },
  { lang: 'th', pattern: /[\u0E00-\u0E7F]/ },
  { lang: 'ru', pattern: /[\u0400-\u04FF]/ },
  { lang: 'bn', pattern: /[\u0980-\u09FF]/ },
  { lang: 'ta', pattern: /[\u0B80-\u0BFF]/ },
  { lang: 'te', pattern: /[\u0C00-\u0C7F]/ },
];

/**
 * Detect language from text using script detection + keyword heuristics.
 * Fast, no external dependency needed.
 */
function detectLanguage(text) {
  if (!text || text.length < 5) return 'en';

  // Check script-based detection first
  for (const { lang, pattern } of SCRIPT_PATTERNS) {
    if (pattern.test(text)) return lang;
  }

  // Common word patterns for Latin-script languages
  const lower = text.toLowerCase();

  // Spanish
  if (/\b(hola|como|estas|gracias|donde|cuando|porque|pero|también|ahora|bueno|qué|está|tiene)\b/.test(lower)) return 'es';
  // French
  if (/\b(bonjour|merci|comment|pourquoi|aussi|beaucoup|très|avec|dans|sont|nous|vous|cette)\b/.test(lower)) return 'fr';
  // German
  if (/\b(hallo|danke|warum|nicht|haben|diese|werden|können|müssen|schon|auch)\b/.test(lower)) return 'de';
  // Portuguese
  if (/\b(obrigado|como|você|muito|também|quando|porque|agora|então)\b/.test(lower)) return 'pt';
  // Italian
  if (/\b(ciao|grazie|come|perché|anche|molto|quando|adesso|questo)\b/.test(lower)) return 'it';
  // Turkish
  if (/\b(merhaba|nasıl|teşekkür|evet|hayır|neden|çok|için|bir|olan)\b/.test(lower)) return 'tr';
  // Indonesian/Malay
  if (/\b(terima kasih|apa|bagaimana|tidak|sudah|dengan|dari|untuk|yang|ini)\b/.test(lower)) return 'id';
  // Hindi (Romanized)
  if (/\b(kya|kaise|hai|hain|nahi|bhai|yaar|acha|abhi|kuch|bohot|bahut|mujhe|tujhe|woh|kab)\b/.test(lower)) return 'hi';
  // Urdu (Romanized)
  if (/\b(kya|kaise|hai|nahi|bhai|yaar|mashallah|inshallah|jaldi|acha)\b/.test(lower)) return 'ur';

  return 'en';
}

/**
 * Detect the dominant language of a channel from recent messages.
 */
function detectChannelLanguage(messages) {
  const langCounts = {};
  for (const msg of messages) {
    if (msg.is_bot_message) continue;
    const lang = detectLanguage(msg.content);
    langCounts[lang] = (langCounts[lang] || 0) + 1;
  }

  let maxLang = 'en';
  let maxCount = 0;
  for (const [lang, count] of Object.entries(langCounts)) {
    if (count > maxCount) {
      maxLang = lang;
      maxCount = count;
    }
  }

  return maxLang;
}

/**
 * Detect user's preferred language and update their profile.
 */
function detectAndUpdateUserLanguage(userId, text) {
  const lang = detectLanguage(text);
  if (lang !== 'en') {
    updateUserField(userId, 'preferred_language', lang);
  }
  return lang;
}

/**
 * Analyze the vibe/mood of recent chat messages.
 */
async function analyzeChannelVibe(guildId, channelId, messages) {
  if (messages.length < 5) {
    updateChannelVibe(guildId, channelId, 'quiet', 'low');
    return { vibe: 'quiet', activity: 'low', topic: '' };
  }

  const chatSnippet = messages.slice(-20).map((m) => `${m.username}: ${m.content}`).join('\n');

  const prompt = `Analyze this Discord chat. Respond with ONLY a JSON object:
{"vibe": "one word mood (chill/heated/dead/funny/flirty/toxic/chaotic/deep/gaming/random)", "activity": "low/normal/high/very_high", "topic": "main topic in 3-5 words or empty string"}

Chat:
${chatSnippet}`;

  try {
    const result = await analyze(prompt, { maxTokens: 60 });
    if (!result) return null;

    const cleaned = result.replace(/```json?\n?/g, '').replace(/```/g, '').trim();
    const data = JSON.parse(cleaned);

    updateChannelVibe(guildId, channelId, data.vibe || 'neutral', data.activity || 'normal', data.topic || '');
    return data;
  } catch (e) {
    return null;
  }
}

module.exports = {
  detectLanguage,
  detectChannelLanguage,
  detectAndUpdateUserLanguage,
  analyzeChannelVibe,
};
