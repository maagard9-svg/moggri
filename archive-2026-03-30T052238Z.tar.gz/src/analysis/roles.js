/**
 * Role Hierarchy & Server Info Analysis Engine
 * Reads all roles, detects staff/admin/mod hierarchy, categorizes members.
 * SAFETY: NEVER pings roles, NEVER assigns/removes roles, NEVER pings @everyone/@here.
 */

// Cache role data per guild (refresh every 5 min)
const roleCache = new Map();
const CACHE_TTL = 300000; // 5 min

// Staff role keyword detection (priority order)
const STAFF_KEYWORDS = [
  { keywords: ['owner', 'founder', 'creator'], tier: 'owner', level: 100 },
  { keywords: ['admin', 'administrator'], tier: 'admin', level: 90 },
  { keywords: ['head mod', 'head moderator', 'senior mod', 'lead mod'], tier: 'head_mod', level: 80 },
  { keywords: ['moderator', 'mod', 'moderation'], tier: 'moderator', level: 70 },
  { keywords: ['staff', 'team', 'official', 'management'], tier: 'staff', level: 65 },
  { keywords: ['helper', 'support', 'trial mod', 'junior mod'], tier: 'helper', level: 55 },
  { keywords: ['vip', 'premium', 'donator', 'donor', 'booster', 'nitro booster', 'supporter'], tier: 'vip', level: 40 },
  { keywords: ['verified', 'member', 'regular', 'trusted'], tier: 'member', level: 20 },
  { keywords: ['muted', 'jailed', 'restricted', 'timeout', 'quarantine'], tier: 'restricted', level: -10 },
];

// Gender role detection
const GENDER_KEYWORDS = {
  male: ['he/him', 'male', 'boy', 'guy', 'man', 'king', 'prince', 'bro', 'mr', 'gentleman', 'dude'],
  female: ['she/her', 'female', 'girl', 'woman', 'queen', 'princess', 'sis', 'mrs', 'miss', 'ms', 'lady', 'goddess'],
  nonbinary: ['they/them', 'non-binary', 'nonbinary', 'enby', 'nb', 'agender', 'genderfluid'],
};

// Color/vanity role detection
const VANITY_KEYWORDS = ['color', 'colour', 'aesthetic', 'custom', 'cosmetic', 'name color', 'pronoun'];

// Activity/level role patterns
const LEVEL_PATTERN = /^(level|lvl|lv)\s*\d+$/i;
const RANK_PATTERN = /^(rank|tier)\s*\d+$/i;

/**
 * Analyze all roles in a guild and build a structured hierarchy.
 * Returns cached if fresh, otherwise re-analyzes.
 */
function analyzeServerRoles(guild) {
  const cached = roleCache.get(guild.id);
  if (cached && Date.now() - cached.analyzedAt < CACHE_TTL) return cached;

  const roles = guild.roles.cache
    .filter((r) => r.name !== '@everyone')
    .sort((a, b) => b.position - a.position); // Highest first

  const hierarchy = {
    guildId: guild.id,
    guildName: guild.name,
    totalRoles: roles.size,
    totalMembers: guild.memberCount,
    analyzedAt: Date.now(),
    staffRoles: [],
    genderRoles: [],
    vanityRoles: [],
    levelRoles: [],
    botRoles: [],
    otherRoles: [],
    tiers: {},        // tier name -> array of role info
    roleMap: {},      // role id -> role info
    highestStaffRole: null,
  };

  for (const [, role] of roles) {
    const roleName = role.name.toLowerCase().trim();
    const roleInfo = {
      id: role.id,
      name: role.name,
      position: role.position,
      color: role.hexColor,
      memberCount: role.members.size,
      hoisted: role.hoist,
      mentionable: role.mentionable,
      managed: role.managed, // Bot-managed roles
      permissions: [],
      tier: 'other',
      staffLevel: 0,
    };

    // Detect key permissions (for understanding hierarchy without modifying)
    const perms = role.permissions;
    if (perms.has('Administrator')) roleInfo.permissions.push('Administrator');
    if (perms.has('ManageGuild')) roleInfo.permissions.push('ManageServer');
    if (perms.has('ManageRoles')) roleInfo.permissions.push('ManageRoles');
    if (perms.has('ManageChannels')) roleInfo.permissions.push('ManageChannels');
    if (perms.has('ManageMessages')) roleInfo.permissions.push('ManageMessages');
    if (perms.has('BanMembers')) roleInfo.permissions.push('BanMembers');
    if (perms.has('KickMembers')) roleInfo.permissions.push('KickMembers');
    if (perms.has('MentionEveryone')) roleInfo.permissions.push('MentionEveryone');
    if (perms.has('ManageNicknames')) roleInfo.permissions.push('ManageNicknames');

    // Categorize role
    let categorized = false;

    // Check if it's a bot role
    if (role.managed) {
      hierarchy.botRoles.push(roleInfo);
      roleInfo.tier = 'bot';
      categorized = true;
    }

    // Check staff keywords
    if (!categorized) {
      for (const staffDef of STAFF_KEYWORDS) {
        if (staffDef.keywords.some((kw) => roleName.includes(kw))) {
          roleInfo.tier = staffDef.tier;
          roleInfo.staffLevel = staffDef.level;
          hierarchy.staffRoles.push(roleInfo);
          if (!hierarchy.tiers[staffDef.tier]) hierarchy.tiers[staffDef.tier] = [];
          hierarchy.tiers[staffDef.tier].push(roleInfo);
          categorized = true;
          break;
        }
      }
    }

    // Also detect staff by permissions if not caught by name
    if (!categorized && roleInfo.permissions.includes('Administrator')) {
      roleInfo.tier = 'admin';
      roleInfo.staffLevel = 90;
      hierarchy.staffRoles.push(roleInfo);
      if (!hierarchy.tiers['admin']) hierarchy.tiers['admin'] = [];
      hierarchy.tiers['admin'].push(roleInfo);
      categorized = true;
    } else if (!categorized && (roleInfo.permissions.includes('BanMembers') || roleInfo.permissions.includes('KickMembers') || roleInfo.permissions.includes('ManageMessages'))) {
      roleInfo.tier = 'moderator';
      roleInfo.staffLevel = 70;
      hierarchy.staffRoles.push(roleInfo);
      if (!hierarchy.tiers['moderator']) hierarchy.tiers['moderator'] = [];
      hierarchy.tiers['moderator'].push(roleInfo);
      categorized = true;
    }

    // Gender roles
    if (!categorized) {
      for (const [gender, keywords] of Object.entries(GENDER_KEYWORDS)) {
        if (keywords.some((kw) => roleName.includes(kw))) {
          roleInfo.tier = 'gender';
          roleInfo.genderType = gender;
          hierarchy.genderRoles.push(roleInfo);
          categorized = true;
          break;
        }
      }
    }

    // Level/rank roles
    if (!categorized && (LEVEL_PATTERN.test(roleName) || RANK_PATTERN.test(roleName))) {
      roleInfo.tier = 'level';
      hierarchy.levelRoles.push(roleInfo);
      categorized = true;
    }

    // Vanity/cosmetic roles
    if (!categorized && VANITY_KEYWORDS.some((kw) => roleName.includes(kw))) {
      roleInfo.tier = 'vanity';
      hierarchy.vanityRoles.push(roleInfo);
      categorized = true;
    }

    // Everything else
    if (!categorized) {
      hierarchy.otherRoles.push(roleInfo);
    }

    hierarchy.roleMap[role.id] = roleInfo;
  }

  // Sort staff by level
  hierarchy.staffRoles.sort((a, b) => b.staffLevel - a.staffLevel);
  hierarchy.highestStaffRole = hierarchy.staffRoles[0] || null;

  roleCache.set(guild.id, hierarchy);
  return hierarchy;
}

/**
 * Get a user's role analysis — their position in the hierarchy.
 */
function analyzeUserRoles(guild, member) {
  const hierarchy = analyzeServerRoles(guild);
  if (!member?.roles?.cache) return null;

  const userRoles = member.roles.cache
    .filter((r) => r.name !== '@everyone')
    .sort((a, b) => b.position - a.position);

  const analysis = {
    userId: member.id,
    username: member.user?.username || member.displayName || 'unknown',
    displayName: member.displayName || member.user?.username || 'unknown',
    roles: [],
    highestRole: null,
    isStaff: false,
    staffTier: null,
    staffLevel: 0,
    detectedGender: 'unknown',
    isBooster: member.premiumSince ? true : false,
    joinedAt: member.joinedAt?.toISOString() || null,
    isOwner: guild.ownerId === member.id,
  };

  if (analysis.isOwner) {
    analysis.isStaff = true;
    analysis.staffTier = 'owner';
    analysis.staffLevel = 100;
  }

  for (const [, role] of userRoles) {
    const roleInfo = hierarchy.roleMap[role.id];
    if (!roleInfo) continue;

    analysis.roles.push({
      name: role.name,
      tier: roleInfo.tier,
      position: roleInfo.position,
      staffLevel: roleInfo.staffLevel,
    });

    // Highest role
    if (!analysis.highestRole || roleInfo.position > analysis.highestRole.position) {
      analysis.highestRole = { name: role.name, position: roleInfo.position };
    }

    // Staff detection
    if (roleInfo.staffLevel > analysis.staffLevel) {
      analysis.isStaff = true;
      analysis.staffTier = roleInfo.tier;
      analysis.staffLevel = roleInfo.staffLevel;
    }

    // Gender detection from roles
    if (roleInfo.genderType && analysis.detectedGender === 'unknown') {
      analysis.detectedGender = roleInfo.genderType;
    }
  }

  return analysis;
}

/**
 * Build a human-readable summary of server roles for AI context.
 * Uses role NAMES only — never pings.
 */
function buildRoleContextForAI(guild) {
  const hierarchy = analyzeServerRoles(guild);
  const parts = [];

  parts.push(`[Server: ${hierarchy.guildName} | Members: ${hierarchy.totalMembers} | Roles: ${hierarchy.totalRoles}]`);

  if (hierarchy.staffRoles.length > 0) {
    parts.push('[Staff Hierarchy (highest to lowest):');
    for (const role of hierarchy.staffRoles.slice(0, 15)) {
      const memberCount = role.memberCount > 0 ? ` (${role.memberCount} members)` : ' (empty)';
      parts.push(`  ${role.tier.toUpperCase()}: ${role.name}${memberCount}`);
    }
    parts.push(']');
  }

  if (hierarchy.genderRoles.length > 0) {
    parts.push('[Gender Roles: ' + hierarchy.genderRoles.map((r) => `${r.name} (${r.genderType})`).join(', ') + ']');
  }

  if (hierarchy.levelRoles.length > 0) {
    parts.push('[Level Roles: ' + hierarchy.levelRoles.slice(0, 10).map((r) => r.name).join(', ') + ']');
  }

  if (hierarchy.botRoles.length > 0) {
    parts.push('[Bot Roles: ' + hierarchy.botRoles.slice(0, 8).map((r) => r.name).join(', ') + ']');
  }

  return parts.join('\n');
}

/**
 * Build human-readable summary of a specific user's roles for AI context.
 */
function buildUserRoleContext(guild, member) {
  const analysis = analyzeUserRoles(guild, member);
  if (!analysis) return '';

  const parts = [];
  parts.push(`[User Roles for ${analysis.displayName}:`);

  if (analysis.isOwner) parts.push('  STATUS: Server Owner');
  else if (analysis.isStaff) parts.push(`  STATUS: Staff (${analysis.staffTier})`);
  else parts.push('  STATUS: Regular member');

  if (analysis.roles.length > 0) {
    parts.push('  Roles: ' + analysis.roles.map((r) => r.name).join(', '));
  }

  if (analysis.highestRole) {
    parts.push(`  Highest Role: ${analysis.highestRole.name}`);
  }

  if (analysis.detectedGender !== 'unknown') {
    parts.push(`  Gender (from roles): ${analysis.detectedGender}`);
  }

  if (analysis.isBooster) parts.push('  Server Booster: Yes');
  if (analysis.joinedAt) parts.push(`  Joined: ${analysis.joinedAt}`);

  parts.push(']');
  return parts.join('\n');
}

/**
 * Answer a question about roles/server info.
 * Returns structured data the AI can use.
 */
function getServerInfoForQuery(guild, query) {
  const hierarchy = analyzeServerRoles(guild);
  const lower = query.toLowerCase();
  const info = {};

  // Server basics
  info.serverName = guild.name;
  info.memberCount = guild.memberCount;
  info.createdAt = guild.createdAt?.toISOString();
  info.ownerId = guild.ownerId;
  info.boostLevel = guild.premiumTier;
  info.boostCount = guild.premiumSubscriptionCount;
  info.totalRoles = hierarchy.totalRoles;
  info.totalChannels = guild.channels.cache.size;

  // If asking about staff
  if (/staff|admin|mod|team|official|who runs|who owns/.test(lower)) {
    info.staffRoles = hierarchy.staffRoles.map((r) => ({
      name: r.name,
      tier: r.tier,
      members: r.memberCount,
    }));
  }

  // If asking about specific roles
  if (/role|roles/.test(lower)) {
    info.allRoles = [...hierarchy.staffRoles, ...hierarchy.otherRoles, ...hierarchy.genderRoles, ...hierarchy.vanityRoles]
      .slice(0, 25)
      .map((r) => ({ name: r.name, tier: r.tier, members: r.memberCount }));
  }

  return info;
}

/**
 * Clear cached data for a guild (call on role updates).
 */
function invalidateRoleCache(guildId) {
  roleCache.delete(guildId);
}

module.exports = {
  analyzeServerRoles,
  analyzeUserRoles,
  buildRoleContextForAI,
  buildUserRoleContext,
  getServerInfoForQuery,
  invalidateRoleCache,
};
