const { updateSocialGraph, getStrongestPairs, getUserStats, updateUserStats, logReaction, getTopReactedUsers } = require('../database/server');
const { extractMentionedUserIds } = require('../utils/helpers');

/**
 * Process a message and update the social graph.
 */
function processMessageForSocialGraph(guildId, message) {
  const userId = message.author.id;

  // Track mentions
  const mentionedIds = extractMentionedUserIds(message.content);
  for (const mentionedId of mentionedIds) {
    if (mentionedId !== userId) {
      updateSocialGraph(guildId, userId, mentionedId, 'mention');
      updateUserStats(guildId, userId, { incrementMentions: true });
      updateUserStats(guildId, mentionedId, { incrementMentionsReceived: true });
    }
  }

  // Track direct user mentions from Discord API
  if (message.mentions?.users?.size > 0) {
    for (const [mentionedId] of message.mentions.users) {
      if (mentionedId !== userId && !mentionedIds.includes(mentionedId)) {
        updateSocialGraph(guildId, userId, mentionedId, 'mention');
        updateUserStats(guildId, userId, { incrementMentions: true });
        updateUserStats(guildId, mentionedId, { incrementMentionsReceived: true });
      }
    }
  }
}

/**
 * Update social graph when a reply is detected.
 */
function trackReply(guildId, fromUserId, toUserId) {
  if (fromUserId === toUserId) return;
  updateSocialGraph(guildId, fromUserId, toUserId, 'reply');
  updateUserStats(guildId, fromUserId, { incrementReplies: true });
  updateUserStats(guildId, toUserId, { incrementRepliesReceived: true });
}

/**
 * Track a reaction event for social graph analysis.
 */
function trackReaction(guildId, { messageId, channelId, userId, emoji, targetUserId }) {
  if (userId === targetUserId) return;
  logReaction(guildId, { messageId, channelId, userId, emoji, targetUserId });
  if (targetUserId) {
    updateSocialGraph(guildId, userId, targetUserId, 'mention'); // Reactions = soft interaction
  }
}

/**
 * Get relationship insights for a pair of users.
 */
function getRelationshipInsight(guildId, userA, userB) {
  const pairs = getStrongestPairs(guildId, 30);
  const pair = pairs.find(
    (p) => (p.user_a === userA && p.user_b === userB) || (p.user_a === userB && p.user_b === userA)
  );
  if (!pair) return null;

  const strength = pair.interaction_count;
  let insight = '';
  if (strength > 100) insight = 'inseparable / best friends energy';
  else if (strength > 50) insight = 'very close / always talking';
  else if (strength > 20) insight = 'close friends / frequent interaction';
  else if (strength > 10) insight = 'regular interaction';
  else if (strength > 5) insight = 'occasional interaction';
  else insight = 'barely interact';

  // Analyze if one-sided
  const reverse = pairs.find((p) => p.user_a === pair.user_b && p.user_b === pair.user_a);
  const isOneSided = !reverse || reverse.interaction_count < pair.interaction_count * 0.3;

  return { ...pair, insight, isOneSided, reverseStrength: reverse?.interaction_count || 0 };
}

/**
 * Detect relationship dynamics from the social graph.
 * Returns interesting patterns.
 */
function detectDynamics(guildId) {
  const pairs = getStrongestPairs(guildId, 20);
  const dynamics = [];
  const seen = new Set();

  for (const pair of pairs) {
    const key = [pair.user_a, pair.user_b].sort().join('-');
    if (seen.has(key)) continue;
    seen.add(key);

    if (pair.interaction_count > 15) {
      // Check if reverse exists
      const reverse = pairs.find((p) => p.user_a === pair.user_b && p.user_b === pair.user_a);

      if (reverse && reverse.interaction_count > 10) {
        // Mutual relationship
        const totalStrength = pair.interaction_count + reverse.interaction_count;
        let label = 'close';
        if (totalStrength > 100) label = 'besties / inseparable';
        else if (totalStrength > 50) label = 'tight';
        else if (pair.reply_count > pair.mention_count * 2) label = 'deep convos';

        dynamics.push({
          type: 'mutual',
          users: [pair.user_a, pair.user_b],
          strength: totalStrength,
          label,
        });
      } else if (!reverse || reverse.interaction_count < pair.interaction_count * 0.2) {
        // One-sided attention
        dynamics.push({
          type: 'one-sided',
          from: pair.user_a,
          to: pair.user_b,
          strength: pair.interaction_count,
        });
      }
    }
  }

  // Sort by strength
  dynamics.sort((a, b) => b.strength - a.strength);
  return dynamics.slice(0, 10);
}

/**
 * Get conversation pairs for a specific user.
 */
function getUserConnections(guildId, userId) {
  const pairs = getStrongestPairs(guildId, 50);
  return pairs.filter((p) => p.user_a === userId || p.user_b === userId)
    .map((p) => ({
      partnerId: p.user_a === userId ? p.user_b : p.user_a,
      interactions: p.interaction_count,
      replies: p.reply_count,
      label: p.relationship_label,
    }))
    .sort((a, b) => b.interactions - a.interactions)
    .slice(0, 10);
}

module.exports = {
  processMessageForSocialGraph,
  trackReply,
  trackReaction,
  getRelationshipInsight,
  detectDynamics,
  getUserConnections,
};
