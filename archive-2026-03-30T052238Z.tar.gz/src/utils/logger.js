const { appendFileSync, mkdirSync, existsSync } = require('fs');
const { join } = require('path');
const config = require('../config');

const logsDir = join(config.paths.data, 'logs');
if (!existsSync(logsDir)) mkdirSync(logsDir, { recursive: true });

const LEVELS = { DEBUG: 0, INFO: 1, WARN: 2, ERROR: 3 };
const currentLevel = LEVELS[process.env.LOG_LEVEL?.toUpperCase()] ?? LEVELS.INFO;

function getISTTimestamp() {
  const ist = new Date(Date.now() + 5.5 * 60 * 60 * 1000);
  return ist.toISOString().replace('T', ' ').replace('Z', '');
}

function getLogFile() {
  const ist = new Date(Date.now() + 5.5 * 60 * 60 * 1000);
  const date = ist.toISOString().split('T')[0]; // YYYY-MM-DD
  return join(logsDir, `${date}.log`);
}

function write(level, tag, message, extra) {
  if (LEVELS[level] < currentLevel) return;

  const ts = getISTTimestamp();
  let line = `[${ts} IST] [${level}] [${tag}] ${message}`;
  if (extra) {
    const str = extra instanceof Error ? extra.stack || extra.message : String(extra);
    line += ` | ${str}`;
  }

  // Console output
  if (level === 'ERROR') console.error(line);
  else if (level === 'WARN') console.warn(line);
  else console.log(line);

  // File output
  try { appendFileSync(getLogFile(), line + '\n'); } catch (_) { /* best-effort */ }
}

const logger = {
  debug: (tag, msg, extra) => write('DEBUG', tag, msg, extra),
  info: (tag, msg, extra) => write('INFO', tag, msg, extra),
  warn: (tag, msg, extra) => write('WARN', tag, msg, extra),
  error: (tag, msg, extra) => write('ERROR', tag, msg, extra),
};

module.exports = logger;
