const { mkdirSync, existsSync } = require('fs');
const config = require('../config');

function ensureDirectories() {
  const dirs = [config.paths.data, config.paths.servers];
  for (const dir of dirs) {
    if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
  }
}

function randomInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function randomFloat(min, max) {
  return Math.random() * (max - min) + min;
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function truncate(str, len = 1900) {
  if (!str) return '';
  return str.length > len ? str.slice(0, len) + '...' : str;
}

/**
 * Get current time in IST (Indian Standard Time, UTC+5:30).
 */
function getISTTime() {
  const now = new Date();
  const ist = new Date(now.getTime() + (5.5 * 60 * 60 * 1000));
  return ist;
}

/**
 * Format a date as IST string.
 */
function formatIST(date) {
  if (!date) date = new Date();
  const ist = new Date(date.getTime() + (5.5 * 60 * 60 * 1000));
  const hours = ist.getUTCHours();
  const minutes = ist.getUTCMinutes().toString().padStart(2, '0');
  const ampm = hours >= 12 ? 'PM' : 'AM';
  const h12 = hours % 12 || 12;
  const day = ist.getUTCDate();
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const month = months[ist.getUTCMonth()];
  const year = ist.getUTCFullYear();
  return `${day} ${month} ${year}, ${h12}:${minutes} ${ampm} IST`;
}

/**
 * Get current IST hour (0-23).
 */
function getISTHour() {
  const now = new Date();
  const ist = new Date(now.getTime() + (5.5 * 60 * 60 * 1000));
  return ist.getUTCHours();
}

function timeSince(dateMs) {
  const seconds = Math.floor((Date.now() - dateMs) / 1000);
  if (seconds < 60) return `${seconds}s ago`;
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  return `${days}d ago`;
}

function extractMentionedUserIds(content) {
  const regex = /<@!?(\d+)>/g;
  const ids = [];
  let match;
  while ((match = regex.exec(content)) !== null) {
    ids.push(match[1]);
  }
  return ids;
}

/**
 * CRITICAL SAFETY: Sanitize bot output before sending to Discord.
 * Strips all role pings, @everyone, @here from AI-generated text.
 * Strips extreme sexual/toxic slurs that shouldn't be output.
 * Prevents self-pinging. Only allows individual user pings (<@userid>).
 */
function sanitizeBotOutput(text, botId) {
  if (!text) return '';

  let sanitized = text;

  // Remove @everyone and @here (case-insensitive)
  sanitized = sanitized.replace(/@everyone/gi, 'everyone');
  sanitized = sanitized.replace(/@here/gi, 'here');

  // Remove role pings: <@&ROLEID>
  sanitized = sanitized.replace(/<@&\d+>/g, '');

  // Remove any remaining @& patterns that might slip through
  sanitized = sanitized.replace(/@&/g, '');

  // Prevent self-pinging (bot mentioning itself)
  if (botId) {
    sanitized = sanitized.replace(new RegExp(`<@!?${botId}>`, 'g'), '');
  }

  // Strip extreme sexual/toxic slurs the bot should NEVER output
  // These catch all variants — misspellings, spacing, partial matches
  const toxicPatterns = [
    /randi/gi,                                       // randi anywhere
    /rand\b/gi,                                      // rand (variant of randi)
    /chut/gi,                                        // chut anywhere
    /ch\s*o*\s*t/gi,                                 // c h o t variants
    /\blund\b/gi,                                    // lund
    /\bland?\b/gi,                                   // lan, land 
    /gand/gi,                                        // gand anywhere
    /g\s*a\s*n\s*d/gi,                              // g a n d spaced
    /teri\s+(ma|maa|ammi)/gi,                       // teri maa/ma/ammi (any continuation)
    /\b(ma|maa|ammi)\s+(ki|ka)\s/gi,               // maa ki/ka anything
    /\bmkc+\b/gi,                                    // mkc, mkccc
    /\btmkc+\b/gi,                                   // tmkc
    /khandan/gi,                                     // khandan
    /chod/gi,                                        // chod in any form
    /fuda/gi,                                        // fuda
    /fandi/gi,                                       // fandi
  ];

  for (const pattern of toxicPatterns) {
    sanitized = sanitized.replace(pattern, '');
  }

  // Clean up leftover fragments: "ka bc 😂" → "bc 😂", " ki  😂" → "😂"
  sanitized = sanitized.replace(/\b(ka|ki|ke|ki)\s+(😂|🤣|💀)/g, '$2');
  sanitized = sanitized.replace(/\s{2,}/g, ' ').trim();

  // If sanitization removed everything meaningful, return a safe fallback
  if (sanitized.length < 2) return null;

  return sanitized;
}

/**
 * Format a number with K/M suffix.
 */
function formatNumber(num) {
  if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
  if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
  return String(num);
}

module.exports = {
  ensureDirectories,
  randomInt,
  randomFloat,
  sleep,
  truncate,
  getISTTime,
  formatIST,
  getISTHour,
  timeSince,
  extractMentionedUserIds,
  sanitizeBotOutput,
  formatNumber,
};
