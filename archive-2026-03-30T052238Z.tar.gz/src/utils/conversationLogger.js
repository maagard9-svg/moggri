const { appendFileSync, mkdirSync, existsSync, readFileSync } = require('fs');
const { join } = require('path');
const config = require('../config');

const convoDir = join(config.paths.data, 'logs', 'conversations');
if (!existsSync(convoDir)) mkdirSync(convoDir, { recursive: true });

function getISTTimestamp() {
  const ist = new Date(Date.now() + 5.5 * 60 * 60 * 1000);
  return ist.toISOString().replace('T', ' ').replace('Z', '');
}

function getConvoLogFile() {
  const ist = new Date(Date.now() + 5.5 * 60 * 60 * 1000);
  const date = ist.toISOString().split('T')[0];
  return join(convoDir, `${date}.log`);
}

/**
 * Log a user message -> bot reply pair to the conversation log file.
 */
function logConversation({ serverName, channelName, username, userMessage, botReply }) {
  const ts = getISTTimestamp();
  const line = [
    `[${ts} IST]`,
    `[${serverName || 'Unknown Server'} / #${channelName || 'unknown'}]`,
    `${username}: ${userMessage}`,
    `${config.bot.name}: ${botReply}`,
    '---',
  ].join('\n') + '\n';

  try {
    appendFileSync(getConvoLogFile(), line);
  } catch (_) {
    // best-effort logging
  }
}

/**
 * Read the latest conversation log and return its contents (for review / training).
 */
function readConversationLog(date) {
  const file = date
    ? join(convoDir, `${date}.log`)
    : getConvoLogFile();
  if (!existsSync(file)) return null;
  return readFileSync(file, 'utf-8');
}

module.exports = { logConversation, readConversationLog };
