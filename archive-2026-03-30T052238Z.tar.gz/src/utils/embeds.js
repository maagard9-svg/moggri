const { EmbedBuilder } = require('discord.js');

const COLORS = {
  primary: 0x5865F2,
  success: 0x57F287,
  warning: 0xFEE75C,
  danger: 0xED4245,
  info: 0x5865F2,
  starklink: 0xA855F7,
};

function baseEmbed() {
  return new EmbedBuilder()
    .setColor(COLORS.starklink)
    .setTimestamp()
    .setFooter({ text: 'StarkLink AI • by moggerstark' });
}

function successEmbed(title, description) {
  return baseEmbed()
    .setColor(COLORS.success)
    .setTitle(title)
    .setDescription(description);
}

function errorEmbed(title, description) {
  return baseEmbed()
    .setColor(COLORS.danger)
    .setTitle(title)
    .setDescription(description);
}

function infoEmbed(title, description) {
  return baseEmbed()
    .setTitle(title)
    .setDescription(description);
}

function statsEmbed(title, fields = []) {
  const embed = baseEmbed()
    .setTitle(title);

  for (const field of fields) {
    embed.addFields({ name: field.name, value: String(field.value), inline: field.inline ?? true });
  }

  return embed;
}

function userProfileEmbed(user, stats, memories = []) {
  const embed = baseEmbed()
    .setTitle(user.display_name || user.username)
    .addFields(
      { name: 'Messages', value: String(user.total_messages || 0), inline: true },
      { name: 'Gender', value: user.detected_gender || 'unknown', inline: true },
      { name: 'Language', value: user.preferred_language || 'en', inline: true },
      { name: 'Vibe', value: user.vibe || 'neutral', inline: true },
    );

  if (stats) {
    const replyRate = stats.message_count > 0 ? Math.round((stats.replies_received / stats.message_count) * 100) : 0;
    embed.addFields(
      { name: 'Server Msgs', value: String(stats.message_count || 0), inline: true },
      { name: 'Reply Rate', value: `${replyRate}%`, inline: true },
    );
  }

  if (user.personality_summary) {
    embed.addFields({ name: 'Personality', value: user.personality_summary, inline: false });
  }

  if (memories.length > 0) {
    const memText = memories.slice(0, 5).map((m) => `• ${m.content}`).join('\n');
    embed.addFields({ name: 'Memories', value: memText, inline: false });
  }

  return embed;
}

function helpEmbed(prefix) {
  return baseEmbed()
    .setTitle('StarkLink Commands')
    .setDescription('Advanced AI chatbot that feels human. Made by moggerstark.\nTimezone: IST (Indian Standard Time)')
    .addFields(
      { name: `${prefix}setchatchannel add/remove/list`, value: 'Set channels where AI is active', inline: false },
      { name: `${prefix}setwelcomechannel [#channel]`, value: 'Set welcome channel for new members (use "off" to disable)', inline: false },
      { name: `${prefix}enable / ${prefix}disable`, value: 'Enable/disable AI in this server', inline: false },
      { name: `${prefix}banai @user / ${prefix}unbanai @user`, value: 'Ban/unban user from AI', inline: false },
      { name: `${prefix}profile [@user]`, value: 'View AI profile of a user', inline: false },
      { name: `${prefix}whois [@user]`, value: 'Detailed user info with roles & stats', inline: false },
      { name: `${prefix}roles`, value: 'View server role hierarchy', inline: false },
      { name: `${prefix}serverinfo`, value: 'View server information', inline: false },
      { name: `${prefix}stats`, value: 'Server AI stats & top users', inline: false },
      { name: `${prefix}leaderboard`, value: 'Server message leaderboard', inline: false },
      { name: `${prefix}vibes`, value: 'Current channel vibe analysis', inline: false },
      { name: `${prefix}social [@user]`, value: 'View social connections', inline: false },
      { name: `${prefix}memory [@user]`, value: 'View stored memories about a user', inline: false },
      { name: `${prefix}forgetme`, value: 'Clear your memory data', inline: false },
      { name: `${prefix}status`, value: 'Bot status & model info', inline: false },
      { name: `${prefix}help`, value: 'Show this help menu', inline: false },
    );
}

function socialGraphEmbed(pairs, title = 'Social Connections') {
  const embed = baseEmbed()
    .setTitle(title);

  if (pairs.length === 0) {
    embed.setDescription('Not enough data yet. Keep chatting!');
    return embed;
  }

  const lines = pairs.map((p, i) => {
    const label = p.relationship_label ? ` (${p.relationship_label})` : '';
    return `**${i + 1}.** <@${p.user_a}> ↔ <@${p.user_b}>: **${p.interaction_count}** interactions${label}`;
  });

  embed.setDescription(lines.join('\n'));
  return embed;
}

module.exports = {
  COLORS,
  baseEmbed,
  successEmbed,
  errorEmbed,
  infoEmbed,
  statsEmbed,
  userProfileEmbed,
  helpEmbed,
  socialGraphEmbed,
};
