const { getRecentMessages, getChatChannels, getChannelVibe, getServerDb, getMessageVelocity, getIgnoredMessages, logMessage, logEngagement, getEngagementSuccessRate } = require('../database/server');
const { getInactiveUsers } = require('../database/global');
const { buildEngagementContext } = require('../ai/context');
const { chat } = require('../ai/groq');
const { sanitizeBotOutput, getISTTime } = require('../utils/helpers');
const { randomInt, sleep } = require('../utils/helpers');
const { markBotReplied } = require('./decision');
const config = require('../config');

// Track which users we've already pinged recently about inactivity
const recentPings = new Map();

/**
 * Get IST hour (0-23) for time-of-day awareness.
 */
function getISTHour() {
  return getISTTime().getUTCHours();
}

/**
 * Score a channel for engagement suitability.
 * Higher score = better candidate for proactive message.
 */
function scoreChannel(guildId, channelId) {
  const recentMsgs = getRecentMessages(guildId, channelId, 30);
  if (recentMsgs.length === 0) return -1;

  const lastMsgTime = recentMsgs[recentMsgs.length - 1]?.created_at || 0;
  const timeSinceLastMsg = Math.floor(Date.now() / 1000) - lastMsgTime;

  // Not quiet enough or too dead
  if (timeSinceLastMsg < 300 || timeSinceLastMsg > 1800) return -1;

  let score = 50;

  // More recent activity = slightly better
  score += Math.max(0, 30 - Math.floor(timeSinceLastMsg / 60));

  // More messages = more active channel = better
  score += Math.min(recentMsgs.length * 2, 30);

  // Ignored messages boost — someone needs attention
  const ignored = getIgnoredMessages(guildId, channelId, 5);
  score += ignored.length * 10;

  // Channel engagement success rate
  const successRate = getEngagementSuccessRate(guildId, channelId);
  if (successRate !== null) {
    score += Math.round(successRate * 20); // 0-20 bonus
  }

  return score;
}

/**
 * Proactive engagement loop — runs periodically.
 * Uses weighted channel scoring instead of random selection.
 * IST time-of-day aware: reduced activity 2AM-7AM.
 */
async function engagementLoop(client) {
  // IST time-of-day check — reduce activity during late night
  const hour = getISTHour();
  if (hour >= 2 && hour < 7) {
    // Late night: only 10% chance to even attempt
    if (Math.random() > 0.1) return;
  }

  for (const guild of client.guilds.cache.values()) {
    try {
      await processGuildEngagement(client, guild);
    } catch (err) {
      console.error(`[ENGAGEMENT] Error for guild ${guild.id}:`, err.message);
    }
  }
}

async function processGuildEngagement(client, guild) {
  const guildId = guild.id;
  const chatChannels = getChatChannels(guildId);

  let targetChannels = [];
  if (chatChannels.length > 0) {
    targetChannels = chatChannels;
  } else {
    const firstText = guild.channels.cache.find((c) => c.type === 0 && c.permissionsFor(guild.members.me)?.has('SendMessages'));
    if (firstText) targetChannels = [firstText.id];
  }

  if (targetChannels.length === 0) return;

  // Score all channels and pick the best one
  const scored = targetChannels
    .map((id) => ({ id, score: scoreChannel(guildId, id) }))
    .filter((c) => c.score > 0)
    .sort((a, b) => b.score - a.score);

  if (scored.length === 0) return;

  // Pick from top 3 with weighted random (best channel most likely)
  const top = scored.slice(0, 3);
  const totalScore = top.reduce((s, c) => s + c.score, 0);
  let pick = Math.random() * totalScore;
  let channelId = top[0].id;
  for (const c of top) {
    pick -= c.score;
    if (pick <= 0) { channelId = c.id; break; }
  }

  const channel = guild.channels.cache.get(channelId);
  if (!channel) return;

  // Check recent activity
  const recentMsgs = getRecentMessages(guildId, channelId, 30);
  if (recentMsgs.length === 0) return;

  // Don't engage too often — random chance
  if (Math.random() > 0.3) return;

  // Build context and generate a proactive message
  const messages = buildEngagementContext(guild, channel, recentMsgs);
  const result = await chat(messages, { temperature: 1.0, maxTokens: 150 });

  if (result.content) {
    // SAFETY: Sanitize output
    const sanitized = sanitizeBotOutput(result.content);
    if (!sanitized) return;

    await sleep(randomInt(2000, 8000));
    try {
      const sent = await channel.send(sanitized);
      logMessage(guildId, {
        messageId: sent.id,
        channelId: channel.id,
        userId: client.user.id,
        username: config.bot.name,
        content: sanitized,
        isBotMessage: true,
      });
      logEngagement(guildId, channel.id, sent.id, 'proactive');
      markBotReplied(channelId);
    } catch (err) {
      console.error('[ENGAGEMENT] Send failed:', err.message);
    }
  }
}

/**
 * Ping inactive users occasionally with AI-generated callouts.
 */
async function pingInactiveUsers(client) {
  // Reduce during late night IST
  const hour = getISTHour();
  if (hour >= 2 && hour < 7) return;

  const inactiveUsers = getInactiveUsers(86400);
  if (inactiveUsers.length === 0) return;

  for (const guild of client.guilds.cache.values()) {
    const chatChannels = getChatChannels(guild.id);
    const channelId = chatChannels.length > 0
      ? chatChannels[0]
      : guild.channels.cache.find((c) => c.type === 0)?.id;

    if (!channelId) continue;
    const channel = guild.channels.cache.get(channelId);
    if (!channel) continue;

    for (const user of inactiveUsers.slice(0, 2)) {
      const pingKey = `${guild.id}-${user.user_id}`;
      const lastPing = recentPings.get(pingKey) || 0;
      if (Date.now() - lastPing < 86400000) continue;

      const member = guild.members.cache.get(user.user_id);
      if (!member) continue;

      if (Math.random() > 0.15) continue;

      // Generate AI callout for this user
      let msg;
      try {
        const result = await chat([
          { role: 'system', content: `You are ${config.bot.name} in "${guild.name}". You noticed <@${user.user_id}> (${user.username}) has been inactive. Write a SHORT (1 line) casual callout to them. Be playful, not annoying. Include their mention <@${user.user_id}>.` },
          { role: 'user', content: `Call out ${user.username} for being inactive in a chill way.` },
        ], { temperature: 1.0, maxTokens: 60 });
        msg = result.content ? sanitizeBotOutput(result.content) : null;
      } catch (_) { /* fallback below */ }

      // Fallback if AI fails
      if (!msg) {
        const callouts = [
          `<@${user.user_id}> you show up, talk, then vanish again... classic`,
          `<@${user.user_id}> been real quiet lately`,
          `haven't seen <@${user.user_id}> in a minute... still alive?`,
          `<@${user.user_id}> disappeared again huh`,
          `<@${user.user_id}> your absence has been noted`,
        ];
        msg = callouts[randomInt(0, callouts.length - 1)];
      }

      try {
        await sleep(randomInt(3000, 10000));
        const sent = await channel.send(msg);
        logMessage(guild.id, {
          messageId: sent.id,
          channelId: channel.id,
          userId: client.user.id,
          username: config.bot.name,
          content: msg,
          isBotMessage: true,
        });
        logEngagement(guild.id, channel.id, sent.id, 'inactive_ping');
        recentPings.set(pingKey, Date.now());
        markBotReplied(channelId);
      } catch (err) {
        // Skip
      }

      break;
    }
  }
}

module.exports = {
  engagementLoop,
  pingInactiveUsers,
};
