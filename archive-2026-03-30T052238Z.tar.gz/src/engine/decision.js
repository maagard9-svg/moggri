const config = require('../config');
const { isChatChannel, isUserBanned, isUserIgnored, getRecentMessages, getServerConfig, getMessageVelocity, getRoleSnapshot } = require('../database/server');
const { randomFloat } = require('../utils/helpers');

// Track per-channel cooldowns and consecutive replies
const channelCooldowns = new Map();
const consecutiveReplies = new Map();
const lastBotMessage = new Map();

// Track users on "silent treatment" — said bye/fuckoff, bot ignores until they come back
// Now stores timestamp so it can auto-expire after 2 hours
const silentTreatment = new Map();

// Per-user rate limiting to prevent spam-triggering
const userCooldowns = new Map();
const userSpamTracker = new Map();

// Other bot command patterns — NEVER respond to these
const OTHER_BOT_COMMAND_PATTERNS = [
  /^[,\.!\-;~`>\$%\^\+]\w{1,20}$/i,               // ,m .aura -m !staff $bal ,voice ,i etc.
  /^[,\.!\-;~`>\$%\^\+]\w{1,20}\s+\S/i,           // ,play song / .ban user / .lb m etc.
  /^\w{1,6}[?!]\w{1,10}$/i,                        // s?u s?m t!help etc.
  /^[<][@#]\d+[>]\s*$/,                             // just a ping with nothing else
  /^(\+|-|\*|\/|=)\w/i,                             // math-style bot commands
  /^[,\.!\-;~`>\$%\^\+]\s+\w{1,15}$/i,            // , m or . aura with space
  /^\.lb\b/i,                                       // .lb m, .lb voice etc.
  /^,lb\b/i,                                        // ,lb voice
  /^,vc$/i,                                         // ,vc
  /^,i$/i,                                          // ,i
  /^,voice/i,                                       // ,voice, ,voice lb
];

// Channel name patterns that are for other bots — NEVER respond in these
const BOT_CHANNEL_PATTERNS = [
  /bot(z|s|tz|ts)?/i,      // #botzz #bots #bot-commands etc.
  /command/i,              // #commands #bot-commands
  /music/i,                // #music
  /counting/i,             // #counting
  /bump/i,                 // #bump
];

// Greeting patterns — bot MUST always reply to these
const GREETING_PATTERNS = [
  /^(hello|hey|hi|yo|sup|heyy+|hii+|helloo+|yoo+|ayy?o?|wassup|whatsup|what'?s\s*up)\b/i,
  /^(gm|good\s*morning|good\s*evening|good\s*afternoon|good\s*night)\b/i,
  /^(oi|ayo|yooo+|broo?|bhai|yaar|dude)\s*[!?.]*$/i,
  /^(namaste|namaskar|salaam|salam|adab)\b/i,
];

// Callout patterns — someone asking if anyone's there, bot MUST reply
const CALLOUT_PATTERNS = [
  /\b(koi hai|anyone here|anyone online|anyone there|is anyone|anybody here|anyone up|koi h|koi he|kon hai|kaun hai)\b/i,
  /\b(koi baat kar(o|lo)|baat karo|baat karlo|chat karo|come chat|talk to me|someone talk|bored af|i'?m bored)\b/i,
  /\b(dead chat|chat dead|nobody talking|no one talking|so quiet|itna sannata|khamoshi)\b/i,
  /\b(entertain me|say something|kuch bolo|bol na|bolo kuch|sun na|suno)\b/i,
  /\b(lonely|akela|alone here|all alone)\b/i,
];

/**
 * Decision engine: Should the bot reply to this message?
 */
function shouldRespond(message, guildId) {
  const channelId = message.channel.id;
  const userId = message.author.id;
  const botId = message.client.user.id;
  const content = message.content.toLowerCase();

  // --- Hard blocks ---

  // Ignore all bots
  if (message.author.bot) {
    return { shouldReply: false, reason: 'is_bot' };
  }

  // Ignore commands meant for OTHER bots (,m .aura s?u -m !staff etc.)
  for (const pattern of OTHER_BOT_COMMAND_PATTERNS) {
    if (pattern.test(content.trim())) {
      return { shouldReply: false, reason: 'other_bot_command' };
    }
  }

  // Don't respond in bot-dedicated channels (unless directly pinged)
  // Strip Unicode decoration chars (fullwidth dots, symbols, emojis) to match real channel name
  const chanName = (message.channel.name || '').toLowerCase().replace(/[^a-z0-9\-_\s]/gi, '');
  const isBotChannel = BOT_CHANNEL_PATTERNS.some(p => p.test(chanName));
  if (isBotChannel && !message.mentions.has(botId)) {
    return { shouldReply: false, reason: 'bot_channel' };
  }

  // Is AI disabled for this server?
  if (getServerConfig(guildId, 'ai_enabled', 'true') === 'false') {
    return { shouldReply: false, reason: 'ai_disabled' };
  }

  // Not a chat channel?
  if (!isChatChannel(guildId, channelId)) {
    return { shouldReply: false, reason: 'not_chat_channel' };
  }

  // User banned from AI?
  if (isUserBanned(guildId, userId)) {
    return { shouldReply: false, reason: 'user_banned' };
  }

  // --- Silent treatment check (bye/fuckoff users) ---
  const silentKey = `${guildId}-${userId}`;
  const silentSince = silentTreatment.get(silentKey);
  if (silentSince) {
    // Auto-expire after 2 hours
    if (Date.now() - silentSince > 2 * 60 * 60 * 1000) {
      silentTreatment.delete(silentKey);
    } else {
      // Only break silence if user pings bot directly or replies to bot
      const mentionedBot = message.mentions.has(botId);
      let repliedToBot = false;
      if (message.reference) {
        const recentMsgs = getRecentMessages(guildId, channelId, 50);
        const repliedTo = recentMsgs.find((m) => m.message_id === message.reference.messageId);
        if (repliedTo && repliedTo.is_bot_message) repliedToBot = true;
      }

      if (mentionedBot || repliedToBot) {
        silentTreatment.delete(silentKey);
      } else {
        return { shouldReply: false, reason: 'silent_treatment' };
      }
    }
  }

  // User asked to be ignored (via DB)?
  if (isUserIgnored(guildId, userId)) {
    // ONLY respond if they ping the bot directly
    if (!message.mentions.has(botId)) {
      return { shouldReply: false, reason: 'user_ignored' };
    }
  }

  // --- High priority triggers (always respond) ---

  // Bot was mentioned/pinged
  if (message.mentions.has(botId)) {
    return {
      shouldReply: true,
      reason: 'mentioned',
      delay: randomDelay(2000, 6000),
    };
  }

  // Someone replied to bot's message
  if (message.reference) {
    const recentMsgs = getRecentMessages(guildId, channelId, 50);
    const repliedTo = recentMsgs.find((m) => m.message_id === message.reference.messageId);
    if (repliedTo && repliedTo.is_bot_message) {
      return {
        shouldReply: true,
        reason: 'replied_to_bot',
        delay: randomDelay(3000, 10000),
      };
    }
  }

  // Bot name mentioned in text
  const botNameLower = config.bot.name.toLowerCase();
  if (content.includes(botNameLower) || content.includes('starklink') || content.includes('stark link')) {
    return {
      shouldReply: true,
      reason: 'name_mentioned',
      delay: randomDelay(4000, 12000),
    };
  }

  // --- Greeting / Callout detection (HIGH PRIORITY — always reply) ---
  for (const pattern of GREETING_PATTERNS) {
    if (pattern.test(content.trim())) {
      return {
        shouldReply: true,
        reason: 'greeting',
        delay: randomDelay(3000, 8000),
      };
    }
  }

  for (const pattern of CALLOUT_PATTERNS) {
    if (pattern.test(content.trim())) {
      return {
        shouldReply: true,
        reason: 'callout',
        delay: randomDelay(4000, 12000),
      };
    }
  }

  // --- "Fuck off" / "bye" / ignore triggers ---
  const dismissPatterns = [
    /fuck\s*off/i, /shut\s*up/i, /don'?t\s*talk\s*to\s*me/i,
    /leave\s*me\s*alone/i, /go\s*away/i, /stfu/i,
    /stop\s*talking/i, /nobody\s*asked\s*(you|u)?/i,
    /be\s*quiet/i, /zip\s*it/i,
  ];

  const byePatterns = [
    /^(bye|gn|gtg|goodnight|good night|cya|see ya|later|peace out|im out|i'?m leaving)$/i,
    /^(bye|gn|gtg|goodnight|cya)\s+(starklink|stark|bot)/i,
  ];

  // Check if message was directed at bot (within 30s of bot's last message)
  const lastBot = lastBotMessage.get(channelId);
  const recentBotInteraction = lastBot && Date.now() - lastBot.time < 30000;

  if (recentBotInteraction) {
    // Dismiss patterns — activate silent treatment (stores timestamp for auto-expiry)
    for (const pattern of dismissPatterns) {
      if (pattern.test(content)) {
        silentTreatment.set(silentKey, Date.now());
        return { shouldReply: false, reason: 'ignore_requested', silentUser: true };
      }
    }

    // Bye patterns — activate silent treatment (softer)
    for (const pattern of byePatterns) {
      if (pattern.test(content.trim())) {
        silentTreatment.set(silentKey, Date.now());
        return { shouldReply: false, reason: 'user_said_bye', silentUser: true };
      }
    }
  }

  // --- Staff message bonus ---
  let staffBonus = 0;
  try {
    const roleSnap = getRoleSnapshot(guildId, userId);
    if (roleSnap && roleSnap.is_staff) {
      staffBonus = 0.15;
    }
  } catch (e) { /* optional */ }

  // --- Message is a reply to someone else (not bot) ---
  if (message.reference && message.reference.messageId) {
    // Low chance to butt in to someone else's conversation
    if (Math.random() > 0.08 + staffBonus) {
      return { shouldReply: false, reason: 'reply_to_others' };
    }
  }

  // --- Cooldown check ---
  const lastCooldown = channelCooldowns.get(channelId) || 0;
  const velocity = getMessageVelocity(guildId, channelId, 60);
  const dynamicCooldown = velocity > 5 ? config.bot.cooldownPerChannel * 0.6 : config.bot.cooldownPerChannel;

  if (Date.now() - lastCooldown < dynamicCooldown) {
    return { shouldReply: false, reason: 'cooldown' };
  }

  // --- Consecutive reply limit ---
  const consecutive = consecutiveReplies.get(channelId) || 0;
  if (consecutive >= config.bot.maxConsecutiveReplies) {
    return { shouldReply: false, reason: 'consecutive_limit' };
  }

  // --- Random ignore (human unpredictability) ---
  if (Math.random() < config.bot.ignoreChance) {
    return { shouldReply: false, reason: 'random_ignore' };
  }

  // --- Per-user rate limit (prevent spam-triggering) ---
  const userKey = `${guildId}-${userId}`;
  const lastUserReply = userCooldowns.get(userKey) || 0;
  if (Date.now() - lastUserReply < 15000) {
    return { shouldReply: false, reason: 'user_cooldown' };
  }

  // Anti-spam: if user sent >5 messages in 30s, reduce reply chance drastically
  const spamData = userSpamTracker.get(userKey);
  let spamPenalty = 1.0;
  if (spamData && Date.now() - spamData.start < 30000) {
    if (spamData.count > 5) spamPenalty = 0.1;
  }

  // --- Content-based triggers for STANDALONE messages (not replies) ---
  if (!message.reference) {
    const baseChance = 0.30;
    const lengthBonus = Math.min(content.length / 100, 0.25);
    const questionBonus = content.includes('?') ? 0.40 : 0;
    const emotionBonus = /(!{2,}|lmao|bruh|wtf|omg|bro|nah|fr|deadass|lowkey)/i.test(content) ? 0.15 : 0;
    const opinionBonus = /^(i think|imo|honestly|ngl|unpopular opinion|hot take|controversial)/i.test(content) ? 0.30 : 0;
    const directQuestion = /(what do (you|y'?all|u) think|thoughts\??|opinions?\??|agree\??)/i.test(content) ? 0.40 : 0;
    const energyBonus = content === content.toUpperCase() && content.length > 5 ? 0.15 : 0;
    const topicBonus = content.length > 40 ? 0.15 : 0;
    // Hindi/casual callout phrases that didn't match exact patterns above
    const hindiBonus = /\b(kya|bhai|yaar|bro|dude|arey|arre|sun|suno|dekh|chalo|chal|batao|bata|plz|please|tell|kon|kaun)\b/i.test(content) ? 0.20 : 0;
    // Someone talking to the chat / asking questions to anyone
    const openConvoBonus = /\b(who|what|how|why|where|when|which|choose|pick|best|worst|favourite|favorite)\b/i.test(content) ? 0.25 : 0;
    // Dead chat — bot should talk more when nobody else is
    const velocity = getMessageVelocity(guildId, channelId, 60);
    const deadChatBonus = velocity <= 2 ? 0.25 : 0;
    // BUSY CHAT PENALTY: when many people are talking, reduce reply chance significantly
    const busyPenalty = velocity > 15 ? 0.4 : velocity > 10 ? 0.6 : velocity > 6 ? 0.8 : 1.0;

    const replyChance = (baseChance + lengthBonus + questionBonus + emotionBonus + opinionBonus + directQuestion + energyBonus + topicBonus + hindiBonus + openConvoBonus + deadChatBonus + staffBonus) * spamPenalty * busyPenalty;

    if (Math.random() < replyChance) {
      return {
        shouldReply: true,
        reason: 'organic',
        delay: randomDelay(config.bot.replyDelayMin, config.bot.replyDelayMax),
      };
    }
  }

  return { shouldReply: false, reason: 'no_trigger' };
}

/**
 * Should the bot react instead of replying?
 */
function shouldReact(message, replyChanceScore) {
  const content = message.content.toLowerCase();
  const emotionalBoost = /(!{2,}|lmao|bruh|wtf|omg|💀|😂|🔥|😭)/i.test(content) ? 0.12 : 0;
  // If message scored >0.4 in reply chance but didn't get picked, react more often
  const nearMissBoost = (replyChanceScore && replyChanceScore > 0.4) ? 0.12 : 0;
  return Math.random() < (config.bot.reactChance + emotionalBoost + nearMissBoost);
}

/**
 * Get a random reaction emoji based on message content.
 */
function getReactionEmoji(content) {
  const lower = content.toLowerCase();
  const emojiMap = [
    { pattern: /lmao|haha|lol|funny|comedy/i, emojis: ['😂', '💀', '🤣', '😹'] },
    { pattern: /sad|😢|😭|crying|depressed|rip/i, emojis: ['😢', '🫂', '💔', '🥺'] },
    { pattern: /fire|🔥|hot|sick|insane|crazy/i, emojis: ['🔥', '💯', '🫡', '⚡'] },
    { pattern: /love|❤|heart|cute|adorable/i, emojis: ['❤️', '💕', '🫶', '💗'] },
    { pattern: /wtf|bruh|what|huh|weirdo/i, emojis: ['💀', '😐', '🗿', '🤨'] },
    { pattern: /cap|lie|fake|sus|sussy/i, emojis: ['🧢', '💀', '🤨', '👀'] },
    { pattern: /\bw\b|win|goat|best|king|queen/i, emojis: ['👑', '🐐', '💪', '🏆'] },
    { pattern: /\bl\b|loss|ratio|cope|loser/i, emojis: ['💀', '📉', '🫠', '🤡'] },
    { pattern: /smart|genius|big brain/i, emojis: ['🧠', '💡', '🤓'] },
    { pattern: /cringe|ew|gross|yikes/i, emojis: ['😬', '🫣', '💀'] },
    { pattern: /sleep|tired|bed|goodnight|gn/i, emojis: ['😴', '💤', '🌙'] },
    { pattern: /food|eat|hungry|yummy/i, emojis: ['🍕', '😋', '🤤'] },
  ];

  for (const { pattern, emojis } of emojiMap) {
    if (pattern.test(lower)) {
      return emojis[Math.floor(Math.random() * emojis.length)];
    }
  }

  const defaults = ['👀', '💀', '🫡', '🤔', '👁️', '🗿', '😐', '🫣'];
  return defaults[Math.floor(Math.random() * defaults.length)];
}

function markBotReplied(channelId, userId, guildId) {
  channelCooldowns.set(channelId, Date.now());
  consecutiveReplies.set(channelId, (consecutiveReplies.get(channelId) || 0) + 1);
  lastBotMessage.set(channelId, { time: Date.now() });
  // Track per-user cooldown
  if (userId && guildId) {
    userCooldowns.set(`${guildId}-${userId}`, Date.now());
  }
}

function trackUserMessage(userId, guildId) {
  const key = `${guildId}-${userId}`;
  const data = userSpamTracker.get(key);
  if (data && Date.now() - data.start < 30000) {
    data.count++;
  } else {
    userSpamTracker.set(key, { start: Date.now(), count: 1 });
  }
}

function resetConsecutive(channelId) {
  consecutiveReplies.set(channelId, 0);
}

function randomDelay(min, max) {
  return Math.floor(Math.random() * (max - min)) + min;
}

module.exports = {
  shouldRespond,
  shouldReact,
  getReactionEmoji,
  markBotReplied,
  resetConsecutive,
  trackUserMessage,
};
