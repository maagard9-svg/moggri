const { Client, GatewayIntentBits, Partials } = require('discord.js');
const { appendFileSync, mkdirSync, existsSync } = require('fs');
const { join } = require('path');
const config = require('./config');
const { ensureDirectories } = require('./utils/helpers');
const { initGlobalDb } = require('./database/global');
const { registerEvents } = require('./events/ready');

// Ensure data directories exist
ensureDirectories();

// --- Crash log helper ---
const logsDir = join(config.paths.data, 'logs');
if (!existsSync(logsDir)) mkdirSync(logsDir, { recursive: true });

function logCrash(label, err) {
  const ist = new Date(Date.now() + 5.5 * 60 * 60 * 1000);
  const ts = ist.toISOString().replace('T', ' ').replace('Z', ' IST');
  const line = `[${ts}] [${label}] ${err?.stack || err?.message || String(err)}\n`;
  try { appendFileSync(join(logsDir, 'crash.log'), line); } catch (_) { /* best-effort */ }
  console.error(`[${label}]`, err);
}

// Create Discord client with all needed intents
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildPresences,
    GatewayIntentBits.GuildMessageReactions,
  ],
  partials: [Partials.Message, Partials.Channel, Partials.Reaction],
});

// Initialize global database
initGlobalDb();

// Register all events
registerEvents(client);

// --- Login with auto-reconnect ---
let reconnectAttempts = 0;
const MAX_RECONNECT = 10;

function login() {
  client.login(config.discord.token).catch((err) => {
    logCrash('LOGIN FAILED', err);
    scheduleReconnect();
  });
}

function scheduleReconnect() {
  if (reconnectAttempts >= MAX_RECONNECT) {
    logCrash('FATAL', new Error(`Max reconnect attempts (${MAX_RECONNECT}) reached, exiting`));
    process.exit(1);
  }
  reconnectAttempts++;
  const delay = Math.min(reconnectAttempts * 5000, 60000);
  console.log(`[RECONNECT] Attempt ${reconnectAttempts}/${MAX_RECONNECT} in ${delay / 1000}s...`);
  setTimeout(login, delay);
}

// Reset counter on successful connection
client.once('ready', () => { reconnectAttempts = 0; });

// Auto-reconnect on disconnect
client.on('shardDisconnect', (event, shardId) => {
  logCrash('SHARD DISCONNECT', new Error(`Shard ${shardId} disconnected (code ${event?.code})`));
  scheduleReconnect();
});

client.on('shardError', (err, shardId) => {
  logCrash('SHARD ERROR', err);
});

client.on('shardReconnecting', (shardId) => {
  console.log(`[SHARD] Reconnecting shard ${shardId}...`);
});

login();

// Graceful shutdown
process.on('SIGINT', () => {
  console.log('[SHUTDOWN] Closing...');
  client.destroy();
  process.exit(0);
});

process.on('SIGTERM', () => {
  console.log('[SHUTDOWN] SIGTERM received, closing...');
  client.destroy();
  process.exit(0);
});

process.on('unhandledRejection', (err) => {
  logCrash('UNHANDLED REJECTION', err);
});

process.on('uncaughtException', (err) => {
  logCrash('UNCAUGHT EXCEPTION', err);
  // Give time for the log to flush, then exit
  setTimeout(() => process.exit(1), 2000);
});
